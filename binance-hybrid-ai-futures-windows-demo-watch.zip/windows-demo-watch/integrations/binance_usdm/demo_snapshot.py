"""Strict REST snapshot used after startup, reconnect, fills and uncertain writes."""

import hashlib
import json
from datetime import datetime
from decimal import Decimal
from typing import Any

from integrations.binance_usdm.demo import DemoClient, DemoFailure, DemoNotFound
from integrations.binance_usdm.filters import number
from services.execution.demo_models import DemoLedger, DemoSnapshot


def signed_number(value: object) -> Decimal:
    if isinstance(value, (float, bool)) or not isinstance(value, (str, int, Decimal)):
        raise DemoFailure("Invalid DEMO financial number")
    result = Decimal(value)
    if not result.is_finite():
        raise DemoFailure("Non-finite DEMO financial number")
    return result


def pick(raw: Any, keys: tuple[str, ...]) -> dict[str, str]:
    if not isinstance(raw, dict) or any(key not in raw for key in keys):
        raise DemoFailure("Incomplete DEMO order snapshot")
    return {
        key: str(raw[key]).lower() if isinstance(raw[key], bool) else str(raw[key]) for key in keys
    }


ORDER_KEYS = (
    "symbol",
    "clientOrderId",
    "orderId",
    "side",
    "type",
    "status",
    "origQty",
    "executedQty",
    "avgPrice",
    "price",
    "positionSide",
    "reduceOnly",
)
ALGO_KEYS = (
    "symbol",
    "clientAlgoId",
    "algoId",
    "side",
    "orderType",
    "algoStatus",
    "triggerPrice",
    "closePosition",
    "positionSide",
    "workingType",
    "priceProtect",
    "algoType",
)


def snapshot(client: DemoClient, ledger: DemoLedger, now: datetime) -> DemoSnapshot:
    mode = client.request("GET", "/fapi/v1/positionSide/dual")
    assets = client.request("GET", "/fapi/v1/multiAssetsMargin")
    if (
        not isinstance(mode, dict)
        or mode.get("dualSidePosition") is not False
        or not isinstance(assets, dict)
        or assets.get("multiAssetsMargin") is not False
    ):
        raise DemoFailure(
            "DEMO supports verified one-way/single-asset only; settings are never changed automatically"
        )
    account = client.request("GET", "/fapi/v3/account")
    configs = client.request("GET", "/fapi/v1/symbolConfig")
    positions_raw = client.request("GET", "/fapi/v3/positionRisk")
    regular = client.request("GET", "/fapi/v1/openOrders")
    algos_raw = client.request("GET", "/fapi/v1/openAlgoOrders")
    if not isinstance(account, dict) or not all(
        isinstance(x, list) for x in (positions_raw, regular, algos_raw, configs)
    ):
        raise DemoFailure("Invalid DEMO account/open-order response")
    wallet = signed_number(account["totalWalletBalance"])
    unrealized = signed_number(account["totalUnrealizedProfit"])
    available = number(account["availableBalance"], allow_zero=True)
    margin = number(account["totalInitialMargin"], allow_zero=True)
    positions: dict[str, Decimal] = {}
    entry_prices: dict[str, Decimal] = {}
    leverage: dict[str, Decimal] = {}
    for item in configs:
        if item.get("marginType") != "CROSSED":
            raise DemoFailure("DEMO cross margin configuration required")
        leverage[item["symbol"]] = number(item["leverage"])
    for row in positions_raw:
        if row.get("positionSide") != "BOTH" or row.get("marginType", "cross") != "cross":
            raise DemoFailure("Unsupported DEMO position mode")
        symbol = row["symbol"]
        if symbol in positions:
            raise DemoFailure("Ambiguous DEMO positions")
        positions[symbol] = signed_number(row["positionAmt"])
        entry_prices[symbol] = number(row["entryPrice"], allow_zero=True)
        # V3 omits leverage: account configuration is queried separately per symbol.

    orders = {str(row["clientOrderId"]): pick(row, ORDER_KEYS) for row in regular}
    algos = {
        str(row["clientAlgoId"]): pick(row, ALGO_KEYS)
        | {"actualOrderId": str(row.get("actualOrderId", ""))}
        for row in algos_raw
    }
    if len(orders) != len(regular) or len(algos) != len(algos_raw):
        raise DemoFailure("Duplicate remote IDs")
    for order in ledger.orders.values():
        if order.client_id not in orders:
            try:
                raw = client.request(
                    "GET",
                    "/fapi/v1/order",
                    {"symbol": order.signal.symbol, "origClientOrderId": order.client_id},
                )
                orders[order.client_id] = pick(raw, ORDER_KEYS)
            except DemoNotFound:
                pass  # Preserve SUBMITTING/UNKNOWN and its reservation; absence is not rejection.
        for algo_id in [order.algo_id, order.tp_algo_id]:
            if algo_id and algo_id not in algos:
                try:
                    raw = client.request("GET", "/fapi/v1/algoOrder", {"clientAlgoId": algo_id})
                    algos[algo_id] = pick(raw, ALGO_KEYS) | {
                        "actualOrderId": str(raw.get("actualOrderId", ""))
                    }
                except DemoNotFound:
                    pass
        if order.exit_id and order.exit_id not in orders:
            try:
                raw = client.request(
                    "GET",
                    "/fapi/v1/order",
                    {"symbol": order.signal.symbol, "origClientOrderId": order.exit_id},
                )
                orders[order.exit_id] = pick(raw, ORDER_KEYS)
            except DemoNotFound:
                pass
    for algo in algos.values():
        actual = algo.get("actualOrderId")
        if algo["algoStatus"] == "FINISHED" and actual and actual != "0":
            raw = client.request(
                "GET", "/fapi/v1/order", {"symbol": algo["symbol"], "orderId": actual}
            )
            orders["ALGO_EXEC:" + actual] = pick(raw, ORDER_KEYS)
    data = dict(
        positions={s: str(q) for s, q in positions.items()},
        orders=orders,
        algos=algos,
        wallet=str(wallet),
        unrealized=str(unrealized),
        available=str(available),
        margin=str(margin),
    )
    transfers: dict[str, str] = {}
    if ledger.income_since_ms is not None:
        for page in range(1, 11):
            incomes = client.request(
                "GET",
                "/fapi/v1/income",
                {
                    "startTime": str(ledger.income_since_ms),
                    "endTime": str(int(now.timestamp() * 1000)),
                    "limit": "1000",
                    "page": str(page),
                },
            )
            if not isinstance(incomes, list):
                raise DemoFailure("Invalid DEMO income response")
            for item in incomes:
                if item["incomeType"] in {"TRANSFER", "WELCOME_BONUS"}:
                    if item.get("asset") != "USDT":
                        raise DemoFailure("Unexpected account transfer asset")
                    transfers[item["incomeType"] + ":" + str(item["tranId"])] = str(
                        signed_number(item["income"])
                    )
            if len(incomes) < 1000:
                break
        else:
            raise DemoFailure("DEMO income pagination incomplete; refuse new entries")
    fingerprint = hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()
    return DemoSnapshot(
        as_of=now,
        equity=wallet + unrealized,
        available_balance=available,
        margin_used=margin,
        positions=positions,
        entry_prices=entry_prices,
        leverage=leverage,
        orders=orders,
        algos=algos,
        fingerprint=fingerprint,
        transfers=transfers,
    )
