# 이전 preflight 수정 안내

이 배포에는 후속 수정이 포함되어 있습니다. 현재 안전 경계와 실행 방법은 DEMO_PRIVATE_CHECK_KO.md를 읽으세요.
