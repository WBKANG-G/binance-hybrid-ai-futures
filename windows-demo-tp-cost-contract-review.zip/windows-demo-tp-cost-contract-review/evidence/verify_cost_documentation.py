import ast,hashlib,json,urllib.request
from pathlib import Path
proof=Path('docs/request_cost_evidence/PINNED_RUNTIME_COST_PROOF.json')
data=json.loads(proof.read_text());verified={};sources={}
for name,record in data['files'].items():
 with urllib.request.urlopen(record['url'],timeout=30) as response:
  assert response.status==200
  raw=response.read()
 assert hashlib.sha256(raw).hexdigest()==record['sha256']
 sources[name]=raw.decode()
 verified[name]=dict(url=record['url'],http_status=200,sha256=record['sha256'],bytes=len(raw))
for row in data['routes']:
 tree=ast.parse(sources[row['sdk_file']])
 node=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name==row['sdk_method'])
 assert node.lineno==row['method_line']
 assert row['path'] in [n.value for n in ast.walk(node) if isinstance(n,ast.Constant) and isinstance(n.value,str)]
 doc=ast.get_docstring(node);assert doc
 lines=doc.splitlines();first=next(i for i,line in enumerate(lines) if 'Weight' in line)
 assert '\n'.join(lines[first:]).split('Args:')[0].strip()==row['weight_excerpt']
result=dict(status='VERIFIED_PINNED_PUBLIC_SDK_DOCUMENTATION_ONLY',sdk_commit=data['sdk_commit'],files=verified,route_excerpts_verified=len(data['routes']),actual_exchange_requests=0,current_venue_cost_bounds_verified=False,execution_approved=False)
Path('/tmp/cost-contract-sdk-evidence.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(source_files_verified=len(verified),route_excerpts_verified=len(data['routes']),actual_exchange_requests=0)))
