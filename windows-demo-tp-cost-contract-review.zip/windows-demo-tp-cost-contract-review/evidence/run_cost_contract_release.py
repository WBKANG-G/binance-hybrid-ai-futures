import asyncio,os
from pathlib import Path
python='/workspace/windows-transfer/phase4-review/review-venv/bin/python'
names=['test_demo','test_demo_validation','test_demo_flat_confirmation','test_demo_flat_transport','test_demo_tp_trigger_check','test_tp_budget_rescue','test_managed_order_quota','test_quota_startup_review','test_shared_weight_budget','test_shared_weight_checkpoint','test_managed_runtime_assembly','test_runtime_storage_binding','test_runtime_start_guard','test_runtime_request_contract','test_runtime_header_provenance','test_runtime_proof_freshness','test_runtime_clock_refresh','test_runtime_stopped_admission','test_runtime_confirmation_deadline','test_runtime_confirmation_once','test_runtime_confirmation_drain','test_runtime_confirmation_binding','test_runtime_confirmation_lock','test_runtime_confirmation_report','test_runtime_capacity_fit','test_runtime_observation_budget','test_runtime_cost_binding']
env=dict(os.environ,TEST_DATABASE_URL='postgresql+psycopg://dev:dev@127.0.0.1:55435/hybrid',RUNTIME_ASSEMBLY_REPORT_DIR='/tmp/cost-contract-lifecycle-release')
async def run(label,args):
 with open('/tmp/cost-contract-release-'+label+'.log','w') as f:
  p=await asyncio.create_subprocess_exec(python,'-m','pytest','-q',*args,'--junitxml=/tmp/cost-contract-release-'+label+'.xml',env=env,stdout=f,stderr=asyncio.subprocess.STDOUT)
  code=await p.wait()
  print(label,code,flush=True)
  return code
async def main():
 commands=[run('regression',['tests/unit']+['tests/integration/'+n+'.py' for n in names])]
 commands += [run(mode,['tests/integration/test_managed_runtime_lifecycle.py','-k','['+mode+']']) for mode in ['tp','partial','seal_failure']]
 return max(await asyncio.gather(*commands))
raise SystemExit(asyncio.run(main()))
