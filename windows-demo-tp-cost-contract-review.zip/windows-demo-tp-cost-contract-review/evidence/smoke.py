import json
from integrations.binance_usdm.demo_tp_weight_model import MODELED_TP_ROUTE_COSTS
from packages.persistence.demo_order_quota import LocalQuotaStopped
from services.execution.demo_managed_runtime import assemble_managed_runtime
from services.execution.demo_runtime_cost_contract import RULES,cost_contract_report,require_runtime_cost_contract
report=cost_contract_report(MODELED_TP_ROUTE_COSTS)
assert report['documented_routes_covered']==21 and not report['execution_approved']
for rule in RULES:
 costs=dict(MODELED_TP_ROUTE_COSTS);costs[rule.method,rule.path]=rule.modeled_weight+1
 try:
  require_runtime_cost_contract(costs)
 except LocalQuotaStopped:
  pass
 else:
  raise AssertionError('changed initial model accepted')
try:
 assemble_managed_runtime(None,None,None,None,None)
except LocalQuotaStopped as error:
 assert str(error)=='RUNTIME_REAL_EXECUTION_DISABLED'
else:
 raise AssertionError('execution enabled')
print(json.dumps(dict(smoke='PASSED',network='NONE',scope='PINNED_DOCUMENTED_COST_GUARD_AND_DEFAULT_REFUSAL',routes_checked=21,changed_costs_refused=21,actual_exchange_requests=0,execution_approved=False)))
