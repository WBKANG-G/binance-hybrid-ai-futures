"""Explicit isolated DEMO CLI. Default is read-only authenticated preflight."""

import argparse
import asyncio
import json
import os
from decimal import Decimal
from pathlib import Path
from uuid import UUID, uuid4

import yaml
from sqlalchemy import create_engine
from sqlalchemy.exc import SQLAlchemyError

from integrations.binance_usdm.demo import DemoClient, DemoCredentials, DemoFailure, DemoSettings
from packages.domain.config import UniqueKeyLoader, database_url
from packages.domain.contracts import Signal
from packages.persistence.demo import DemoStore
from services.execution.demo import DemoCoordinator
from services.execution.demo_models import DemoLedger
from services.execution.demo_stream import session
from services.risk.paper import AccountValue, GateSnapshot, RiskRejected, period_keys


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument(
        "--account",
        required=True,
        help="Dedicated DEMO- account; never share the underlying exchange account",
    )
    parser.add_argument(
        "--initialize", action="store_true", help="Create a new DEMO ledger (never overwrite)"
    )
    parser.add_argument(
        "--enable-demo", action="store_true", help="Explicit opt-in to DEMO writes only"
    )
    parser.add_argument(
        "--watch", action="store_true", help="Run protected private-stream supervision"
    )
    parser.add_argument(
        "--signal", type=Path, help="One explicit DEMO Signal + GateSnapshot; requires --watch"
    )
    parser.add_argument("--command", choices=["PAUSE_ENTRIES", "SAFE_STOP", "EMERGENCY_FLATTEN"])
    parser.add_argument("--operation-id", type=UUID)
    parser.add_argument(
        "--resume-entries",
        action="store_true",
        help="Explicitly resume NORMAL/reconciled entries inside --watch; never clears hard locks",
    )
    args = parser.parse_args()
    if (
        os.getenv("LIVE_TRADING_ENABLED", "false").lower() != "false"
        or os.getenv("TRADING_MODE", "PAPER") == "LIVE"
    ):
        parser.error("LIVE context is forbidden in the DEMO CLI")
    config = DemoSettings.model_validate(yaml.load(args.config.read_text(), Loader=UniqueKeyLoader))
    if args.enable_demo:
        config = DemoSettings.model_validate(config.model_dump() | {"demo_trading_enabled": True})
    if (args.watch or args.command or args.signal) and not config.demo_trading_enabled:
        parser.error("DEMO writes require explicit --enable-demo or a reviewed DEMO config")
    if args.resume_entries and (not args.watch or not args.operation_id):
        parser.error("--resume-entries requires --watch and a stable --operation-id")
    if args.signal and not args.watch:
        parser.error("--signal requires continuous --watch protection")
    if args.command and not args.operation_id:
        parser.error("Commands require a stable --operation-id")
    try:
        credentials = DemoCredentials.from_environment()
    except ValueError as error:
        parser.error(str(error))
    engine = create_engine(database_url().get_secret_value(), connect_args={"connect_timeout": 2})
    coordinator = None
    lease = None
    store = DemoStore(engine)
    try:
        now = store.now()
        if args.initialize:
            day, week = period_keys(now, config.policy.week_start_kst)
            store.create(
                args.account,
                DemoLedger(
                    policy=config.policy,
                    value=AccountValue(as_of=now, initial=Decimal(1)),
                    daily_base=Decimal(1),
                    weekly_base=Decimal(1),
                    high_water=Decimal(1),
                    daily_key=day,
                    weekly_key=week,
                ),
            )
        lease = store.acquire(args.account, uuid4())
        client = DemoClient(config, credentials)
        client.sync_clock()
        coordinator = DemoCoordinator(store, lease, client)
        coordinator.refresh_metadata()
        coordinator.reconcile()
        if args.command:
            result = coordinator.command(args.operation_id, args.command)
            print(
                json.dumps(
                    {
                        "environment": "DEMO",
                        "operation_result": result,
                        "live_trading_enabled": False,
                    }
                )
            )
        elif args.watch:

            def on_ready() -> None:
                if args.resume_entries:
                    coordinator.resume_entries(args.operation_id)
                if args.signal:
                    raw = json.loads(args.signal.read_text())
                    signal = Signal.model_validate(raw["signal"])
                    coordinator.reserve(signal, GateSnapshot.model_validate(raw["gate"]))
                    coordinator.submit(str(signal.signal_id))

            asyncio.run(session(coordinator, on_ready=on_ready))
        else:
            ledger = store.read(args.account)
            print(
                json.dumps(
                    {
                        "environment": "DEMO",
                        "preflight": "READ_ONLY",
                        "account_reconciled": ledger.reconciled,
                        "private_stream_ready": ledger.stream_ready,
                        "orders_enabled": False,
                        "live_trading_enabled": False,
                        "risk_state": ledger.risk_state.value,
                    }
                )
            )
    except KeyboardInterrupt:
        # No silent assumption of flat. On restart the new leader must reconcile.
        print("DEMO supervisor stopped; inspect positions/protection and reconcile before entry")
    except (DemoFailure, RiskRejected, SQLAlchemyError, ValueError, KeyError, OSError):
        raise SystemExit(
            "DEMO operation blocked or unresolved; inspect sanitized ledger/status, network and runtime credential bindings"
        ) from None
    finally:
        if lease is not None:
            try:
                store.release(lease)
            except Exception:
                pass
        engine.dispose()


if __name__ == "__main__":
    main()
