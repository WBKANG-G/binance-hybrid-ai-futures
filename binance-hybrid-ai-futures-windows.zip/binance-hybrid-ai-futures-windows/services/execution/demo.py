"""Durable DEMO coordinator. No simulator is accepted as authenticated evidence."""

from decimal import Decimal
from hashlib import sha256
from typing import Any
from uuid import UUID

from integrations.binance_usdm.demo import DemoClient, DemoFailure, DemoRejected
from integrations.binance_usdm.demo_snapshot import signed_number, snapshot
from integrations.binance_usdm.filters import SymbolRules, number
from integrations.binance_usdm.orders import build_entry, build_protection
from packages.domain.contracts import (
    AlgoOrder,
    EntryOrder,
    OrderState,
    PositionState,
    RiskState,
    Signal,
    TradingMode,
)
from packages.persistence.demo import DemoStore
from services.execution.demo_models import DemoLedger, DemoSnapshot
from services.execution.models import Lease, PaperOrder
from services.execution.paper import account_risk
from services.risk.paper import (
    AccountValue,
    GateSnapshot,
    RiskRejected,
    period_keys,
    size,
    unit_loss,
)

ZERO = Decimal(0)
TERMINAL = {OrderState.FILLED, OrderState.CANCELED, OrderState.REJECTED, OrderState.EXPIRED}
STATES = {
    "NEW": OrderState.ACKNOWLEDGED,
    "PARTIALLY_FILLED": OrderState.PARTIALLY_FILLED,
    "FILLED": OrderState.FILLED,
    "CANCELED": OrderState.CANCELED,
    "EXPIRED": OrderState.EXPIRED,
    "EXPIRED_IN_MATCH": OrderState.EXPIRED,
    "REJECTED": OrderState.REJECTED,
}


class DemoCoordinator:
    def __init__(self, store: DemoStore, lease: Lease, client: DemoClient):
        self.store, self.lease, self.client = store, lease, client
        self.rules: dict[str, SymbolRules] = {}
        if store.read(lease.account_id).policy != client.settings.policy:
            raise RiskRejected("DEMO immutable policy mismatch")

    def _fresh(self, ledger: DemoLedger) -> None:
        now = self.store.now()
        account_risk(ledger, now)
        if (
            ledger.paused
            or ledger.risk_state != RiskState.NORMAL
            or not ledger.reconciled
            or not ledger.stream_ready
        ):
            raise RiskRejected("DEMO entry gate locked/not reconciled/private stream unavailable")
        if (
            ledger.last_reconciled is None
            or ledger.stream_at is None
            or any(
                not 0 <= (now - t).total_seconds() <= ledger.policy.max_snapshot_age_seconds
                for t in (ledger.last_reconciled, ledger.stream_at)
            )
        ):
            raise RiskRejected("DEMO account/private stream stale")

    def refresh_metadata(self) -> None:
        info = self.client.public("/fapi/v1/exchangeInfo")
        self.rules = {
            item["symbol"]: SymbolRules.from_exchange_info(info, item["symbol"])
            for item in info["symbols"]
            if item.get("status") == "TRADING"
            and item.get("contractType") == "PERPETUAL"
            and item.get("quoteAsset") == "USDT"
            and item.get("marginAsset") == "USDT"
        }

    def reserve(self, signal: Signal, gate: GateSnapshot) -> PaperOrder:
        signal = Signal.model_validate(signal.model_dump())
        if not self.client.settings.demo_trading_enabled:
            raise RiskRejected("DEMO entry reservations disabled in read-only preflight")
        if signal.environment != TradingMode.DEMO:
            raise RiskRejected("Only DEMO signals can reach the DEMO coordinator")
        rules = self.rules.get(signal.symbol)
        if rules is None:
            raise RiskRejected("DEMO symbol metadata unavailable")

        def apply(ledger: DemoLedger) -> PaperOrder:
            key = str(signal.signal_id)
            if key in ledger.orders:
                if ledger.orders[key].signal != signal:
                    raise RiskRejected("Conflicting DEMO signal ID")
                return ledger.orders[key].model_copy(deep=True)
            self._fresh(ledger)
            # Re-fetch under the same account lock before granting a new reservation.
            remote = snapshot(self.client, ledger, self.store.now())
            if remote.fingerprint != ledger.fingerprint:
                raise RiskRejected("DEMO remote state changed; reconcile first")
            quantity, loss = size(
                ledger.policy, signal, gate, ledger.value.equity, rules, self.store.now()
            )
            active = [o for o in ledger.orders.values() if o.remaining or o.open_quantity]
            equity = ledger.value.equity
            notional = quantity * signal.suggested_limit_price
            total = sum((o.notional for o in active), ZERO) + notional
            risk = sum((o.charged_risk for o in active), ZERO) + quantity * loss
            leverage = remote.leverage.get(signal.symbol, ZERO)
            if leverage <= 0 or any(
                remote.leverage.get(o.signal.symbol, ZERO) <= 0 for o in active
            ):
                raise RiskRejected("Missing verified DEMO leverage")
            existing_margin = sum(
                (o.notional / remote.leverage[o.signal.symbol] for o in active), ZERO
            )
            reserved_margin = sum(
                (
                    o.remaining * o.signal.suggested_limit_price / remote.leverage[o.signal.symbol]
                    for o in active
                    if o.state
                    in {OrderState.RISK_RESERVED, OrderState.SUBMITTING, OrderState.UNKNOWN}
                ),
                ZERO,
            )
            if (
                leverage <= 0
                or leverage > ledger.policy.limit("max_leverage")
                or len(active) >= ledger.policy.limit("max_concurrent_positions")
                or any(o.signal.symbol == signal.symbol for o in active)
                or notional > equity * ledger.policy.limit("max_single_notional_pct") / 100
                or total > equity * ledger.policy.limit("max_total_notional_pct") / 100
                or max(existing_margin, remote.margin_used) + notional / leverage
                > equity * ledger.policy.limit("max_margin_usage_pct") / 100
                or notional / leverage + reserved_margin > remote.available_balance
                or risk > equity * ledger.policy.limit("max_correlated_risk_pct") / 100
            ):
                raise RiskRejected("DEMO reservation/filter/leverage/exposure cap")
            client_id = "DE-" + sha256((self.lease.account_id + key).encode()).hexdigest()[:30]
            order = PaperOrder(
                client_id=client_id,
                signal=signal,
                snapshot=gate,
                group=gate.correlation_group,
                quantity=quantity,
                quantity_step=rules.step_size,
                price_tick=rules.tick_size,
                remaining=quantity,
                loss_per_unit=loss,
                budget=quantity * loss,
            )
            ledger.orders[key] = order
            return order.model_copy(deep=True)

        return self.store.change(self.lease, "DEMO_ENTRY_RESERVED", apply)

    def submit(self, key: str) -> None:
        def stage(ledger: DemoLedger) -> bool:
            order = ledger.orders[key]
            if order.state != OrderState.RISK_RESERVED:
                return False
            self._fresh(ledger)
            if self.store.now() >= order.signal.expires_at:
                raise RiskRejected("Expired DEMO signal")
            order.state = OrderState.SUBMITTING
            ledger.requests[order.client_id] = "SUBMITTING"
            return True

        if not self.store.change(self.lease, "DEMO_ENTRY_INTENT", stage):
            return

        def effect(ledger: DemoLedger) -> None:
            order = ledger.orders[key]
            try:
                self._fresh(ledger)
                # Updated market data and metadata, not the original candidate price alone.
                self.refresh_metadata()
                book = self.client.public(
                    "/fapi/v1/ticker/bookTicker", {"symbol": order.signal.symbol}
                )
                mark = self.client.public("/fapi/v1/premiumIndex", {"symbol": order.signal.symbol})
                latest = GateSnapshot.model_validate(
                    order.snapshot.model_dump()
                    | {
                        "market_at": self.store.now(),
                        "bid": book["bidPrice"],
                        "ask": book["askPrice"],
                        "mark": mark["markPrice"],
                    }
                )
                size(
                    ledger.policy,
                    order.signal,
                    latest,
                    ledger.value.equity,
                    self.rules[order.signal.symbol],
                    self.store.now(),
                )
                intent = build_entry(
                    EntryOrder(
                        client_order_id=order.client_id,
                        signal_id=order.signal.signal_id,
                        environment=TradingMode.DEMO,
                        account_id=self.lease.account_id,
                        symbol=order.signal.symbol,
                        side="BUY" if order.signal.direction == "LONG" else "SELL",
                        quantity=order.quantity,
                        limit_price=order.signal.suggested_limit_price,
                    ),
                    self.rules[order.signal.symbol],
                    mark_price=latest.mark,
                )
                self.client.submit(intent)
                ledger.requests[order.client_id] = "ACKNOWLEDGED"
            except DemoRejected:
                order.state, order.remaining = OrderState.REJECTED, ZERO
                ledger.requests[order.client_id] = "REJECTED"
            except (DemoFailure, ValueError):
                order.state = OrderState.UNKNOWN
                ledger.requests[order.client_id] = "UNKNOWN"
            ledger.reconciled = False

        self.store.change(self.lease, "DEMO_ENTRY_EFFECT", effect)
        self.reconcile()

    def disconnect(self) -> None:
        def apply(ledger: DemoLedger) -> None:
            ledger.stream_ready, ledger.reconciled = False, False

        self.store.change(self.lease, "DEMO_STREAM_UNTRUSTED", apply)

    def connected(self) -> None:
        # Call only after verified WSS handshake or pong; REST reconciliation follows.
        def apply(ledger: DemoLedger) -> None:
            ledger.stream_ready, ledger.stream_at = True, self.store.now()
            ledger.reconciled = False

        self.store.change(self.lease, "DEMO_STREAM_CONNECTED", apply)
        self.reconcile()

    def event(self, raw: dict[str, Any]) -> None:
        # Events are invalidation hints; REST truth prevents duplicate/out-of-order fill arithmetic.
        if raw.get("e") not in {
            "ORDER_TRADE_UPDATE",
            "ALGO_UPDATE",
            "ACCOUNT_UPDATE",
            "ACCOUNT_CONFIG_UPDATE",
            "MARGIN_CALL",
            "listenKeyExpired",
            "TRADE_LITE",
        }:
            self.disconnect()
            raise DemoFailure("Unrecognized DEMO private event")
        if raw["e"] == "listenKeyExpired":
            self.disconnect()
            return
        stamp = raw.get("E")
        if (
            type(stamp) is not int
            or not 0 <= int(self.store.now().timestamp() * 1000) - stamp <= 30_000
        ):
            self.disconnect()
            raise DemoFailure("Stale/future DEMO private event")
        self.connected()

    @staticmethod
    def _stop_ok(order: PaperOrder, raw: dict[str, str] | None) -> bool:
        return bool(
            raw
            and raw["clientAlgoId"] == order.algo_id
            and raw["algoType"] == "CONDITIONAL"
            and raw["priceProtect"] == "false"
            and raw["symbol"] == order.signal.symbol
            and raw["side"] == ("SELL" if order.signal.direction == "LONG" else "BUY")
            and raw["orderType"] == "STOP_MARKET"
            and raw["algoStatus"] == "NEW"
            and raw["closePosition"] == "true"
            and raw["positionSide"] == "BOTH"
            and raw["workingType"] == "MARK_PRICE"
            and signed_number(raw["triggerPrice"]) == order.signal.initial_stop_price
        )

    def reconcile(self) -> None:
        try:
            self._reconcile_checked()
        except DemoFailure:

            def failed(ledger: DemoLedger) -> None:
                ledger.reconciled = False
                ledger.paused = True
                for existing in ledger.orders.values():
                    if existing.open_quantity:
                        existing.protected = False
                        existing.position_state = PositionState.OPEN_UNPROTECTED
                # Protection metadata failure must not prevent a minimal position query
                # and a risk-reducing exit for an unprotected managed position.
                try:
                    rows = self.client.request("GET", "/fapi/v3/positionRisk")
                    if not isinstance(rows, list):
                        raise DemoFailure("Invalid emergency position response")
                    for order in ledger.orders.values():
                        if order.position_state == PositionState.CLOSED:
                            continue
                        for row in rows:
                            if (
                                row.get("symbol") != order.signal.symbol
                                or row.get("positionSide") != "BOTH"
                            ):
                                continue
                            amount = signed_number(row["positionAmt"])
                            if (
                                amount
                                and amount * (1 if order.signal.direction == "LONG" else -1) > 0
                                and abs(amount) <= order.quantity
                                and not order.protected
                            ):
                                order.open_quantity = abs(amount)
                                order.average_price = number(row["entryPrice"])
                                order.actual_risk = abs(amount) * order.average_price
                                order.position_state = PositionState.OPEN_UNPROTECTED
                                ledger.risk_state = RiskState.EMERGENCY
                except (DemoFailure, ValueError, KeyError):
                    pass

            self.store.change(self.lease, "DEMO_RECONCILIATION_FAILED", failed)
            if self.store.read(self.lease.account_id).risk_state == RiskState.EMERGENCY:
                self._flatten()
            raise

    def _reconcile_checked(self) -> None:
        self.store.change(
            self.lease, "DEMO_RECONCILING", lambda ledger: setattr(ledger, "reconciled", False)
        )

        def query_merge(ledger: DemoLedger) -> None:
            first = snapshot(self.client, ledger, self.store.now())
            second = snapshot(self.client, ledger, self.store.now())
            if first.fingerprint != second.fingerprint:
                raise DemoFailure("DEMO REST snapshots changed mid-reconciliation")
            self._merge(ledger, second)

        self.store.change(self.lease, "DEMO_REST_SNAPSHOT", query_merge)
        if not self.client.settings.demo_trading_enabled:

            def read_only(ledger: DemoLedger) -> None:
                if any(o.open_quantity and not o.protected for o in ledger.orders.values()):
                    ledger.paused = True
                    ledger.reconciled = False
                    if ledger.risk_state == RiskState.NORMAL:
                        ledger.risk_state = RiskState.UNHEALTHY

            self.store.change(self.lease, "DEMO_READ_ONLY_OBSERVATION", read_only)
            return
        ledger = self.store.read(self.lease.account_id)
        for key, order in ledger.orders.items():
            if (
                order.position_state == PositionState.EXIT_PENDING
                and not order.open_quantity
                and order.remaining
            ):
                self._cancel_only(key)
        ledger = self.store.read(self.lease.account_id)
        for key, order in ledger.orders.items():
            if order.open_quantity and not order.protected:
                self._protect(key, "SL")
            current = self.store.read(self.lease.account_id).orders[key]
            if current.open_quantity and current.protected and current.tp_algo_id is None:
                self._protect(key, "TP")

        def finish(ledger: DemoLedger) -> None:
            actual = snapshot(self.client, ledger, self.store.now())
            self._merge(ledger, actual)
            if any(o.open_quantity and not o.protected for o in ledger.orders.values()):
                ledger.risk_state = RiskState.EMERGENCY
                ledger.reconciled = False

        self.store.change(self.lease, "DEMO_PROTECTION_RECHECK", finish)
        ledger = self.store.read(self.lease.account_id)
        if ledger.risk_state == RiskState.EMERGENCY:
            self._flatten()
        # Flat cleanup is a separate queried/fenced side effect.
        for key, order in self.store.read(self.lease.account_id).orders.items():
            if order.position_state == PositionState.CLOSED:
                self._cleanup(key)

    def _merge(self, ledger: DemoLedger, remote: DemoSnapshot) -> None:
        now = self.store.now()
        if ledger.income_since_ms is None:
            if remote.equity <= 0:
                raise DemoFailure("DEMO account has no positive equity")
            ledger.value = AccountValue(as_of=now, initial=remote.equity)
            ledger.daily_base = ledger.weekly_base = ledger.high_water = remote.equity
            ledger.daily_key, ledger.weekly_key = period_keys(now, ledger.policy.week_start_kst)
            ledger.income_since_ms = int(now.timestamp() * 1000)
        for key, value in remote.transfers.items():
            if key in ledger.income_seen and ledger.income_seen[key] != value:
                raise DemoFailure("DEMO transfer identity conflict")
            if key not in ledger.income_seen:
                ledger.net_transfers += signed_number(value)
                ledger.income_seen[key] = value
        # Exchange equity already includes realized/unrealized/fees/funding; do not double-count income.
        ledger.value = AccountValue(
            as_of=now,
            initial=ledger.value.initial,
            realized=remote.equity - ledger.value.initial - ledger.net_transfers,
            net_deposits=ledger.net_transfers,
        )
        ledger.available_balance, ledger.margin_used = remote.available_balance, remote.margin_used
        ledger.positions = remote.positions
        known_orders = {o.client_id for o in ledger.orders.values()} | {
            o.exit_id for o in ledger.orders.values() if o.exit_id
        }
        known_algos = {a for o in ledger.orders.values() for a in (o.algo_id, o.tp_algo_id) if a}
        mismatch = any(
            k not in known_orders
            and not k.startswith("ALGO_EXEC:")
            and row["status"] in {"NEW", "PARTIALLY_FILLED"}
            for k, row in remote.orders.items()
        )
        mismatch = mismatch or any(
            k not in known_algos and row["algoStatus"] == "NEW" for k, row in remote.algos.items()
        )
        managed_symbols: set[str] = set()
        unresolved = False
        for order in ledger.orders.values():
            row = remote.orders.get(order.client_id)
            if row is None:
                if order.state in {
                    OrderState.SUBMITTING,
                    OrderState.UNKNOWN,
                    OrderState.CANCEL_REQUESTED,
                }:
                    order.state = OrderState.UNKNOWN
                    unresolved = True
                continue
            if (
                row["clientOrderId"] != order.client_id
                or (order.server_order_id is not None and row["orderId"] != order.server_order_id)
                or row["symbol"] != order.signal.symbol
                or row["side"] != ("BUY" if order.signal.direction == "LONG" else "SELL")
                or row["type"] != "LIMIT"
                or row["reduceOnly"] != "false"
                or row["positionSide"] != "BOTH"
                or signed_number(row["origQty"]) != order.quantity
                or signed_number(row["price"]) != order.signal.suggested_limit_price
            ):
                mismatch = True
                continue
            filled = number(row["executedQty"], allow_zero=True)
            if filled < order.filled or filled > order.quantity:
                mismatch = True
                continue
            order.server_order_id = row["orderId"]
            order.filled = filled
            order.state = STATES.get(row["status"], OrderState.UNKNOWN)
            order.remaining = ZERO if order.state in TERMINAL else order.quantity - filled
            if order.state == OrderState.UNKNOWN:
                unresolved = True
            pos = remote.positions.get(order.signal.symbol, ZERO)
            direction = 1 if order.signal.direction == "LONG" else -1
            if order.position_state == PositionState.CLOSED and order.remaining == 0:
                continue  # Historical position; it cannot acquire a later signal's exposure.
            if filled:
                managed_symbols.add(order.signal.symbol)
                expected_closed = False
                if order.exit_id:
                    exit_row = remote.orders.get(order.exit_id)
                    if (
                        exit_row
                        and exit_row["status"] == "FILLED"
                        and exit_row["reduceOnly"] == "true"
                        and exit_row["symbol"] == order.signal.symbol
                        and exit_row["clientOrderId"] == order.exit_id
                        and exit_row["side"] == ("SELL" if direction == 1 else "BUY")
                        and exit_row["positionSide"] == "BOTH"
                        and signed_number(exit_row["executedQty"]) > 0
                    ):
                        expected_closed = True
                        order.exit_state = "FILLED"
                        ledger.requests[order.exit_id] = "FILLED"
                for client_id in [order.algo_id, order.tp_algo_id]:
                    algo = remote.algos.get(client_id or "")
                    if algo and algo["algoStatus"] == "FINISHED":
                        execution = remote.orders.get("ALGO_EXEC:" + algo.get("actualOrderId", ""))
                        if (
                            execution
                            and execution["status"] == "FILLED"
                            and execution["symbol"] == order.signal.symbol
                            and execution["side"] == ("SELL" if direction == 1 else "BUY")
                        ):
                            expected_closed = True
                if pos == 0 and expected_closed and order.remaining:
                    order.open_quantity, order.actual_risk, order.protected = ZERO, ZERO, False
                    order.position_state = PositionState.EXIT_PENDING
                    unresolved = True
                    continue
                if expected_closed and pos:
                    ledger.risk_state = RiskState.EMERGENCY
                if pos == 0 and expected_closed and order.remaining == 0:
                    order.open_quantity, order.actual_risk, order.protected = ZERO, ZERO, False
                    order.position_state = PositionState.CLOSED
                    continue
                if pos * direction < 0 or abs(pos) > filled or (pos == 0 and not expected_closed):
                    mismatch = True
                    unresolved = True
                    order.open_quantity = max(order.open_quantity, filled)
                else:
                    if abs(pos) < filled and not expected_closed:
                        mismatch = True  # Manual partial close is not silently adopted.
                    order.open_quantity = abs(pos)
                order.average_price = number(row["avgPrice"])
                if pos and remote.entry_prices[order.signal.symbol] != order.average_price:
                    mismatch = True
                order.actual_risk = order.open_quantity * unit_loss(
                    ledger.policy, order.average_price, order.signal.initial_stop_price
                )
                order.protected = bool(pos) and self._stop_ok(
                    order, remote.algos.get(order.algo_id or "")
                )
                order.position_state = (
                    PositionState.PROTECTED if order.protected else PositionState.OPEN_UNPROTECTED
                )
                if order.actual_risk + order.pending_risk > order.budget:
                    ledger.risk_state = RiskState.EMERGENCY
            for client_id in [order.algo_id, order.tp_algo_id]:
                if client_id in remote.algos:
                    ledger.algo_server_ids[client_id] = remote.algos[client_id]["algoId"]
            if order.open_quantity and order.protected and order.algo_id:
                ledger.requests[order.algo_id] = "VERIFIED"
            if order.open_quantity and order.tp_algo_id:
                tp = remote.algos.get(order.tp_algo_id)
                valid_tp = bool(
                    tp
                    and tp["clientAlgoId"] == order.tp_algo_id
                    and tp["symbol"] == order.signal.symbol
                    and tp["side"] == ("SELL" if order.signal.direction == "LONG" else "BUY")
                    and tp["algoType"] == "CONDITIONAL"
                    and tp["orderType"] == "TAKE_PROFIT_MARKET"
                    and tp["algoStatus"] == "NEW"
                    and tp["closePosition"] == "true"
                    and tp["positionSide"] == "BOTH"
                    and tp["workingType"] == "MARK_PRICE"
                    and tp["priceProtect"] == "false"
                    and signed_number(tp["triggerPrice"]) == order.signal.target_price
                )
                if valid_tp:
                    ledger.requests[order.tp_algo_id] = "VERIFIED"
                elif not tp or tp["algoStatus"] != "FINISHED":
                    ledger.paused = True
                    unresolved = True

        mismatch = mismatch or any(
            q and symbol not in managed_symbols for symbol, q in remote.positions.items()
        )
        if mismatch and ledger.risk_state not in {
            RiskState.EMERGENCY,
            RiskState.DAILY_LOCK,
            RiskState.WEEKLY_LOCK,
            RiskState.DRAWDOWN_LOCK,
        }:
            ledger.risk_state = RiskState.UNHEALTHY
        if not mismatch and not ledger.orders and ledger.risk_state == RiskState.UNHEALTHY:
            ledger.risk_state = RiskState.NORMAL
        account_risk(ledger, now)
        active = [o for o in ledger.orders.values() if o.remaining or o.open_quantity]
        if active and (
            any(
                remote.leverage.get(o.signal.symbol, ZERO) <= 0
                or remote.leverage[o.signal.symbol] > ledger.policy.limit("max_leverage")
                for o in active
            )
            or remote.equity <= 0
            or sum((o.notional for o in active), ZERO)
            > remote.equity * ledger.policy.limit("max_total_notional_pct") / 100
            or any(
                o.notional > remote.equity * ledger.policy.limit("max_single_notional_pct") / 100
                for o in active
            )
            or remote.margin_used
            > remote.equity * ledger.policy.limit("max_margin_usage_pct") / 100
            or sum((o.actual_risk + o.pending_risk for o in active), ZERO)
            > remote.equity * ledger.policy.limit("max_correlated_risk_pct") / 100
        ):
            ledger.risk_state = RiskState.EMERGENCY
        ledger.fingerprint = remote.fingerprint
        ledger.last_reconciled = now
        ledger.reconciled = (
            not mismatch
            and not unresolved
            and all(not o.open_quantity or o.protected for o in ledger.orders.values())
        )

    def _protect(self, key: str, kind: str) -> None:
        def stage(ledger: DemoLedger) -> str | None:
            order = ledger.orders[key]
            identifier = ("DS-" if kind == "SL" else "DT-") + order.client_id[3:]
            if identifier in ledger.requests:
                return None  # Query the same ID; never repeat an uncertain Algo POST.
            if kind == "SL":
                order.algo_id = identifier
            else:
                order.tp_algo_id = identifier
            ledger.requests[identifier] = "SUBMITTING"
            return identifier

        identifier = self.store.change(self.lease, "DEMO_" + kind + "_INTENT", stage)
        if identifier is None:
            return

        def effect(ledger: DemoLedger) -> None:
            order = ledger.orders[key]
            try:
                protection = AlgoOrder(
                    client_algo_id=identifier,
                    position_id=order.signal.signal_id,
                    environment=TradingMode.DEMO,
                    account_id=self.lease.account_id,
                    symbol=order.signal.symbol,
                    side="SELL" if order.signal.direction == "LONG" else "BUY",
                    order_type="STOP_MARKET" if kind == "SL" else "TAKE_PROFIT_MARKET",
                    trigger_price=order.signal.initial_stop_price
                    if kind == "SL"
                    else order.signal.target_price,
                )
                intent = build_protection(
                    protection, self.rules[order.signal.symbol], working_type="MARK_PRICE"
                )
                # Explicitly avoid priceProtect delaying the stop trigger.
                self.client.request(
                    "POST", intent.path, dict(intent.params) | {"priceProtect": "FALSE"}
                )
                ledger.requests[identifier] = "ACKNOWLEDGED"
            except (DemoFailure, ValueError):
                ledger.requests[identifier] = "UNKNOWN"
                ledger.paused = True
                if kind == "SL":
                    ledger.risk_state = RiskState.EMERGENCY

        self.store.change(self.lease, "DEMO_" + kind + "_EFFECT", effect)
        if kind == "SL":

            def verify(ledger: DemoLedger) -> None:
                self._merge(ledger, snapshot(self.client, ledger, self.store.now()))

            self.store.change(self.lease, "DEMO_SL_VERIFIED_QUERY", verify)

    def cancel(self, key: str) -> None:
        self._cancel_only(key)
        self.reconcile()

    def _cancel_only(self, key: str) -> None:
        def stage(ledger: DemoLedger) -> str | None:
            order = ledger.orders[key]
            if order.state == OrderState.RISK_RESERVED:
                order.state, order.remaining = OrderState.EXPIRED, ZERO
                return None
            if order.state not in TERMINAL:
                order.state = OrderState.CANCEL_REQUESTED
            ledger.reconciled = False
            return order.client_id

        identifier = self.store.change(self.lease, "DEMO_CANCEL_INTENT", stage)
        if identifier is None:
            return

        def effect(ledger: DemoLedger) -> None:
            order = ledger.orders[key]
            try:
                self.client.request(
                    "DELETE",
                    "/fapi/v1/order",
                    {"symbol": order.signal.symbol, "origClientOrderId": identifier},
                )
            except DemoFailure:
                order.state = OrderState.UNKNOWN

        self.store.change(self.lease, "DEMO_CANCEL_EFFECT", effect)

    def _flatten(self) -> None:
        for key, order in self.store.read(self.lease.account_id).orders.items():
            if order.remaining:

                def cancel(ledger: DemoLedger, key: str = key) -> None:
                    current = ledger.orders[key]
                    try:
                        self.client.request(
                            "DELETE",
                            "/fapi/v1/order",
                            {
                                "symbol": current.signal.symbol,
                                "origClientOrderId": current.client_id,
                            },
                        )
                    except DemoFailure:
                        pass

                self.store.change(self.lease, "DEMO_EMERGENCY_CANCEL", cancel)
            if not order.open_quantity or (
                order.exit_id and (order.exit_state != "FILLED" or order.exit_generation >= 3)
            ):
                continue
            generation = order.exit_generation + 1
            identifier = (
                "DX-" + order.client_id[3:] + (("-" + str(generation)) if generation > 1 else "")
            )

            def stage(ledger: DemoLedger, key: str = key, identifier: str = identifier) -> None:
                current = ledger.orders[key]
                current.exit_id, current.exit_state = identifier, "SUBMITTING"
                current.exit_generation += 1
                current.position_state = PositionState.EXIT_PENDING
                ledger.requests[identifier] = "SUBMITTING"

            self.store.change(self.lease, "DEMO_REDUCE_ONLY_INTENT", stage)

            def effect(ledger: DemoLedger, key: str = key, identifier: str = identifier) -> None:
                current = ledger.orders[key]
                try:
                    rows = self.client.request("GET", "/fapi/v3/positionRisk")
                    if not isinstance(rows, list):
                        raise DemoFailure("Invalid emergency position response")
                    matches = [
                        row
                        for row in rows
                        if row.get("symbol") == current.signal.symbol
                        and row.get("positionSide") == "BOTH"
                    ]
                    if len(matches) > 1:
                        raise DemoFailure("Ambiguous emergency position")
                    amount = signed_number(matches[0]["positionAmt"]) if matches else ZERO
                    if (
                        amount == 0
                        or amount * (1 if current.signal.direction == "LONG" else -1) <= 0
                    ):
                        current.exit_state = "UNKNOWN"
                        return
                    self.client.request(
                        "POST",
                        "/fapi/v1/order",
                        {
                            "symbol": current.signal.symbol,
                            "side": "SELL" if amount > 0 else "BUY",
                            "type": "MARKET",
                            "reduceOnly": "true",
                            "quantity": format(abs(amount), "f"),
                            "newClientOrderId": identifier,
                        },
                    )
                    ledger.requests[identifier] = "ACKNOWLEDGED"
                    current.exit_state = "ACKNOWLEDGED"
                except DemoFailure:
                    current.exit_state = "UNKNOWN"
                    ledger.requests[identifier] = "UNKNOWN"

            self.store.change(self.lease, "DEMO_REDUCE_ONLY_EFFECT", effect)

    def _cleanup(self, key: str) -> None:
        def effect(ledger: DemoLedger) -> None:
            order = ledger.orders[key]
            remote = snapshot(self.client, ledger, self.store.now())
            if remote.positions.get(order.signal.symbol, ZERO) != 0:
                return
            if any(
                row["symbol"] == order.signal.symbol
                and row["status"] in {"NEW", "PARTIALLY_FILLED"}
                for row in remote.orders.values()
            ):
                return
            for identifier in [order.algo_id, order.tp_algo_id]:
                raw = remote.algos.get(identifier or "")
                if raw and raw["algoStatus"] == "NEW":
                    try:
                        self.client.request(
                            "DELETE", "/fapi/v1/algoOrder", {"clientAlgoId": identifier or ""}
                        )
                    except DemoFailure:
                        ledger.reconciled = False

        self.store.change(self.lease, "DEMO_VERIFIED_FLAT_CLEANUP", effect)

    def command(self, operation_id: UUID, command: str) -> str:
        if command not in {"PAUSE_ENTRIES", "SAFE_STOP", "EMERGENCY_FLATTEN"}:
            raise ValueError("Invalid DEMO command")

        def stage(ledger: DemoLedger) -> None:
            key = str(operation_id)
            if key in ledger.operations and ledger.operations[key] != command:
                raise ValueError("Conflicting operation ID")
            ledger.operations[key] = command
            ledger.paused = True
            if command == "EMERGENCY_FLATTEN":
                ledger.risk_state = RiskState.EMERGENCY

        self.store.change(self.lease, "DEMO_OPERATION_INTENT", stage)
        if command in {"PAUSE_ENTRIES", "EMERGENCY_FLATTEN"}:
            for key, order in self.store.read(self.lease.account_id).orders.items():
                if order.remaining:
                    self.cancel(key)
        self.reconcile()
        ledger = self.store.read(self.lease.account_id)
        if command == "EMERGENCY_FLATTEN":
            return (
                "VERIFIED_FLAT"
                if ledger.reconciled
                and not any(ledger.positions.values())
                and all(not o.remaining and not o.open_quantity for o in ledger.orders.values())
                else "UNKNOWN"
            )
        return "ENTRIES_BLOCKED"

    def expire(self) -> None:
        for key, order in self.store.read(self.lease.account_id).orders.items():
            if order.remaining and self.store.now() >= order.signal.expires_at:
                self.cancel(key)

    def resume_entries(self, operation_id: UUID) -> str:
        """Explicit CLI operator action; never clears loss/emergency/mismatch locks."""

        def apply(ledger: DemoLedger) -> str:
            key = str(operation_id)
            if key in ledger.operations and ledger.operations[key] != "RESUME_ENTRIES":
                raise ValueError("Conflicting DEMO operation ID")
            if not self.client.settings.demo_trading_enabled:
                raise RiskRejected("DEMO entry mutations disabled")
            account_risk(ledger, self.store.now())
            if (
                ledger.risk_state != RiskState.NORMAL
                or not ledger.reconciled
                or not ledger.stream_ready
            ):
                raise RiskRejected("Resume requires NORMAL risk and reconciled private stream")
            if (
                ledger.last_reconciled is None
                or ledger.stream_at is None
                or any(
                    not 0
                    <= (self.store.now() - at).total_seconds()
                    <= ledger.policy.max_snapshot_age_seconds
                    for at in (ledger.last_reconciled, ledger.stream_at)
                )
            ):
                raise RiskRejected("Resume observation is stale")
            if snapshot(self.client, ledger, self.store.now()).fingerprint != ledger.fingerprint:
                raise RiskRejected("Resume requires unchanged reconciled account")
            ledger.paused = False
            ledger.operations[key] = "RESUME_ENTRIES"
            return "ENTRIES_READY_FOR_NEW_SIGNAL_GATES"

        return self.store.change(self.lease, "DEMO_OPERATOR_RESUME", apply)
