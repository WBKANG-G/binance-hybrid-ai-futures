"""Minimal baseline reproducer; isolated PostgreSQL fixture only, not a Windows probe."""
# ruff: noqa: F811
import asyncio
from uuid import uuid4
import pytest
from packages.persistence.demo_order_quota import LocalQuotaStopped
from tests.integration.test_demo import system as demo_system
from tests.integration.test_managed_order_quota import managed
from tests.integration.test_managed_runtime_assembly import assembly, open_session
from tests.integration.test_quota_startup_review import snapshot
from tests.unit.test_quota_startup_read_only import files

@pytest.mark.parametrize("change", ["live_context", "transport"])
def test_changed_start_context_stops_before_first_transport(assembly, monkeypatch, change):
    store, c, q, clock, w, source, sender, calls, storage, clocks = assembly
    session = open_session(assembly, allow_synthetic_model_execution=True)
    clock.seconds += 70.01
    if change == "live_context":
        monkeypatch.setenv("LIVE_TRADING_ENABLED", "true")
    else:
        session.coordinator.client.send = sender
    before, disk = snapshot(store), files(storage.order_directory)
    try:
        with pytest.raises(LocalQuotaStopped, match="RUNTIME_START_"):
            asyncio.run(session.run(uuid4()))
        assert snapshot(store) == before and files(storage.order_directory) == disk and not calls
    finally:
        session.close()
