@echo off
echo BLOCKED: the prior operation is completed. This package installs a fix only.
exit /b 2
