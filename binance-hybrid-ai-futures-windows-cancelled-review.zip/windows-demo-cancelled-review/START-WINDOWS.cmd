@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo [1/4] Docker Desktop 확인 중...
docker compose version >nul 2>&1
if errorlevel 1 goto missingdocker
docker info >nul 2>&1
if errorlevel 1 goto notrunning
echo [2/4] 실행 설정 확인 중...
docker compose -p hybrid-windows -f infra/docker-compose.yml config --quiet
if errorlevel 1 goto failed
echo [3/4] 설치 및 실행 중. 최초 실행은 인터넷 속도에 따라 오래 걸립니다.
docker compose -p hybrid-windows -f infra/docker-compose.yml up -d --build --wait --wait-timeout 180
if errorlevel 1 goto failed
echo [4/4] 실거래 비활성 및 DB 상태 확인 중...
docker compose -p hybrid-windows -f infra/docker-compose.yml exec -T api python -c "import json,urllib.request; r=json.load(urllib.request.urlopen('http://127.0.0.1:8000/api/v1/system/ready',timeout=10)); assert r['environment']=='PAPER' and r['live_trading_enabled'] is False and r['orders_enabled'] is False and r['database']=='ready'; print('PASS: PAPER, orders disabled, database ready')"
if errorlevel 1 goto failed
echo.
echo 실행 완료. 이 Windows 컴퓨터의 브라우저 주소창에 입력하세요:
echo http://localhost:5173
echo 다음으로 CHECK-DEMO.cmd를 실행하면 키 없이 공개 연결만 확인합니다.
echo 현재 자동매매 및 실거래는 실행되지 않습니다.
pause
exit /b 0
:missingdocker
echo Docker Desktop 설치가 필요합니다. WINDOWS_START_HERE.md를 확인하세요.
pause
exit /b 1
:notrunning
echo Docker Desktop을 열고 Engine running 상태가 된 뒤 다시 실행하세요.
pause
exit /b 1
:failed
echo 실행에 실패했습니다. 이 창의 마지막 오류 부분을 복사해 대화에 보내주세요.
echo API 키나 비밀번호는 보내지 마세요. 보안 설정을 끄지 마세요.
pause
exit /b 1
