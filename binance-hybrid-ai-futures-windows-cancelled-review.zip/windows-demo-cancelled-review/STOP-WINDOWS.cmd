@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo 프로그램을 종료합니다. Windows 개발 DB 데이터는 보존합니다.
docker compose -p hybrid-windows -f infra/docker-compose.yml down
if errorlevel 1 goto failed
echo 종료 완료.
pause
exit /b 0
:failed
echo 종료 실패. 오류 내용을 확인하세요. DB 삭제 명령은 실행하지 마세요.
pause
exit /b 1
