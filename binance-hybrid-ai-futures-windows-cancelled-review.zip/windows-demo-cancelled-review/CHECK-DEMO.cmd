@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
echo Binance DEMO 공개 REST 및 WebSocket 확인. 키 미사용, 주문 없음.
docker compose -p hybrid-windows -f infra/docker-compose.yml exec -T api python -c "import asyncio,json,sys; from scripts.demo_probe import probe; r=asyncio.run(probe()); print(json.dumps(r,indent=2)); sys.exit(0 if r['rest']=='PASS' and r['websocket']=='PASS' else 1)"
if errorlevel 1 goto failed
echo REST 및 WebSocket 모두 PASS입니다. 키 인증 및 DEMO 주문은 아직 검증하지 않았습니다.
pause
exit /b 0
:failed
echo 연결 확인이 완료되지 않았습니다. START-WINDOWS.cmd가 성공했는지 확인하세요.
echo 위 결과를 대화에 보내주세요. API 키는 필요 없습니다.
pause
exit /b 1
