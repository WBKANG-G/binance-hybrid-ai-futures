"""Single, capped operational DEMO validation; explicitly not a strategy signal."""

import asyncio
import json
from datetime import UTC, datetime, timedelta
from decimal import Decimal
from typing import Literal
from uuid import UUID, uuid5

from integrations.binance_usdm.demo import DemoClient, DemoFailure
from integrations.binance_usdm.demo_snapshot import snapshot
from integrations.binance_usdm.filters import number
from packages.domain.contracts import Signal, TradingMode
from services.execution.demo import DemoCoordinator
from services.execution.demo_preview import preview
from services.execution.demo_stream import session
from services.risk.paper import GateSnapshot

MAX_TEST_NOTIONAL = Decimal("100")  # DEMO-only hard ceiling, never LIVE configuration.


def prepare(
    coordinator: DemoCoordinator,
    operation_id: UUID,
    direction: Literal["LONG", "SHORT"],
    *,
    entry_style: Literal["PASSIVE", "OPPOSITE_QUOTE"] = "PASSIVE",
) -> tuple[Signal, GateSnapshot, Decimal]:
    if direction not in {"LONG", "SHORT"}:
        raise DemoFailure("Validation direction must be explicit")
    client = coordinator.client
    ledger = coordinator.store.read(coordinator.lease.account_id)
    if (
        not ledger.stream_ready
        or not ledger.reconciled
        or ledger.last_reconciled is None
        or ledger.risk_state.value != "NORMAL"
    ):
        raise DemoFailure("Validation requires fresh private stream and NORMAL reconciliation")
    observer = DemoClient(
        client.settings.model_copy(update={"demo_trading_enabled": False}),
        client.credentials,
        send=client.send,
        clock_ms=client.clock_ms,
    )
    observer.sync_clock()
    report = preview(observer, ledger, entry_style=entry_style)
    item = next(row for row in report["illustrations"] if row["direction"] == direction)
    if Decimal(item["notional_usdt"]) > MAX_TEST_NOTIONAL:
        raise DemoFailure("Minimum DEMO validation order exceeds 100 USDT test ceiling")
    now_ms = client.clock_ms() + client.offset
    rows = client.public("/fapi/v1/klines", {"symbol": "BTCUSDT", "interval": "1m", "limit": "2"})
    if not isinstance(rows, list):
        raise DemoFailure("Validation closed-candle evidence unavailable")
    closed = []
    for row in rows:
        if (
            not isinstance(row, list)
            or len(row) < 7
            or type(row[0]) is not int
            or type(row[6]) is not int
        ):
            raise DemoFailure("Invalid validation candle response")
        if row[0] % 60000 or row[6] != row[0] + 59999:
            raise DemoFailure("Invalid validation candle interval")
        o, h, low, c = (number(row[i]) for i in range(1, 5))
        if low > min(o, c) or h < max(o, c) or low > h:
            raise DemoFailure("Invalid validation candle prices")
        if 0 < now_ms - row[6] <= 90000:
            closed.append(row[6])
    if not closed or datetime.fromisoformat(report["expires_at"]) <= datetime.fromtimestamp(
        now_ms / 1000, UTC
    ):
        raise DemoFailure("Validation candle/quote evidence expired")
    now = datetime.fromtimestamp(now_ms / 1000, UTC)
    signal = Signal(
        signal_id=operation_id,
        environment=TradingMode.DEMO,
        strategy=None,
        purpose="DEMO_VALIDATION",
        symbol="BTCUSDT",
        direction=direction,
        signal_closed_candle_at=datetime.fromtimestamp(max(closed) / 1000, UTC),
        expires_at=now + timedelta(seconds=10),
        suggested_limit_price=item["limit_price"],
        initial_stop_price=item["assumed_stop_price"],
        target_price=item["assumed_target_price"],
        risk_profile_version=ledger.policy.risk.version,
    )
    # Single-symbol operational check; no AI or claimed trend/breakout decision.
    gate = GateSnapshot(
        market_at=datetime.fromisoformat(report["as_of"]),
        account_at=ledger.last_reconciled,
        correlation_at=ledger.last_reconciled,
        bid=report["bid"],
        ask=report["ask"],
        mark=report["mark"],
        correlation_group="SINGLE_BTC_DEMO_VALIDATION",
        evaluation="RULES_ONLY",
    )
    return signal, gate, Decimal(item["execution_quantity_cap"])


async def validate_once(
    coordinator: DemoCoordinator,
    operation_id: UUID,
    direction: Literal["LONG", "SHORT"],
    *,
    observation_seconds: float = 30,
    entry_style: Literal["PASSIVE", "OPPOSITE_QUOTE"] = "PASSIVE",
) -> None:
    """Keep the private supervisor active, then cancel residual entry and verify flat.

    Reusing the operation ID recovers the same durable intent; it never creates a new entry.
    Session cancellation starts only after entry preparation/submission has returned.
    """
    if (
        not coordinator.client.settings.demo_trading_enabled
        or coordinator.client.settings.margin_mode != "ISOLATED"
        or coordinator.client.settings.symbols != ("BTCUSDT",)
        or direction not in {"LONG", "SHORT"}
        or entry_style not in {"PASSIVE", "OPPOSITE_QUOTE"}
    ):
        raise DemoFailure("Validation requires explicit enabled ISOLATED BTCUSDT context")
    store, lease = coordinator.store, coordinator.lease
    key = str(operation_id)
    original = store.read(lease.account_id)
    if any(k != key and (o.remaining or o.open_quantity) for k, o in original.orders.items()):
        raise DemoFailure("Another active DEMO intent prevents validation")
    if key in original.orders and (
        original.orders[key].signal.purpose != "DEMO_VALIDATION"
        or original.orders[key].signal.direction != direction
        or original.validation_entry_styles.get(key, "PASSIVE") != entry_style
    ):
        raise DemoFailure("Validation operation ID conflict")
    if key not in original.orders and (
        not original.reconciled
        or original.risk_state.value != "NORMAL"
        or any(original.positions.values())
    ):
        raise DemoFailure("New validation requires an empty reconciled NORMAL account")
    loop = asyncio.get_running_loop()
    callback_done = asyncio.Event()
    failure = False

    def on_ready() -> None:
        try:
            current = store.read(lease.account_id)
            if key not in current.orders:
                coordinator.resume_entries(uuid5(operation_id, "resume"))
                signal, gate, cap = prepare(
                    coordinator, operation_id, direction, entry_style=entry_style
                )
                order = coordinator.reserve(signal, gate, quantity_cap=cap, entry_style=entry_style)
                print(
                    json.dumps(
                        dict(
                            validation="RESERVED_NOT_YET_SUBMITTED",
                            environment="DEMO",
                            operation_id=key,
                            purpose="DEMO_VALIDATION",
                            entry_style=entry_style,
                            direction=direction,
                            quantity=str(order.quantity),
                            quantity_cap=str(cap),
                            limit_price=str(signal.suggested_limit_price),
                            stop_price=str(signal.initial_stop_price),
                            target_price=str(signal.target_price),
                            live_trading_enabled=False,
                        )
                    ),
                    flush=True,
                )
                coordinator.submit(key)
            else:
                print(
                    json.dumps(
                        dict(
                            validation="RECOVER_EXISTING_INTENT",
                            operation_id=key,
                            live_trading_enabled=False,
                        )
                    ),
                    flush=True,
                )
        finally:
            loop.call_soon_threadsafe(callback_done.set)

    task = asyncio.create_task(session(coordinator, on_ready=on_ready))
    done = asyncio.create_task(callback_done.wait())
    try:
        await asyncio.wait({task, done}, return_when=asyncio.FIRST_COMPLETED)
        if task.done():
            await task  # Propagate connection/setup failures before reporting success.
        else:
            finished, _ = await asyncio.wait({task}, timeout=observation_seconds)
            if finished:
                await task
    except Exception:
        failure = True  # Never include raw private session errors or URLs in output.
    finally:
        done.cancel()
        if not task.done():
            task.cancel()
        try:
            await task
        except (asyncio.CancelledError, Exception):
            pass
    # No automatic POST retry. The stable flatten operation queries any UNKNOWN exit.
    result = "UNKNOWN"
    try:
        await asyncio.to_thread(
            coordinator.command, uuid5(operation_id, "finish-pause"), "PAUSE_ENTRIES"
        )
        before_exit = await asyncio.to_thread(store.read, lease.account_id)
        if any(before_exit.positions.values()) or any(
            o.open_quantity for o in before_exit.orders.values()
        ):
            result = await asyncio.to_thread(
                coordinator.command, uuid5(operation_id, "finish"), "EMERGENCY_FLATTEN"
            )
        else:
            result = (
                "VERIFIED_FLAT"
                if all(not o.remaining for o in before_exit.orders.values())
                else "UNKNOWN"
            )
        final = await asyncio.to_thread(store.read, lease.account_id)
        remote = await asyncio.to_thread(snapshot, coordinator.client, final, store.now())
        # A close acknowledgement is not a fill. Only after a fresh snapshot
        # proves zero exposure may the same durable operation reconcile/clean up.
        if (
            result == "UNKNOWN"
            and not any(remote.positions.values())
            and not any(
                row["status"] in {"NEW", "PARTIALLY_FILLED"} for row in remote.orders.values()
            )
        ):
            result = await asyncio.to_thread(
                coordinator.command, uuid5(operation_id, "finish"), "EMERGENCY_FLATTEN"
            )
            final = await asyncio.to_thread(store.read, lease.account_id)
            remote = await asyncio.to_thread(snapshot, coordinator.client, final, store.now())
        if (
            any(remote.positions.values())
            or any(row["status"] in {"NEW", "PARTIALLY_FILLED"} for row in remote.orders.values())
            or any(row["algoStatus"] == "NEW" for row in remote.algos.values())
        ):
            result = "UNKNOWN"
    except Exception:
        result = "UNKNOWN"
    final = store.read(lease.account_id)
    order = final.orders.get(key)
    evidence = final.validation_evidence.get(key, {})
    acceptance = bool(
        order
        and order.filled
        and evidence.get("stop_verified")
        and evidence.get("target_verified")
        and result == "VERIFIED_FLAT"
        and not failure
    )
    print(
        json.dumps(
            dict(
                validation="FINISHED_FLAT"
                if result == "VERIFIED_FLAT"
                else "UNRESOLVED_DO_NOT_REPEAT",
                environment="DEMO",
                operation_id=key,
                entry_filled=bool(order and order.filled),
                filled_quantity=str(order.filled) if order else "0",
                entry_state=order.state.value if order else "NOT_CREATED",
                position_state=order.position_state.value if order else "NOT_CREATED",
                entry_outcome=(
                    "FULL_FILL"
                    if order and order.filled == order.quantity
                    else "PARTIAL_FILL"
                    if order and order.filled
                    else "UNFILLED"
                ),
                stop_verified=final.validation_evidence.get(key, {}).get("stop_verified", False),
                target_verified=final.validation_evidence.get(key, {}).get(
                    "target_verified", False
                ),
                filled_protection_and_flat_verified=acceptance,
                session_error=failure,
                live_trading_enabled=False,
            )
        ),
        flush=True,
    )
    if result != "VERIFIED_FLAT" or failure or order is None or (order.filled and not acceptance):
        raise DemoFailure(
            "DEMO validation incomplete; inspect sanitized state and recover with the same operation ID"
        )
