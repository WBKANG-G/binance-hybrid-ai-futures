"""DEMO-only ledger and strictly parsed exchange observations (never credentials)."""

from datetime import datetime
from decimal import Decimal
from typing import Literal

from pydantic import Field

from packages.domain.config import NonNegativeDecimal, PositiveDecimal
from services.execution.models import Ledger, State
from services.risk.paper import DemoPolicy


class DemoLedger(Ledger):
    mode: Literal["DEMO"] = "DEMO"
    policy: DemoPolicy
    stream_ready: bool = False
    stream_at: datetime | None = None
    fingerprint: str = ""
    available_balance: NonNegativeDecimal = Decimal(0)
    margin_used: NonNegativeDecimal = Decimal(0)
    positions: dict[str, Decimal] = Field(default_factory=dict)
    algo_server_ids: dict[str, str] = Field(default_factory=dict)
    income_seen: dict[str, str] = Field(default_factory=dict)
    net_transfers: Decimal = Decimal(0)
    income_since_ms: int | None = None
    requests: dict[str, str] = Field(default_factory=dict)
    margin_mode: Literal["CROSSED", "ISOLATED"] = "CROSSED"
    symbols: tuple[str, ...] = ()
    margin_types: dict[str, str] = Field(default_factory=dict)
    verified_leverage: dict[str, Decimal] = Field(default_factory=dict)
    isolated_wallets: dict[str, Decimal] = Field(default_factory=dict)
    isolated_margins: dict[str, Decimal] = Field(default_factory=dict)
    entry_quantity_caps: dict[str, PositiveDecimal] = Field(default_factory=dict)
    validation_evidence: dict[str, dict[str, bool]] = Field(default_factory=dict)
    validation_entry_styles: dict[str, Literal["PASSIVE", "OPPOSITE_QUOTE"]] = Field(
        default_factory=dict
    )


class DemoSnapshot(State):
    as_of: datetime
    equity: Decimal
    available_balance: Decimal
    margin_used: Decimal
    positions: dict[str, Decimal]
    entry_prices: dict[str, Decimal]
    leverage: dict[str, Decimal]
    orders: dict[str, dict[str, str]]
    algos: dict[str, dict[str, str]]
    fingerprint: str
    transfers: dict[str, str] = Field(default_factory=dict)
    margin_types: dict[str, str] = Field(default_factory=dict)
    isolated_wallets: dict[str, Decimal] = Field(default_factory=dict)
    isolated_margins: dict[str, Decimal] = Field(default_factory=dict)
    liquidation_prices: dict[str, Decimal] = Field(default_factory=dict)
