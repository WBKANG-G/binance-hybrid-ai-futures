import json
from tempfile import TemporaryDirectory
from uuid import uuid4
from pathlib import Path
from datetime import UTC, datetime, timedelta
from packages.persistence.demo_shared_weight import SharedWeightJournal, STARTUP_HOLD, WINDOW
from services.execution.demo_managed_runtime import OwnedSharedBudget, assemble_managed_runtime
from packages.persistence.demo_order_quota import LocalQuotaStopped
seconds=[0.0]
with TemporaryDirectory() as directory:
    b=SharedWeightJournal.create(Path(directory),'DEMO-smoke',uuid4(),monotonic=lambda: seconds[0],wall_clock=lambda: datetime(2026,11,10,tzinfo=UTC)+timedelta(seconds=seconds[0]),boot=lambda:'smoke')
    seconds[0]=STARTUP_HOLD
    token=b.reserve(2,'ORDINARY')
    b.finish_unobserved(token,status=200)
    assert b.view()['pressure']==2 and b.view()['pending_attempts']==0
    seconds[0]+=WINDOW+0.001
    assert b.view()['pressure']==0
assert not OwnedSharedBudget._observes_weight(None,'GET','/fapi/v1/ticker/bookTicker')
assert OwnedSharedBudget._observes_weight(None,'GET','/fapi/v1/time')
try:
    assemble_managed_runtime(None,None,None,None,None)
    raise AssertionError('execution enabled')
except LocalQuotaStopped as error:
    assert str(error)=='RUNTIME_REAL_EXECUTION_DISABLED'
print(json.dumps(dict(smoke='PASSED',network='NONE',modeled_cost_retained=True,unobserved_completion_has_no_weight_floor=True,quote_header_excluded=True,default_execution_refused=True,actual_exchange_requests=0)))
