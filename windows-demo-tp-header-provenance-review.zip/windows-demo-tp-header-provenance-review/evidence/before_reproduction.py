"""Non-authoritative quote headers must not replace trustworthy observations."""

# ruff: noqa: F811
import pytest
from pydantic import SecretStr

from integrations.binance_usdm.rest import RESTResponse
from tests.integration.test_demo import system as demo_system  # noqa: F401
from tests.integration.test_managed_order_quota import managed  # noqa: F401
from tests.integration.test_managed_runtime_assembly import assembly, open_session  # noqa: F401


@pytest.mark.parametrize("header", ["0", "999999", None, "invalid", "-1"])
def test_quote_header_cannot_refresh_or_replace_previous_weight_observation(assembly, header):
    store, c, q, clock, w, source, sender, calls, storage, clocks = assembly
    original_headers = {} if header is None else {"x-mbx-used-weight-1m": header}
    quote = RESTResponse(200, b"{}", original_headers)

    def send(method, path, query, key):
        return (
            quote
            if path == "/fapi/v1/ticker/bookTicker"
            else RESTResponse(200, b"{}", {"x-mbx-used-weight-1m": "600"})
        )

    args = list(assembly)
    args[6] = send
    session = open_session(args, allow_synthetic_model_execution=True)
    b = session.budget
    b.clock = clock.mono
    b("GET", "/fapi/v1/time", SecretStr(""), None)
    b.configure(
        {
            "rateLimits": [
                {
                    "rateLimitType": "REQUEST_WEIGHT",
                    "interval": "MINUTE",
                    "intervalNum": 1,
                    "limit": 6000,
                },
                {"rateLimitType": "ORDERS", "interval": "SECOND", "intervalNum": 10, "limit": 300},
                {"rateLimitType": "ORDERS", "interval": "MINUTE", "intervalNum": 1, "limit": 1200},
            ]
        }
    )
    b.preflight()
    previous = (b.header_weight, b.header_charge, b.header_at, b.header_sequence)
    clock.seconds += 1
    try:
        result = b("GET", "/fapi/v1/ticker/bookTicker", SecretStr("symbol=BTCUSDT"), None)
        assert result is quote and result.headers is original_headers
        assert (b.header_weight, b.header_charge, b.header_at, b.header_sequence) == previous
        assert not b.untrusted and not b.stopped
        assert b.total_charge == 3
        assert b.shared.read_only_snapshot()["pressure"] == 602
    finally:
        session.close()

