import json
from types import SimpleNamespace
from integrations.binance_usdm.demo import DemoFailure
from integrations.binance_usdm.demo_tp_admission import TPModelProfile
from packages.persistence.demo_order_quota import LocalQuotaStopped
from services.execution.demo_managed_runtime import assemble_managed_runtime
from services.execution.demo_runtime_observation import RuntimeObservationCoordinator
for entry in ['connected','_wait_for_observation_credit','_require_owned_flat_observation']:
 coordinator=object.__new__(RuntimeObservationCoordinator)
 coordinator.session_failed=True
 coordinator._require_confirmation_bindings=lambda:None
 coordinator._observation_clock=lambda:0.0
 coordinator.admission_budget=SimpleNamespace(profile=TPModelProfile(0),WATCH=128)
 try:
  getattr(coordinator,entry)()
 except DemoFailure as error:
  assert 'session failed' in str(error)
 else:
  raise AssertionError('failed session continued observation')
try:
 assemble_managed_runtime(None,None,None,None,None)
except LocalQuotaStopped as error:
 assert str(error)=='RUNTIME_REAL_EXECUTION_DISABLED'
else:
 raise AssertionError('execution enabled')
print(json.dumps(dict(smoke='PASSED',network='NONE',scope='FAILED_SESSION_PRECONDITION_WITH_STUBBED_BINDING_AND_DEFAULT_REFUSAL',entrypoints_checked=3,actual_exchange_requests=0,execution_approved=False)))
