"""Explicit operator review of flat DEMO emergencies. Never submits exchange writes."""

import hashlib
import json
from uuid import UUID

from integrations.binance_usdm.demo import DemoClient, DemoFailure, DemoNotFound
from integrations.binance_usdm.demo_snapshot import snapshot
from packages.domain.contracts import OrderState, RiskState
from packages.persistence.demo import DemoStore
from services.execution.demo_models import DemoLedger
from services.execution.models import Lease
from services.execution.paper import account_risk
from services.risk.paper import AccountValue


def review(store: DemoStore, client: DemoClient, ledger: DemoLedger) -> dict[str, object]:
    if (
        client.settings.demo_trading_enabled
        or client.settings.margin_mode != "ISOLATED"
        or client.settings.symbols != ("BTCUSDT",)
        or ledger.margin_mode != "ISOLATED"
        or ledger.symbols != ("BTCUSDT",)
        or ledger.policy != client.settings.policy
    ):
        raise DemoFailure("Recovery requires read-only isolated BTCUSDT DEMO context")
    if ledger.risk_state != RiskState.EMERGENCY or not ledger.paused:
        raise DemoFailure("Recovery applies only to paused EMERGENCY")
    if any(ledger.positions.values()) or any(
        o.remaining
        or o.open_quantity
        or o.state
        not in {OrderState.FILLED, OrderState.CANCELED, OrderState.REJECTED, OrderState.EXPIRED}
        for o in ledger.orders.values()
    ):
        raise DemoFailure("Local exposure or nonterminal entry prevents recovery")
    first = snapshot(client, ledger, store.now())
    second = snapshot(client, ledger, store.now())
    if first.fingerprint != second.fingerprint:
        raise DemoFailure("Recovery snapshots changed")
    if (
        any(second.positions.values())
        or any(r["status"] in {"NEW", "PARTIALLY_FILLED"} for r in second.orders.values())
        or any(r["algoStatus"] == "NEW" for r in second.algos.values())
    ):
        raise DemoFailure("Exchange exposure or active orders prevent recovery")
    if second.leverage.get("BTCUSDT") != 2 or second.transfers != ledger.income_seen:
        raise DemoFailure("Recovery settings/transfers require separate reconciliation")
    # Reevaluate loss gates without modifying accounting baselines or the old lock.
    probe = ledger.model_copy(deep=True)
    probe.value = AccountValue(
        as_of=store.now(),
        initial=ledger.value.initial,
        realized=second.equity - ledger.value.initial - ledger.net_transfers,
        net_deposits=ledger.net_transfers,
    )
    probe.risk_state = RiskState.NORMAL
    account_risk(probe, store.now())
    if probe.risk_state != RiskState.NORMAL:
        raise DemoFailure("Loss/day-boundary/risk gate prevents recovery")
    observations: dict[str, str] = {}
    if len(ledger.requests) > 30:
        raise DemoFailure("Too many requests for bounded recovery")
    for identifier in ledger.requests:
        kind = identifier.split("-", 1)[0]
        if kind not in {"DE", "DX", "DS", "DT"}:
            raise DemoFailure("Unsupported historical request prevents recovery")
        algo = kind in {"DS", "DT"}
        try:
            raw = client.request(
                "GET",
                "/fapi/v1/algoOrder" if algo else "/fapi/v1/order",
                {"clientAlgoId": identifier}
                if algo
                else {"symbol": "BTCUSDT", "origClientOrderId": identifier},
            )
        except DemoNotFound:
            observations[identifier] = "NOT_FOUND_UNRESOLVED"
            continue
        if (
            not isinstance(raw, dict)
            or raw.get("symbol") != "BTCUSDT"
            or raw.get("clientAlgoId" if algo else "clientOrderId") != identifier
        ):
            raise DemoFailure("Historical request identity mismatch")
        status = raw.get("algoStatus" if algo else "status")
        allowed = (
            {"CANCELED", "EXPIRED", "FINISHED", "REJECTED"}
            if algo
            else {"FILLED", "CANCELED", "EXPIRED", "EXPIRED_IN_MATCH", "REJECTED"}
        )
        if status not in allowed:
            raise DemoFailure("Active/unknown historical request prevents recovery")
        observations[identifier] = str(status)
    final = snapshot(client, ledger, store.now())
    if final.fingerprint != second.fingerprint:
        raise DemoFailure("Recovery changed during request audit")
    stable = ledger.model_dump(mode="json", exclude={"reconciled", "stream_ready"})
    token = hashlib.sha256(
        json.dumps(
            {"ledger": stable, "exchange": second.fingerprint, "observations": observations},
            sort_keys=True,
            separators=(",", ":"),
        ).encode()
    ).hexdigest()
    return {
        "review_token": token,
        "unresolved_count": sum(v == "NOT_FOUND_UNRESOLVED" for v in observations.values()),
        "risk_gates": "PASS",
        "position_nonzero": False,
        "active_orders": 0,
        "orders_enabled": False,
        "live_trading_enabled": False,
    }


def acknowledge_flat_emergency(
    store: DemoStore,
    lease: Lease,
    client: DemoClient,
    operation_id: UUID,
    expected_token: str,
    *,
    acknowledge_unresolved: bool,
) -> str:
    if not acknowledge_unresolved or len(expected_token) != 64:
        raise DemoFailure("Explicit operator acknowledgement and review token required")

    def apply(ledger: DemoLedger) -> str:
        key = str(operation_id)
        if key in ledger.recovery_receipts:
            if ledger.recovery_receipts[key] != expected_token:
                raise DemoFailure("Recovery operation ID conflict")
            return "ALREADY_RECORDED_NO_ACTION"
        if key in ledger.operations:
            raise DemoFailure("Recovery operation ID conflict")
        result = review(store, client, ledger)
        if result["review_token"] != expected_token:
            raise DemoFailure("Recovery review changed; no state updated")
        ledger.recovery_receipts[key] = expected_token
        ledger.operations[key] = "ACKNOWLEDGE_FLAT_EMERGENCY"
        ledger.risk_state = RiskState.NORMAL
        ledger.paused = True
        ledger.reconciled = False
        ledger.stream_ready = False
        # requests, orders, no-send evidence, accounting and old events stay intact.
        return "EMERGENCY_ACKNOWLEDGED_ENTRIES_STILL_PAUSED"

    return store.change(lease, "DEMO_OPERATOR_ACKNOWLEDGED_FLAT_EMERGENCY", apply)
