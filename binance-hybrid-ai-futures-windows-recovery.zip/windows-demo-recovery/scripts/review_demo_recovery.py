"""Read-only recovery review by default. Explicit apply never sends an exchange write."""

import argparse
import getpass
import json
import os
import warnings
from pathlib import Path
from uuid import UUID, uuid4

import yaml
from sqlalchemy import create_engine

from integrations.binance_usdm.demo import DemoClient, DemoCredentials, DemoFailure, DemoSettings
from packages.domain.config import UniqueKeyLoader, database_url
from packages.persistence.demo import DemoStore
from services.execution.demo_recovery import acknowledge_flat_emergency, review
from services.risk.paper import RiskRejected


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--apply-review")
    parser.add_argument("--operation-id", type=UUID)
    parser.add_argument("--acknowledge-unresolved-history", action="store_true")
    args = parser.parse_args()
    if (
        os.getenv("LIVE_TRADING_ENABLED", "false").lower() != "false"
        or os.getenv("TRADING_MODE", "PAPER") == "LIVE"
    ):
        parser.error("LIVE context forbidden")
    if (
        bool(args.apply_review) != bool(args.operation_id)
        or bool(args.apply_review) != args.acknowledge_unresolved_history
    ):
        parser.error(
            "Apply requires review token, operation ID and explicit history acknowledgement together"
        )
    engine = None
    lease = None
    store = None
    try:
        warnings.simplefilter("error", getpass.GetPassWarning)
        os.environ["BINANCE_DEMO_API_KEY"] = getpass.getpass("DEMO API Key (hidden): ")
        os.environ["BINANCE_DEMO_API_SECRET"] = getpass.getpass("DEMO Secret (hidden): ")
        cfg = DemoSettings.model_validate(
            yaml.load(
                Path("configs/demo-isolated.example.yaml").read_text(), Loader=UniqueKeyLoader
            )
        ).model_copy(update={"demo_trading_enabled": False})
        client = DemoClient(cfg, DemoCredentials.from_environment())
        client.sync_clock()
        engine = create_engine(
            database_url().get_secret_value(), connect_args={"connect_timeout": 2}
        )
        store = DemoStore(engine)
        account = "DEMO-WINDOWS-ISOLATED-BTC-V1"
        if args.apply_review:
            lease = store.acquire(account, uuid4())
            result = acknowledge_flat_emergency(
                store,
                lease,
                client,
                args.operation_id,
                args.apply_review,
                acknowledge_unresolved=args.acknowledge_unresolved_history,
            )
            print(
                json.dumps(
                    {"recovery": result, "orders_enabled": False, "live_trading_enabled": False}
                )
            )
        else:
            before = store.read(account)
            report = review(store, client, before)
            if store.read(account) != before:
                raise DemoFailure("Database changed during review")
            print(
                json.dumps(
                    {
                        "recovery": "REVIEW_ONLY_NO_DATABASE_CHANGE",
                        **report,
                        "risk_state": before.risk_state.value,
                        "paused": before.paused,
                    }
                )
            )
    except (DemoFailure, RiskRejected, ValueError):
        raise SystemExit(
            "Recovery review blocked; keep lock and share this status only. No automatic retry."
        ) from None
    finally:
        os.environ.pop("BINANCE_DEMO_API_KEY", None)
        os.environ.pop("BINANCE_DEMO_API_SECRET", None)
        if lease is not None and store is not None:
            store.release(lease)
        if engine is not None:
            engine.dispose()


if __name__ == "__main__":
    main()
