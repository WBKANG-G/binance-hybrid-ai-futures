"""Bounded receipt validation and coalescing of REST-invalidation hints.

No fill arithmetic or account state is derived from these messages. Every frame
is checked; only known, fresh hints share one later strict REST reconciliation.
"""

import asyncio
import json
from collections.abc import Callable
from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Protocol

from integrations.binance_usdm.demo import DemoFailure
from services.execution.demo_models import PrivateSessionDiagnostic
from services.execution.demo_session_diagnostics import (
    EVENT_KINDS,
    EventKind,
    event_info,
    failure_diagnostic,
)

MAX_PENDING_EVENTS = 128


class Receiver(Protocol):
    async def recv(self) -> str | bytes: ...


@dataclass(frozen=True)
class ReceivedHint:
    kind: EventKind
    stamp: int
    receive_age_ms: int

    def event(self) -> dict[str, Any]:
        return {"e": self.kind, "E": self.stamp}


class EventInbox:
    def __init__(self, now_ms: Callable[[], int], failed: Callable[[], None]):
        self.now_ms, self.failed = now_ms, failed
        self.wakeup = asyncio.Event()
        self.latest: ReceivedHint | None = None
        self.pending = 0
        self.received = 0
        self.coalesced = 0
        self.failure: PrivateSessionDiagnostic | None = None

    def raise_if_failed(self) -> None:
        if self.failure is not None:
            raise DemoFailure("DEMO private receiver failed; entries blocked")

    async def run(self, websocket: Receiver) -> None:
        detail = PrivateSessionDiagnostic(stage="RECEIVE")
        try:
            while True:
                detail = PrivateSessionDiagnostic(stage="RECEIVE")
                message = await websocket.recv()
                self.received = min(1000000000, self.received + 1)
                if len(message) > 1048576:
                    raise DemoFailure("DEMO private event oversized")
                detail.stage = "PARSE"

                def reject_constant(value: str) -> Any:
                    raise ValueError("Non-finite event")

                raw = json.loads(message, parse_float=Decimal, parse_constant=reject_constant)
                if not isinstance(raw, dict):
                    raise DemoFailure("Invalid DEMO event object")
                now = self.now_ms()
                detail.event_kind, detail.event_age_ms = event_info(raw, now)
                detail.event_receive_age_ms = detail.event_age_ms
                detail.stage = "EVENT"
                kind = raw.get("e")
                if not isinstance(kind, str) or kind not in EVENT_KINDS:
                    raise DemoFailure("Unrecognized DEMO private event")
                if kind == "listenKeyExpired":
                    raise DemoFailure("DEMO private listen key expired")
                stamp = raw.get("E")
                # This is the same 30-second/non-future bound as event(). A
                # representative is checked again by unmodified event() later.
                if type(stamp) is not int or not 0 <= now - stamp <= 30000:
                    raise DemoFailure("Stale/future DEMO private event")
                if self.pending >= MAX_PENDING_EVENTS:
                    raise DemoFailure("DEMO private event inbox overflow")
                hint = ReceivedHint(detail.event_kind, stamp, now - stamp)
                self.pending += 1
                if self.latest is None or stamp >= self.latest.stamp:
                    self.latest = hint
                self.wakeup.set()
        except Exception as error:
            self.failure = failure_diagnostic(error, detail)
            self.failed()  # In-memory admission gate; never races DB cleanup.
            self.wakeup.set()

    async def take(self, timeout: float = 5) -> ReceivedHint:
        self.raise_if_failed()
        await asyncio.wait_for(self.wakeup.wait(), timeout=timeout)
        self.raise_if_failed()
        hint = self.latest
        if hint is None:
            raise DemoFailure("DEMO private event inbox empty")
        self.coalesced = min(1000000000, self.coalesced + max(0, self.pending - 1))
        self.latest = None
        self.pending = 0
        self.wakeup.clear()
        return hint
