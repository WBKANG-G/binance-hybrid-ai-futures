import json,subprocess,sys
from tempfile import TemporaryDirectory
from pathlib import Path
with TemporaryDirectory() as directory:
    for mode,status in [('tp',0),('partial',0),('seal_failure',3)]:
        source='/tmp/receipt-'+mode+'.json'
        issued=subprocess.run([sys.executable,'-m','scripts.review_runtime_confirmation_report',source],capture_output=True,text=True)
        assert issued.returncode==status and not issued.stderr
        receipt=Path(directory)/(mode+'-receipt.json');receipt.write_text(issued.stdout)
        verified=subprocess.run([sys.executable,'-m','scripts.review_runtime_confirmation_report',source,'--verify-receipt',str(receipt)],capture_output=True,text=True)
        value=json.loads(verified.stdout)
        assert verified.returncode==status and not verified.stderr and value['receipt_matches_input']
        assert not value['execution_approved'] and not value['receipt_authenticity_verified']
    receipt=Path(directory)/'tp-receipt.json'
    changed=Path(directory)/'changed.json';changed.write_bytes(Path('/tmp/receipt-tp.json').read_bytes()+b'\n')
    refused=subprocess.run([sys.executable,'-m','scripts.review_runtime_confirmation_report',str(changed),'--verify-receipt',str(receipt)],capture_output=True,text=True)
    assert refused.returncode==2 and json.loads(refused.stdout)['code']=='RECEIPT_INPUT_MISMATCH'
print(json.dumps(dict(smoke='PASSED',network='NONE',scope='SAVED_SYNTHETIC_REPORT_RECEIPT_ROUNDTRIPS_ONLY',saved_report_roundtrips=3,changed_input_refused=True,fresh_financial_lifecycle_run=False,actual_exchange_requests=0,execution_approved=False)))
