import json
from types import SimpleNamespace
from integrations.binance_usdm.demo_tp_admission import TPModelProfile
from packages.persistence.demo_order_quota import LocalQuotaStopped
from services.execution.demo_runtime_capacity import capacity_plan, require_runtime_capacity
from services.execution.demo_runtime_confirmation import RuntimeConfirmationCoordinator
from services.execution.demo_managed_runtime import assemble_managed_runtime
for history in range(129):
 p=TPModelProfile(history)
 c=object.__new__(RuntimeConfirmationCoordinator)
 c.admission_budget=SimpleNamespace(profile=p)
 plan=capacity_plan(p)
 assert plan['proof_batch_weight']==c.proof_batch and not plan['execution_approved']
 try:
  require_runtime_capacity(p)
 except LocalQuotaStopped as e:
  assert history>=6 and str(e)=='RUNTIME_PROOF_BATCH_CANNOT_FIT'
 else:
  assert history<=5
try:
 assemble_managed_runtime(None,None,None,None,None)
except LocalQuotaStopped as e:
 assert str(e)=='RUNTIME_REAL_EXECUTION_DISABLED'
else:
 raise AssertionError('execution unexpectedly enabled')
print(json.dumps(dict(smoke='PASSED',network='NONE',scope='SYNTHETIC_EMPTY_WINDOW_FEASIBILITY_AND_DEFAULT_REFUSAL',history_profiles_checked=129,six_history=capacity_plan(TPModelProfile(6)),actual_exchange_requests=0,execution_approved=False)))
