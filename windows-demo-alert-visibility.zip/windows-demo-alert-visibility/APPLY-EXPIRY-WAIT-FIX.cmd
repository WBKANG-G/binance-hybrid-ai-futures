@echo off
setlocal
cd /d "%~dp0"
docker exec hybrid-windows-api-1 python -m scripts.check_demo_session_ready
if errorlevel 1 exit /b 1
docker compose -p hybrid-windows -f infra/docker-compose.yml up -d --build --no-deps --wait api
if errorlevel 1 exit /b 1
docker exec hybrid-windows-api-1 python -c "import hashlib; from pathlib import Path; from services.execution import demo_stream; actual=hashlib.sha256(Path(demo_stream.__file__).read_bytes()).hexdigest(); assert actual == '409098cb05abbfb97eb9b9f1db2070ca6bb5782bc6dd7542311e4eb703b6f456', 'SOURCE_HASH_MISMATCH'; print('EXPIRY_WAIT_FIX_SOURCE_VERIFIED')"
if errorlevel 1 exit /b 1
docker exec hybrid-windows-api-1 python -m scripts.check_demo_session_ready
exit /b %errorlevel%
