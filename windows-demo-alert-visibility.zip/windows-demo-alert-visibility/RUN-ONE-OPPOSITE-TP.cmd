@echo off
setlocal
cd /d "%~dp0"
if exist opposite-tp-result.log (
  echo BLOCKED: previous result log exists. No repeat execution.
  exit /b 2
)
echo This command updates only API and submits at most ONE OPPOSITE_QUOTE DEMO LIMIT entry.
echo Maximum BTC quantity 0.0007 and notional 100 USDT. No LIVE trading.
docker exec hybrid-windows-api-1 python -m scripts.check_demo_session_ready
if errorlevel 1 exit /b 2
docker compose -p hybrid-windows -f infra/docker-compose.yml up -d --build --no-deps --wait api
if errorlevel 1 exit /b 2
docker exec hybrid-windows-api-1 python -c "import hashlib; from pathlib import Path; expected={'scripts/check_demo_tp_trigger.py': '40522b50012be16fb6a888d67645bc72572d7da7c24b58f4b2b87f8edf9c7018', 'services/execution/demo_tp_trigger_check.py': '6b82ce5947480f87a58c194628853322496c90545a47713f4e07dd1fc0414dc8', 'services/execution/demo_validation.py': 'd703860caf01135b3f5e82a444adc5afde1795e1f4d48bbd515cc4b9de5666a0', 'scripts/capture_demo_wss_hints.py': 'a0c2ad6f8e853646a9cfd56fcbe3c068805937ee0254a63b56d78c2b19c2fa09'}; assert all(hashlib.sha256(Path(n).read_bytes()).hexdigest()==h for n,h in expected.items()), 'SOURCE_HASH_MISMATCH'; print('OPPOSITE_TP_REVIEW_SOURCE_VERIFIED')"
if errorlevel 1 exit /b 2
docker exec hybrid-windows-api-1 python -m scripts.check_demo_session_ready
if errorlevel 1 exit /b 2
docker exec hybrid-windows-api-1 python -m scripts.check_demo_tp_trigger --enable-demo --enable-tp-trigger-observation --entry-style OPPOSITE_QUOTE --enable-opposite-quote-tp-observation --operation-id 243598bb-900a-45d5-8af3-a776d543a504 > opposite-tp-result.log
set "TP_CHECK_EXIT=%errorlevel%"
type opposite-tp-result.log
exit /b %TP_CHECK_EXIT%
