"""Private DEMO WSS supervision. Events invalidate state; REST establishes truth."""

import asyncio
import json
import logging
from collections.abc import Callable
from contextlib import AbstractAsyncContextManager
from datetime import timedelta
from decimal import Decimal
from typing import Any, Protocol
from uuid import uuid4

from pydantic import SecretStr
from websockets.asyncio.client import connect

from integrations.binance_usdm.demo import WS_HOST, DemoFailure
from services.execution.demo import DemoCoordinator


class Connection(Protocol):
    async def recv(self) -> str | bytes: ...
    async def ping(self) -> Any: ...


def private_connect(url: SecretStr) -> AbstractAsyncContextManager[Connection]:
    value = url.get_secret_value()
    if not value.startswith(WS_HOST + "/private/ws/"):
        raise ValueError("DEMO private URL must remain isolated")
    logger = logging.Logger("demo-private-redacted")
    logger.disabled = True
    return connect(
        value,
        open_timeout=5,
        close_timeout=2,
        max_size=1_048_576,
        ping_interval=20,
        ping_timeout=10,
        logger=logger,
    )


async def session(
    coordinator: DemoCoordinator,
    *,
    connector: Callable[[SecretStr], AbstractAsyncContextManager[Connection]] = private_connect,
    on_ready: Callable[[], None] | None = None,
    max_messages: int | None = None,
) -> None:
    """One session. Caller may restart after backoff; a reconnect always reconciles first."""
    store, lease, client = coordinator.store, coordinator.lease, coordinator.client
    key = store.change(lease, "DEMO_SESSION_CREATE", lambda ledger: client.listen_key("POST"))
    if key is None:
        raise DemoFailure("DEMO private session unavailable")
    renewed = store.now()
    try:
        async with connector(client.private_url(key)) as websocket:
            await asyncio.to_thread(coordinator.connected)
            if on_ready:
                await asyncio.to_thread(store.renew, lease)
                await asyncio.to_thread(client.sync_clock)
                await asyncio.to_thread(on_ready)
            count = 0
            while max_messages is None or count < max_messages:
                await asyncio.to_thread(store.renew, lease)
                await asyncio.to_thread(client.sync_clock)
                if store.now() - renewed >= timedelta(minutes=25):
                    await asyncio.to_thread(
                        store.change,
                        lease,
                        "DEMO_SESSION_RENEW",
                        lambda ledger: client.listen_key("PUT"),
                    )
                    renewed = store.now()
                try:
                    message = await asyncio.wait_for(websocket.recv(), timeout=5)
                    if len(message) > 1_048_576:
                        raise DemoFailure("DEMO private event oversized")

                    def reject_constant(value: str) -> Any:
                        raise ValueError("Non-finite event")

                    raw = json.loads(message, parse_float=Decimal, parse_constant=reject_constant)
                    if not isinstance(raw, dict):
                        raise DemoFailure("Invalid DEMO event object")
                    await asyncio.to_thread(coordinator.event, raw)
                    count += 1
                except TimeoutError:
                    pong = await websocket.ping()
                    await asyncio.wait_for(pong, timeout=5)
                    await asyncio.to_thread(coordinator.connected)
                await asyncio.to_thread(coordinator.expire)
    except Exception:
        try:
            await asyncio.to_thread(coordinator.disconnect)
        except Exception:
            pass  # Durable leader acquisition also invalidates stream readiness.
        raise DemoFailure("DEMO private connection/session failed; entries blocked") from None
    finally:
        # Session closure never cancels SL/TP. Fencing prevents a stale worker deleting a new leader's key.
        try:
            await asyncio.to_thread(client.sync_clock)
            await asyncio.to_thread(coordinator.command, uuid4(), "PAUSE_ENTRIES")
        except Exception:
            pass
        try:
            await asyncio.to_thread(coordinator.disconnect)
            await asyncio.to_thread(
                store.change,
                lease,
                "DEMO_SESSION_CLOSE",
                lambda ledger: client.listen_key("DELETE"),
            )
        except Exception:
            pass
