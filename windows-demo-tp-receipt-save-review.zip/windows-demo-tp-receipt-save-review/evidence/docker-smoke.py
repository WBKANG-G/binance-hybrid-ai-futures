import hashlib,json,subprocess,sys
from pathlib import Path
from tempfile import TemporaryDirectory
with TemporaryDirectory() as directory:
 for mode,status in [('tp',0),('partial',0),('seal_failure',3)]:
  source=Path('/tmp')/(mode+'.json');raw=source.read_bytes();receipt=Path(directory)/(mode+'-receipt.json')
  def run(*args):
   r=subprocess.run([sys.executable,'-m','scripts.review_runtime_confirmation_report',str(source),*map(str,args)],capture_output=True,text=True)
   assert not r.stderr
   return r.returncode,json.loads(r.stdout),r.stdout
  code,value,stdout=run('--save-receipt',receipt)
  assert code==status and receipt.read_text()==stdout and not value['execution_approved']
  saved=receipt.read_bytes()
  code,value,_=run('--verify-receipt',receipt)
  assert code==status and value['receipt_matches_input'] and not value['execution_approved']
  code,value,_=run('--save-receipt',receipt)
  assert code==2 and value['code']=='OUTPUT_ALREADY_EXISTS' and receipt.read_bytes()==saved
  code,value,_=run('--save-receipt',source)
  assert code==2 and value['code']=='OUTPUT_IS_INPUT' and source.read_bytes()==raw
print(json.dumps(dict(smoke='PASSED',network='NONE',scope='OFFLINE_EXCLUSIVE_RECEIPT_SAVE_ONLY',saved_report_roundtrips=3,existing_receipts_and_sources_preserved=True,fresh_financial_lifecycle_run=False,actual_exchange_requests=0,execution_approved=False)))
