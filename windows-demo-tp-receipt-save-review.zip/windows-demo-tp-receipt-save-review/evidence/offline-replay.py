import hashlib,json,subprocess,zipfile
from pathlib import Path
archive=Path('/tmp/downloaded-review-receipt-review.zip')
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='771ca65fb981014864414be954ae30e13e90f130c45eac4e1405716d576887d3'
root='windows-demo-tp-review-receipt-review/'
out=Path('/tmp/receipt-save-replay');out.mkdir(exist_ok=True)
python='/workspace/windows-transfer/phase4-review/review-venv/bin/python'
def run(source,*args):
 r=subprocess.run([python,'-m','scripts.review_runtime_confirmation_report',str(source),*map(str,args)],capture_output=True,text=True)
 assert not r.stderr
 return r.returncode,json.loads(r.stdout),r.stdout
records=[]
with zipfile.ZipFile(archive) as z:
 proof=json.loads(z.read(root+'SOURCE_PROOF.json'));assert proof['source_commit']=='e136c1a89ac3f8ebdc7a3629ed956228527a8aad'
 prior=json.loads(z.read(root+'evidence/saved_report_replay/REPLAY_VALIDATION.json'))
 for mode in ['tp','partial','seal_failure']:
  raw=z.read(root+'evidence/saved_report_replay/'+mode+'.json')
  digest=hashlib.sha256(raw).hexdigest();assert digest==next(x['input_sha256'] for x in prior['records'] if x['mode']==mode)
  source=out/(mode+'.json');source.write_bytes(raw);receipt=out/(mode+'-receipt.json')
  status,value,stdout=run(source,'--save-receipt',receipt)
  expected=3 if mode=='seal_failure' else 0
  assert status==expected and receipt.read_text()==stdout and not value['execution_approved']
  saved=receipt.read_bytes()
  status,value,stdout=run(source,'--verify-receipt',receipt)
  assert status==expected and value['receipt_matches_input']
  (out/(mode+'-verification.json')).write_text(stdout)
  status,value,stdout=run(source,'--save-receipt',receipt)
  assert status==2 and value['code']=='OUTPUT_ALREADY_EXISTS' and receipt.read_bytes()==saved
  (out/(mode+'-overwrite-rejection.json')).write_text(stdout)
  status,value,stdout=run(source,'--save-receipt',source)
  assert status==2 and value['code']=='OUTPUT_IS_INPUT' and source.read_bytes()==raw
  (out/(mode+'-input-rejection.json')).write_text(stdout)
  records.append(dict(mode=mode,input_sha256=digest,input_bytes=len(raw),save_exit_status=expected,verification_exit_status=expected,receipt_matches_input=True,existing_receipt_preserved=True,input_preserved=True,execution_approved=False))
 for name in ['previous-lifecycle.xml','previous-seal.xml']:
  (out/name).write_bytes(z.read(root+'evidence/saved_report_replay/'+name))
(out/'REPLAY_VALIDATION.json').write_text(json.dumps(dict(status='PASSED_OFFLINE_EXCLUSIVE_SAVE_REPLAY_ONLY',input_artifact_commit='d2307352d739d172dba02b4842c6cbfafd61d3f0',input_archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),input_source_commit=proof['source_commit'],financial_lifecycle_source_commit=prior['financial_lifecycle_source_commit'],records=records,previous_lifecycle_junit_reused_not_rerun=True,fresh_financial_lifecycle_execution_performed=False,actual_exchange_requests=0),indent=2)+'\n')
print(json.dumps(dict(saved_and_verified=3,existing_receipt_rejections=3,same_input_rejections=3,source_bytes_preserved=True,new_financial_lifecycle=False)))
