"""A latched hard stop must precede shared reservations and order authorization."""

# ruff: noqa: F811
from urllib.parse import urlencode

import pytest
from pydantic import SecretStr

from integrations.binance_usdm.demo import DemoFailure
from integrations.binance_usdm.demo_tp_window_budget import weight_scope
from integrations.binance_usdm.rest import RESTResponse
from tests.integration.test_demo import system as demo_system  # noqa: F401
from tests.integration.test_managed_order_quota import managed  # noqa: F401
from tests.integration.test_managed_runtime_assembly import assembly  # noqa: F401
from tests.integration.test_quota_startup_review import snapshot
from tests.integration.test_runtime_header_provenance import prepared
from tests.unit.test_quota_startup_read_only import files

ROUTES = [
    ("GET", "/fapi/v1/time", {}),
    ("GET", "/fapi/v1/ticker/bookTicker", {"symbol": "BTCUSDT"}),
    ("GET", "/fapi/v3/positionRisk", {}),
    (
        "POST",
        "/fapi/v1/order",
        {
            "symbol": "BTCUSDT",
            "side": "BUY",
            "type": "LIMIT",
            "timeInForce": "GTC",
            "quantity": "0.0007",
            "price": "100",
            "newClientOrderId": "DE-test",
        },
    ),
    ("DELETE", "/fapi/v1/listenKey", {}),
]


def wire(method, path, params):
    if path in {"/fapi/v1/time", "/fapi/v1/ticker/bookTicker"}:
        return SecretStr(urlencode(params)), None
    if path == "/fapi/v1/listenKey":
        return SecretStr(""), SecretStr("synthetic-key")
    return SecretStr(
        urlencode(dict(params, timestamp="1000000", recvWindow="5000", signature="0" * 64))
    ), SecretStr("synthetic-key")


@pytest.mark.parametrize('lane', ['ORDINARY', 'WATCH', 'RESCUE', 'PROOF'])
@pytest.mark.parametrize('method,path,params', ROUTES)
def test_latched_clock_stop_rejects_without_new_reservation_or_authorization(assembly, monkeypatch, lane, method, path, params):
    calls = []

    def send(method, path, query, key):
        calls.append(path)
        return RESTResponse(200, b'{', {'x-mbx-used-weight-1m': '600'})
    session, b = prepared(assembly, send)
    c = session.coordinator.client
    c.clock_ms = lambda: 1000000
    try:
        with pytest.raises(DemoFailure):
            c.sync_clock()
        assert b.untrusted and b.stopped
        before = (snapshot(assembly[0]), files(assembly[8].order_directory), files(b.shared.directory))
        weight = b.shared.read_only_snapshot()
        sent = list(calls)
        authorization = []
        original = b.bridge.authorize

        def authorize(*args, **kwargs):
            authorization.append(True)
            return original(*args, **kwargs)
        monkeypatch.setattr(b.bridge, 'authorize', authorize)
        query, key = wire(method, path, params)
        with weight_scope(lane), pytest.raises(DemoFailure):
            b(method, path, query, key)
        assert snapshot(assembly[0]) == before[0]
        assert files(assembly[8].order_directory) == before[1]
        assert files(b.shared.directory) == before[2]
        assert b.shared.read_only_snapshot() == weight
        assert not authorization and calls == sent
        assert b.reason == 'RUNTIME_CLOCK_REFRESH_FAILED'
    finally:
        session.close()
