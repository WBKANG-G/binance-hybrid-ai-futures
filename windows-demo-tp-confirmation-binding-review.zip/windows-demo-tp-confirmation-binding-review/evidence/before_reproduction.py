"""Confirmation bindings reject before the first scheduler side effect."""

# ruff: noqa: F811
import asyncio
from types import SimpleNamespace

import pytest
from pydantic import SecretStr

from integrations.binance_usdm.demo import DemoCredentials
from packages.persistence.demo_order_quota import LocalQuotaStopped
from tests.integration.test_demo import system as demo_system  # noqa: F401
from tests.integration.test_managed_order_quota import managed  # noqa: F401
from tests.integration.test_managed_runtime_assembly import assembly  # noqa: F401
from tests.integration.test_quota_startup_review import snapshot
from tests.integration.test_runtime_confirmation_deadline import scheduler
from tests.unit.test_quota_startup_read_only import files

FAULTS = [
    "store",
    "lease",
    "client",
    "budget",
    "bridge",
    "proxy_bridge",
    "proxy_engine",
    "bridge_store",
    "journal",
    "credentials",
    "settings",
    "costs",
    "provider",
]


def change(c, fault, state):
    b = c.admission_budget
    if fault == "store":
        c.store = SimpleNamespace(renew=lambda lease: state["calls"].append("foreign_renew"))
    elif fault == "lease":
        c.lease = c.lease.model_copy(update={"fence": c.lease.fence + 1})
    elif fault == "client":
        c.client = SimpleNamespace(sync_clock=lambda: state["calls"].append("foreign_clock"))
    elif fault == "budget":
        c.admission_budget = SimpleNamespace(
            clock=lambda: 0,
            _fresh=lambda now: True,
            flat_observed=True,
            profile=b.profile,
            require_proof=lambda cost: state["calls"].append("foreign_admit"),
        )
    elif fault == "bridge":
        c.quota_bridge = object()
    elif fault == "proxy_bridge":
        c.store.bridge = object()
    elif fault == "proxy_engine":
        c.store.engine = object()
    elif fault == "bridge_store":
        c.quota_bridge.store = object()
    elif fault == "journal":
        c.quota_bridge.journal = object()
    elif fault == "credentials":
        c.client.credentials = DemoCredentials(
            SecretStr("synthetic-key"), SecretStr("synthetic-secret")
        )
    elif fault == "settings":
        c.client.settings = c.client.settings.model_copy(update={"symbols": ("ETHUSDT",)})
    elif fault == "costs":
        b.costs[("GET", "/fapi/v1/time")] = 999
    elif fault == "provider":
        b.shared.scope = "DEMO-changed"


@pytest.mark.parametrize('fault', FAULTS)
def test_changed_confirmation_context_stops_before_renewal_or_new_records(assembly, monkeypatch, fault):
    session, c, state = scheduler(assembly, monkeypatch, 'normal')
    before = (snapshot(assembly[0]), files(assembly[8].order_directory), files(session.budget.shared.directory))
    change(c, fault, state)
    try:
        with pytest.raises(LocalQuotaStopped):
            asyncio.run(c.confirm_exit_budgeted())
        assert not state['calls'] and (not state['sleeps'])
        assert snapshot(assembly[0]) == before[0]
        assert files(assembly[8].order_directory) == before[1]
        assert files(session.budget.shared.directory) == before[2]
    finally:
        session.close()
