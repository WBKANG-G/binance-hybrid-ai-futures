import hashlib,json
from tempfile import TemporaryDirectory
from uuid import uuid4
from pathlib import Path
from datetime import UTC,datetime
from integrations.binance_usdm.demo_tp_admission import TPModelProfile
from integrations.binance_usdm.demo_tp_weight_model import MODELED_TP_ROUTE_COSTS
from packages.persistence.demo_shared_weight import SharedWeightJournal
from packages.persistence.demo_order_quota import LocalQuotaStopped
from services.execution.demo_managed_runtime import OwnedSharedBudget,assemble_managed_runtime
calls=[]
def send(*args):
    calls.append(True)
    raise AssertionError('unexpected transport')
with TemporaryDirectory() as directory:
    j=SharedWeightJournal.create(Path(directory),'DEMO-smoke',uuid4(),monotonic=lambda:0.0,wall_clock=lambda:datetime(2026,11,10,tzinfo=UTC),boot=lambda:'smoke')
    b=OwnedSharedBudget(send,TPModelProfile(0),MODELED_TP_ROUTE_COSTS,bridge=None,shared=j,allow_synthetic_model_execution=True)
    before=hashlib.sha256(j.path.read_bytes()).hexdigest()
    b.check_confirmation_context()
    b.costs[('GET','/fapi/v1/time')]=999
    try:
        b.check_confirmation_context()
        raise AssertionError('changed model admitted')
    except LocalQuotaStopped as error:assert str(error)=='RUNTIME_MODEL_BINDING_CHANGED'
    b.revoke()
    try:
        b.check_confirmation_context()
        raise AssertionError('revoked context admitted')
    except LocalQuotaStopped as error:assert str(error)=='RUNTIME_CLOSED'
    assert not calls and hashlib.sha256(j.path.read_bytes()).hexdigest()==before
try:
    assemble_managed_runtime(None,None,None,None,None)
    raise AssertionError('execution enabled')
except LocalQuotaStopped as error:assert str(error)=='RUNTIME_REAL_EXECUTION_DISABLED'
print(json.dumps(dict(smoke='PASSED',network='NONE',scope='BUDGET_CONTEXT_GATE_ONLY_SQLITE_NO_COORDINATOR_OR_ORDER_BRIDGE',changed_model_refused=True,revoked_context_refused=True,journal_hash_unchanged=True,default_execution_refused=True,actual_exchange_requests=0)))
