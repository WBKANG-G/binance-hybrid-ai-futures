import asyncio,json
from threading import Event
from services.execution.demo_runtime_confirmation import ConfirmationClaim
from services.execution.demo_stream import settled_call
from services.execution.demo_managed_runtime import assemble_managed_runtime
from packages.persistence.demo_order_quota import LocalQuotaStopped
claim=ConfirmationClaim()
entered,release,finished=Event(),Event(),Event()
def work():
    entered.set()
    try:
        assert release.wait(5)
    finally:
        finished.set()
async def owner():
    assert claim.claim()
    try:
        await settled_call(work)
    finally:
        claim.finish()
async def check():
    task=asyncio.create_task(owner())
    try:
        assert await asyncio.to_thread(entered.wait,5)
        task.cancel()
        try:
            await asyncio.wait_for(asyncio.shield(task),0.05)
            raise AssertionError('cancellation finished before worker')
        except TimeoutError:pass
        assert not finished.is_set() and not claim.close()
        release.set()
        try:
            await task
            raise AssertionError('cancellation lost')
        except asyncio.CancelledError:pass
        assert finished.is_set() and claim.close() and not claim.claim()
    finally:
        release.set()
        await asyncio.gather(task,return_exceptions=True)
asyncio.run(check())
try:
    assemble_managed_runtime(None,None,None,None,None)
    raise AssertionError('execution enabled')
except LocalQuotaStopped as error:assert str(error)=='RUNTIME_REAL_EXECUTION_DISABLED'
print(json.dumps(dict(smoke='PASSED',network='NONE',scope='BLOCKED_FAKE_WORKER_AND_CLAIM_NO_DATABASE_OR_ORDER_BRIDGE',cancel_waited_for_worker=True,close_refused_until_worker_settled=True,closed_claim_cannot_start=True,default_execution_refused=True,actual_exchange_requests=0)))
