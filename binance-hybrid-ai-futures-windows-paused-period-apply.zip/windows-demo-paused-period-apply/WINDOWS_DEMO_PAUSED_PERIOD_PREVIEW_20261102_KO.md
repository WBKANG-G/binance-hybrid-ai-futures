# 실제 NORMAL/paused 일간·주간 후보 확인

사용자 CMD 결과에 근거한다. 배포 windows-demo-paused-period-preview-20261102 / c97240ce5bff0687ce0c2662102ba5899b871f35, 부모 ZIP SHA256 702413cc2eb35a51171b61a8bfbd49e170163d86c6f162f325851bf8d4e43a31.

api/db/web/key-session/alerts 모두 Healthy였다. 사용자는 DEMO 키를 숨김 입력했고, 출력은 PAUSED_NORMAL_PERIOD_PREVIEW_NO_DATABASE_CHANGE였다. 키 값이나 입력 화면 원본은 저장하지 않는다.

- source OPERATOR_ATTESTED_FLAT_PERIODS_WITH_SIGNED_USDT_EVIDENCE.
- review_token bcf38c1998320344e9c03411b83a9369b152bfcaa76f50fb23438fc89cdf7a1c.
- 이전 일간2026-11-01 / 4999.03492670 USDT.
- 이전 주간2026-10-26 / 4999.64804199 USDT.
- 후보 일간·주간 기준일 모두2026-11-02.
- 후보 일간·주간 기준금 모두4998.99761493 USDT.
- 두 경계 모두2026-11-01T15:00:00+00:00.
- anchor_utc2026-11-01T01:55:09.565889+00:00.
- signed_evidence_until_utc2026-11-02T07:47:42.380767+00:00.
- post_anchor_btc_trades0 / post_anchor_income_records0 / net_deposit_basis_usdt0.
- NORMAL/paused, database_changed false, preview_only true.
- 고점·이전 평가 시각·요청·위험 상태 보존 true.
- account_wide_exchange_export_verified/unresolved_requests_acknowledged/recovery_eligible/orders_enabled/live_trading_enabled false.
- POOLED_HTTPS, HTTP170회/연결1회/재사용169회/서버 close0회, 10152ms.
- signed GET167회 / clock probe3회.

사용자가 새로 확인한 다른 활동 없음과 기존 서명 검사에 근거한 후보 수락이다. 자정 잔고 직접 관측이나 계좌 전체 export 검증이 아니다. 미리보기만으로 기준금이 바뀐 것은 아니다. 적용 시 같은 토큰·전체 서명 증거를 다시 검사하며 실패하면 변경하지 않는다. 이후 활동이나 날짜/잔고/장부 변화가 생기면 예전 후보를 강제로 적용하지 않는다. 현재 Windows 실제 적용은 아직 확인 전이다.
