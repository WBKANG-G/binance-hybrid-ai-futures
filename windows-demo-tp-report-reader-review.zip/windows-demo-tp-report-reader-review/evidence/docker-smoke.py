import json,subprocess,sys
from tempfile import TemporaryDirectory
from pathlib import Path
for mode,status in [('tp',0),('partial',0),('seal_failure',3)]:
    result=subprocess.run([sys.executable,'-m','scripts.review_runtime_confirmation_report','/tmp/reader-'+mode+'.json'],capture_output=True,text=True)
    assert result.returncode==status and not result.stderr
    value=json.loads(result.stdout)
    assert not value['execution_approved'] and value['next_action']=='KEEP_PAUSED_REVIEW_ONLY'
with TemporaryDirectory() as directory:
    data=json.loads(Path('/tmp/reader-tp.json').read_text())
    data['confirmation_scheduler']['execution_approved']=True
    p=Path(directory)/'invalid.json';p.write_text(json.dumps(data))
    result=subprocess.run([sys.executable,'-m','scripts.review_runtime_confirmation_report',str(p)],capture_output=True,text=True)
    assert result.returncode==2 and not json.loads(result.stdout)['execution_approved']
print(json.dumps(dict(smoke='PASSED',network='NONE',scope='PREVIOUS_SYNTHETIC_REPORT_REPLAY_ONLY',saved_report_cli_cases=4,fresh_financial_lifecycle_run=False,actual_exchange_requests=0,execution_approved=False)))
