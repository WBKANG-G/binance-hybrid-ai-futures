import json
from types import SimpleNamespace
from services.execution.demo_runtime_confirmation import RuntimeConfirmationCoordinator,ConfirmationClaim
from services.execution.demo_managed_runtime import assemble_managed_runtime
from packages.persistence.demo_order_quota import LocalQuotaStopped
# Report-state fixture only: this does not run or establish a signed flat proof.
c=object.__new__(RuntimeConfirmationCoordinator)
c._confirmation_claim=ConfirmationClaim()
assert c._confirmation_claim.claim()
c._confirmation_claim.finish()
c._confirmation_bridge=SimpleNamespace(degraded=True)
c.budgeted_flat_confirmation='VERIFIED_FLAT'
c.quota_seal_failed=c.session_failed=True
c.confirmation_attempts_completed=1
c.confirmation_binding_rejections=c.confirmation_deferrals=0
c.confirmation_stop_reason='ORIGINAL_PROOF_VERIFIED'
r=c.confirmation_diagnostics()
assert r['reported_outcome']=='PROOF_VERIFIED_QUOTA_SEAL_FAILED'
assert not r['execution_approved'] and not r['quota_seal_verified_from_records']
assert r['next_action']=='KEEP_PAUSED_REVIEW_ONLY'
try:
    assemble_managed_runtime(None,None,None,None,None)
    raise AssertionError('execution enabled')
except LocalQuotaStopped as error:assert str(error)=='RUNTIME_REAL_EXECUTION_DISABLED'
print(json.dumps(dict(smoke='PASSED',network='NONE',scope='REPORT_STATE_FIXTURE_ONLY_NO_FINANCIAL_PROOF',seal_failure_distinguished=True,execution_approved=False,default_execution_refused=True,actual_exchange_requests=0)))
