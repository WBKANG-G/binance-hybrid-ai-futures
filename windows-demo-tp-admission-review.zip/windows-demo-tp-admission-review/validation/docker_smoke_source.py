import json,sys,types,time
source=sys.stdin.read()
m=types.ModuleType('admission_bundle_smoke');sys.modules[m.__name__]=m
exec(compile(source,'review_tp_entry_admission.py','exec'),m.__dict__)
m.verify_installed_sources()
import yaml
from pathlib import Path
from pydantic import SecretStr
cfg=m.DemoSettings.model_validate(yaml.load(Path('configs/demo-isolated.example.yaml').read_text(),Loader=m.UniqueKeyLoader)).model_copy(update={'demo_trading_enabled':False})
results=[]
for mode in ('body','header','missing'):
 calls=[]
 rows=[{'rateLimitType':'ORDERS','interval':'SECOND','intervalNum':10,'limit':300},{'rateLimitType':'ORDERS','interval':'MINUTE','intervalNum':1,'limit':1200}]
 def send(method,path,query,key):
  assert method=='GET' and path in m.PROBE_PATHS
  calls.append(path)
  headers={'x-mbx-used-weight-1m':str(len(calls))}
  if path=='/fapi/v1/time':body={'serverTime':1000000}
  elif path=='/fapi/v1/exchangeInfo':body={'rateLimits':[{'rateLimitType':'REQUEST_WEIGHT','interval':'MINUTE','intervalNum':1,'limit':6000}]+rows}
  else:
   body=[dict(r) for r in rows]
   if mode=='body':
    for row in body:row['count']=0
   if mode=='header':headers|={'x-mbx-order-count-10s':'0','x-mbx-order-count-1m':'0'}
  return m.RESTResponse(200,json.dumps(body).encode(),headers)
 monitor=m.AdmissionReadMonitor(send)
 client=m.AdmissionReadClient(cfg,m.DemoCredentials(SecretStr('synthetic-key'),SecretStr('synthetic-secret')),send=monitor,clock_ms=lambda:1000000)
 report=m.review_admission(client,monitor)
 assert len(calls)==4 and not report['execution_approved'] and report['order_writes']==0
 if mode=='missing':
  assert report['order_quota_evidence']=='LIMITS_VERIFIED_USAGE_UNAVAILABLE'
  assert all(r['first_count'] is None for r in report['windows'])
 else:assert report['order_quota_evidence']=='SAMPLED_HEADROOM_FITS'
 results.append({'mode':mode,'calls':len(calls),'evidence':report['order_quota_evidence'],'execution_approved':False,'counter_sources':[r['first_counter_source'] for r in report['windows']]})
print(json.dumps({'installed_source_pins_verified':55,'network':'none','database_accessed':False,'actual_exchange_requests':0,'order_writes':0,'results':results}))
