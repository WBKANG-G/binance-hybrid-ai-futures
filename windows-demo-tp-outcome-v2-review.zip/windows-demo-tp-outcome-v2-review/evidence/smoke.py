import json,subprocess,sys
from pathlib import Path
from tempfile import TemporaryDirectory
with TemporaryDirectory() as folder:
 for mode,status in [('tp',0),('partial',3),('seal_failure',3),('receiver_failure',3)]:
  source=Path('/tmp')/(mode+'.json');raw=source.read_bytes();receipt=Path(folder)/(mode+'.json')
  base=[sys.executable,'-m','scripts.review_runtime_outcomes',str(source)]
  issued=subprocess.run(base+['--save-receipt',str(receipt)],capture_output=True,text=True)
  assert issued.returncode==status and not issued.stderr and receipt.read_text()==issued.stdout
  checked=subprocess.run(base+['--verify-receipt',str(receipt)],capture_output=True,text=True)
  result=json.loads(checked.stdout)
  assert checked.returncode==status and result['receipt_matches_input'] and not result['execution_approved']
  if mode=='receiver_failure':
   assert result['original_trial_flat_confirmation']=='UNKNOWN' and result['later_returned_flat_confirmation']=='VERIFIED_FLAT'
   assert not result['original_trial_reported_accepted'] and result['attention_required']
  old=subprocess.run([sys.executable,'-m','scripts.review_runtime_confirmation_report',str(source)],capture_output=True,text=True)
  assert old.returncode==(2 if mode=='receiver_failure' else 3 if mode=='seal_failure' else 0)
  cross=subprocess.run([sys.executable,'-m','scripts.review_runtime_confirmation_report',str(source),'--verify-receipt',str(receipt)],capture_output=True,text=True)
  assert cross.returncode==2
  assert source.read_bytes()==raw
print(json.dumps(dict(smoke='PASSED',network='NONE',scope='OFFLINE_V2_OUTCOME_AND_RECEIPT_ROUNDTRIPS_ONLY',saved_reports=4,v1_rejection_and_cross_policy_separation_preserved=True,fresh_financial_lifecycle_execution_performed=False,actual_exchange_requests=0,execution_approved=False)))
