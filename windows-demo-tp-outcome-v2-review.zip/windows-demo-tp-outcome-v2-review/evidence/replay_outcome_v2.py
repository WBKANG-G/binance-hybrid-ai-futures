import hashlib,json,subprocess,zipfile
from pathlib import Path
archive=Path('/tmp/downloaded-observation-stop-review.zip')
assert hashlib.sha256(archive.read_bytes()).hexdigest()=='eef51d240ca7555a9c03f0309bf840b3136dda3ac68e1c6b0a82d8cd3f06a259'
out=Path('/tmp/outcome-v2-replay');out.mkdir(exist_ok=True)
python='/workspace/windows-transfer/phase4-review/review-venv/bin/python'
records=[]
with zipfile.ZipFile(archive) as z:
 root='windows-demo-tp-observation-stop-review/'
 assert json.loads(z.read(root+'SOURCE_PROOF.json'))['source_commit']=='94c47d86568e785c04a82dd95aeb5f05736e9da0'
 for mode in ['tp','partial','seal_failure','receiver_failure']:
  raw=z.read(root+'evidence/fresh_lifecycle_reports/'+mode+'.json')
  source=out/(mode+'.json');source.write_bytes(raw)
  v1=[python,'-m','scripts.review_runtime_confirmation_report',str(source)]
  old=subprocess.run(v1,capture_output=True,text=True)
  expected_old=2 if mode=='receiver_failure' else 3 if mode=='seal_failure' else 0
  assert old.returncode==expected_old and not old.stderr
  (out/(mode+'-v1-result.json')).write_text(old.stdout)
  if mode!='receiver_failure':
   receipt=out/(mode+'-v1-receipt.json')
   receipt.write_bytes(z.read(root+'evidence/fresh_lifecycle_reports/'+mode+'-receipt.json'))
   checked=subprocess.run(v1+['--verify-receipt',str(receipt)],capture_output=True,text=True)
   assert checked.returncode==expected_old and json.loads(checked.stdout)['receipt_matches_input']
  v2=[python,'-m','scripts.review_runtime_outcomes',str(source)]
  receipt=out/(mode+'-v2-receipt.json')
  issued=subprocess.run(v2+['--save-receipt',str(receipt)],capture_output=True,text=True)
  expected=0 if mode=='tp' else 3
  assert issued.returncode==expected and not issued.stderr and receipt.read_text()==issued.stdout
  value=json.loads(issued.stdout)
  assert not value['execution_approved'] and value['receipt_version']==2
  assert value['outcomes_separated'] is (mode=='receiver_failure')
  if mode=='receiver_failure':
   assert value['original_trial_flat_confirmation']=='UNKNOWN' and not value['original_trial_reported_accepted']
   assert value['later_returned_flat_confirmation']=='VERIFIED_FLAT' and value['attention_required']
  checked=subprocess.run(v2+['--verify-receipt',str(receipt)],capture_output=True,text=True)
  assert checked.returncode==expected and not checked.stderr and json.loads(checked.stdout)['receipt_matches_input']
  (out/(mode+'-v2-verification.json')).write_text(checked.stdout)
  again=subprocess.run(v2+['--save-receipt',str(receipt)],capture_output=True,text=True)
  assert again.returncode==2 and json.loads(again.stdout)['code']=='OUTPUT_ALREADY_EXISTS'
  assert source.read_bytes()==raw
  records.append(dict(mode=mode,input_sha256=hashlib.sha256(raw).hexdigest(),v1_exit_status=expected_old,v2_issue_status=expected,v2_verify_status=expected,original_trial_flat=value['original_trial_flat_confirmation'],later_reported_flat=value['later_returned_flat_confirmation'],original_trial_reported_accepted=value['original_trial_reported_accepted'],attention_required=value['attention_required'],execution_approved=False))
 for label,name in [('tp','release-tp'),('partial','release-partial'),('seal_failure','release-seal_failure'),('receiver_failure','receiver')]:
  (out/('previous-'+label+'.xml')).write_bytes(z.read(root+'evidence/observation-stop-'+name+'.xml'))
validation=dict(input_artifact_commit='843825f41eef618cf6318329d3bb8b377bf4564d',input_archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),input_source_commit='94c47d86568e785c04a82dd95aeb5f05736e9da0',offline_reports_revalidated=4,records=records,previous_junit_reused_not_rerun=True,fresh_financial_lifecycle_execution_performed=False,actual_exchange_requests=0)
(out/'REPLAY_VALIDATION.json').write_text(json.dumps(validation,indent=2)+'\n')
print(json.dumps(dict(offline_v2_roundtrips=4,v1_behavior_preserved=True,old_junit_reused_not_rerun=True,actual_exchange_requests=0)))
