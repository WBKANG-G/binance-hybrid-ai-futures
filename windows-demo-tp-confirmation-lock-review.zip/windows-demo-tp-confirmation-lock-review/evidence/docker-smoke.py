import hashlib,json
from tempfile import TemporaryDirectory
from pathlib import Path
from types import SimpleNamespace
from uuid import uuid4
from packages.persistence.demo_order_quota import DurableOrderQuota,LocalQuotaStopped
from services.execution.demo_runtime_confirmation import RuntimeConfirmationCoordinator
from services.execution.demo_managed_runtime import assemble_managed_runtime
with TemporaryDirectory() as directory:
    q=DurableOrderQuota.create(Path(directory),'DEMO-smoke',uuid4())
    # Isolated guard fixture only: no actual coordinator construction, lease,
    # SDK, PostgreSQL, financial proof or order transport.
    c=object.__new__(RuntimeConfirmationCoordinator)
    engine,budget,lease=object(),object(),object()
    base=SimpleNamespace(engine=engine)
    bridge=SimpleNamespace(store=base,lease=lease,journal=q)
    store=SimpleNamespace(engine=engine,bridge=bridge)
    client=SimpleNamespace(_require_binding=lambda:None)
    c.store=c._confirmation_store=store
    c.client=c._confirmation_client=client
    c.admission_budget=c._confirmation_budget=budget
    c.quota_bridge=c._confirmation_bridge=bridge
    c.lease=c._confirmation_lease=lease
    c._confirmation_journal=q
    c._confirmation_base,c._confirmation_engine=base,engine
    c._confirmation_check_budget=lambda:None
    c.confirmation_binding_rejections=0
    c._require_confirmation_bindings()
    q.close()
    before=hashlib.sha256(q.path.read_bytes()).hexdigest()
    try:
        c._require_confirmation_bindings()
        raise AssertionError('closed order lock admitted')
    except LocalQuotaStopped as error:assert str(error)=='RUNTIME_CONFIRMATION_ORDER_LOCK_REQUIRED'
    assert hashlib.sha256(q.path.read_bytes()).hexdigest()==before
try:
    assemble_managed_runtime(None,None,None,None,None)
    raise AssertionError('execution enabled')
except LocalQuotaStopped as error:assert str(error)=='RUNTIME_REAL_EXECUTION_DISABLED'
print(json.dumps(dict(smoke='PASSED',network='NONE',scope='GUARD_FIXTURE_SYNTHETIC_GRAPH_REAL_ORDER_JOURNAL_NO_COORDINATOR_CONSTRUCTION',closed_order_lock_refused=True,closed_journal_hash_unchanged=True,default_execution_refused=True,actual_exchange_requests=0)))
