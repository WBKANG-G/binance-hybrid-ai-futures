"""Lost order-journal ownership stops scheduling without repairing its records."""

# ruff: noqa: F811
import asyncio
import os

import pytest

from integrations.binance_usdm.demo_tp_window_budget import ProofDeferred
from packages.persistence.demo_order_quota import LocalQuotaStopped
from tests.integration.test_demo import system as demo_system  # noqa: F401
from tests.integration.test_managed_order_quota import managed  # noqa: F401
from tests.integration.test_managed_runtime_assembly import assembly  # noqa: F401
from tests.integration.test_quota_startup_review import snapshot
from tests.integration.test_runtime_confirmation_deadline import scheduler
from tests.unit.test_quota_startup_read_only import files


def lose_lock(q, fault):
    backup = q.lock_path.with_suffix(".held-backup")
    if fault == "closed":
        q.close()
        return lambda: None
    os.replace(q.lock_path, backup)
    if fault == "replaced":
        q.lock_path.write_bytes(b"synthetic replacement")
        q.lock_path.chmod(0o600)

    def restore():
        if q.lock_path.exists():
            q.lock_path.unlink()
        os.replace(backup, q.lock_path)

    return restore


@pytest.mark.parametrize('fault', ['closed', 'missing', 'replaced'])
@pytest.mark.parametrize('timing', ['before', 'waiting'])
def test_lost_order_lock_stops_before_more_scheduler_work(assembly, monkeypatch, fault, timing):
    session, c, state = scheduler(assembly, monkeypatch, 'normal')

    def restore():
        return None
    captured = []

    def inject():
        nonlocal restore
        restore = lose_lock(session.journal, fault)
        assert not session.journal.owns_process_lock()
        captured.append((snapshot(assembly[0]), files(assembly[8].order_directory), list(state['calls'])))
    if timing == 'before':
        inject()
    else:
        attempted = []

        def require(cost):
            state['calls'].append('admit')
            if not attempted:
                attempted.append(True)
                raise ProofDeferred
        monkeypatch.setattr(session.budget, 'require_proof', require)
        pause = c._confirmation_sleep

        async def wait(delay):
            await pause(delay)
            inject()
        c._confirmation_sleep = wait
    try:
        with pytest.raises(LocalQuotaStopped, match='ORDER_LOCK'):
            asyncio.run(c.confirm_exit_budgeted())
        domain, disk, calls = captured[0]
        assert snapshot(assembly[0]) == domain and files(assembly[8].order_directory) == disk
        assert state['calls'] == calls and c.budgeted_flat_confirmation == 'UNKNOWN'
    finally:
        restore()
        session.close()
