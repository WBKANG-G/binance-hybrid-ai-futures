"""Minimal reproducer for the pinned baseline commit in REPRODUCTION.json.
Requires the repository's isolated PostgreSQL test fixture; not a Windows probe.
"""
# ruff: noqa: F811
from uuid import uuid4
import pytest
from packages.persistence.demo_order_quota import LocalQuotaStopped
from services.execution.demo_managed_runtime import RuntimeStorage
from tests.integration.test_demo import system as demo_system
from tests.integration.test_managed_order_quota import managed
from tests.integration.test_managed_runtime_assembly import assembly, open_session
from tests.integration.test_quota_startup_review import snapshot
from tests.unit.test_quota_startup_read_only import files

def test_valid_empty_other_scope_cannot_replace_scope_with_pending_requests(assembly):
    store, c, q, clock, w, source, sender, calls, storage, clocks = assembly
    w.reserve(1000, "RESCUE")
    folder = storage.order_directory / "other-pressure"
    folder.mkdir(mode=0o700)
    identity = uuid4()
    storage.shared_anchor.bootstrap(
        folder, "DEMO-other", identity, monotonic=clock.mono, wall_clock=clock.utc, boot=clocks.boot
    )
    clock.seconds += 70.01
    alternate = RuntimeStorage(
        storage.order_directory, folder, "DEMO-other", identity, storage.shared_anchor
    )
    args = list(assembly)
    args[8] = alternate
    before, disk = snapshot(store), files(storage.order_directory)
    created = None
    try:
        with pytest.raises(LocalQuotaStopped, match="STORAGE_BINDING"):
            created = open_session(args, allow_synthetic_model_execution=True)
    finally:
        if created is not None:
            created.close()
    assert snapshot(store) == before and files(storage.order_directory) == disk and not calls
