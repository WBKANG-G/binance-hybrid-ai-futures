"""NORMAL/paused day+week preview only; never changes a baseline or risk state."""

from integrations.binance_usdm.demo import DemoClient
from integrations.binance_usdm.recovery_transport import recovery_connection
from packages.domain.contracts import RiskState
from packages.persistence.demo import DemoStore
from services.execution.demo_models import DemoLedger
from services.execution.demo_period_review import PeriodReviewBlocked, _review_periods
from services.execution.demo_recovery_budget import AuditBudgetExceeded, RecoveryReadClient


def review_paused_periods(
    store: DemoStore,
    client: DemoClient,
    ledger: DemoLedger,
    *,
    account_id: str,
    attest_no_activity: bool,
) -> dict[str, object]:
    if not attest_no_activity:
        raise PeriodReviewBlocked("EXPLICIT_OPERATOR_ATTESTATION_REQUIRED")
    if (
        ledger.risk_state != RiskState.NORMAL
        or not ledger.paused
        or client.settings.demo_trading_enabled
    ):
        raise PeriodReviewBlocked("READ_ONLY_PAUSED_ISOLATED_CONTEXT_REQUIRED")
    try:
        with recovery_connection(client) as pooled:
            bounded = RecoveryReadClient(client)
            report = _review_periods(
                store,
                bounded,
                ledger,
                account_id=account_id,
                attest_no_activity=attest_no_activity,
                required_risk_state=RiskState.NORMAL,
            )
            bounded.budget.check()
            report.update(
                {
                    "review": "PAUSED_NORMAL_PERIOD_PREVIEW_NO_DATABASE_CHANGE",
                    "risk_state_preserved": True,
                    "preview_only": True,
                    "read_diagnostic": {
                        **(
                            pooled.diagnostics()
                            if pooled
                            else {"audit_transport_mode": "UNPOOLED_TRANSPORT"}
                        ),
                        "signed_get_count": bounded.budget.signed_queries,
                        "clock_probe_count": bounded.budget.clock_probes,
                    },
                }
            )
            return report
    except AuditBudgetExceeded as error:
        # Preserve fixed safe resource codes without printing transport/credential data.
        raise PeriodPreviewBudgetBlocked(error.code) from None


class PeriodPreviewBudgetBlocked(Exception):
    def __init__(self, code: str):
        self.code = code
        super().__init__(code)
