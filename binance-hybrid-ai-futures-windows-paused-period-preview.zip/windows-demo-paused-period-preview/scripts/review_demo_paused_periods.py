"""Read-only NORMAL/paused day+week candidate review; no apply mode."""

import argparse
import getpass
import json
import os
import warnings
from pathlib import Path

import yaml
from sqlalchemy import create_engine
from sqlalchemy.exc import SQLAlchemyError

from integrations.binance_usdm.demo import DemoClient, DemoFailure, DemoSettings
from packages.domain.config import UniqueKeyLoader, database_url
from packages.persistence.demo import DemoStore
from scripts.demo_key_session import credentials as session_credentials
from scripts.review_demo_recovery import blocked
from services.execution.demo_day_review import DayReviewBlocked
from services.execution.demo_history_review import HistoryBlocked
from services.execution.demo_paused_period import PeriodPreviewBudgetBlocked, review_paused_periods
from services.execution.demo_period_review import PeriodReviewBlocked
from services.risk.paper import RiskRejected

ACCOUNT_ID = "DEMO-WINDOWS-ISOLATED-BTC-V1"


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--attest-no-activity-since-anchor", action="store_true")
    args = parser.parse_args()
    if (
        os.getenv("LIVE_TRADING_ENABLED", "false").lower() != "false"
        or os.getenv("TRADING_MODE", "PAPER").upper() == "LIVE"
    ):
        blocked("PERIOD_CONTEXT", "LIVE_CONTEXT_FORBIDDEN")
    if not args.attest_no_activity_since_anchor:
        blocked("PERIOD_ATTESTATION", "EXPLICIT_OPERATOR_ATTESTATION_REQUIRED")
    engine = None
    stage = "CREDENTIAL_INPUT"
    try:
        warnings.simplefilter("error", getpass.GetPassWarning)
        credentials = session_credentials(prompt=True)
        stage = "CONFIGURATION"
        cfg = DemoSettings.model_validate(
            yaml.load(
                Path("configs/demo-isolated.example.yaml").read_text(), Loader=UniqueKeyLoader
            )
        ).model_copy(update={"demo_trading_enabled": False})
        client = DemoClient(cfg, credentials)
        stage = "DATABASE_READ"
        engine = create_engine(
            database_url().get_secret_value(), connect_args={"connect_timeout": 2}
        )
        store = DemoStore(engine)
        before = store.read(ACCOUNT_ID)
        stage = "PAUSED_PERIOD_PREVIEW"
        report = review_paused_periods(
            store,
            client,
            before,
            account_id=ACCOUNT_ID,
            attest_no_activity=args.attest_no_activity_since_anchor,
        )
        if store.read(ACCOUNT_ID) != before:
            raise PeriodReviewBlocked("DATABASE_CHANGED_DURING_REVIEW")
        print(json.dumps(report), flush=True)
    except (PeriodReviewBlocked, DayReviewBlocked, HistoryBlocked) as error:
        blocked(stage, str(error))
    except PeriodPreviewBudgetBlocked as error:
        blocked(stage, error.code)
    except getpass.GetPassWarning:
        blocked(stage, "HIDDEN_INPUT_UNAVAILABLE")
    except DemoFailure:
        blocked(stage, "DEMO_QUERY_OR_SNAPSHOT_FAILED")
    except RiskRejected:
        blocked(stage, "LEASE_OR_RISK_GATE_REJECTED")
    except SQLAlchemyError:
        blocked(stage, "DATABASE_ACCESS_FAILED")
    except (ValueError, EOFError, TypeError, KeyError, ArithmeticError):
        blocked(stage, "INPUT_OR_CONFIGURATION_INVALID")
    finally:
        os.environ.pop("BINANCE_DEMO_API_KEY", None)
        os.environ.pop("BINANCE_DEMO_API_SECRET", None)
        if engine is not None:
            engine.dispose()


if __name__ == "__main__":
    main()
