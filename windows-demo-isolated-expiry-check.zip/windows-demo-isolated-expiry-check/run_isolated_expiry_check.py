"""Synthetic expiry regression in a key-free image and dedicated tmpfs PostgreSQL."""

import hashlib
import json
import os
import sys
import tempfile
from pathlib import Path

DATABASE = (
    "postgresql+psycopg://fault:synthetic-local-only@127.0.0.1:5432/hybrid_fault_review"
)

BASE_HASHES = {
    "alembic.ini": "e7955a0ffb9c32a9c5067d7885ee9197328f17a4a12fb4a5bb556c2b85763aa2",
    "configs/config.schema.json": "b05d5028140a2246e78c3567bdf21a69366388e8e85e3b70460821562922608e",
    "configs/demo-isolated.example.yaml": "d93e85c2e056ffbbc3dac5fab9f0e5bf28032fd16f41bbff1f3ae81fb00882ca",
    "configs/demo.example.yaml": "4ad2260c5870131fa70c69f43c6c74df01203e83ce21994215b78818197ddaf7",
    "configs/demo.schema.json": "8240316a03072a5dfcb603a24e70a58aabd5587bd5636cd4768fc7ac9ca8dc7c",
    "configs/live.example.yaml": "83c1775cf5d728b6fabfedcc0218767e6412f92089f8838283c6fb988029c58d",
    "configs/paper-sandbox.example.yaml": "3a8d7d116c4eb45f5823732e0b9c8b8d1bce6b9c80cf30d59a07fe8f4806b38f",
    "configs/paper-sandbox.schema.json": "8ee6ae21bf51317cfed85e6c45548b5c6b12a46de36f1f54f7b4cbacf46ca9b4",
    "configs/paper.example.yaml": "9f0bf7ad77cb8570e417678810212ece0777e2a7e71c9c307eb3f1843a571783",
    "configs/research.example.yaml": "7943ee8c4a0a28a5e6954b73c7ddf40b73c001d4969a0fd32c55c7d3caf01ffb",
    "configs/research.schema.json": "3edee4b36bd9b6337682640700b16d8918d471aea1285f41c5a29d7058520937",
    "integrations/__init__.py": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "integrations/binance_usdm/README.md": "69307f075caac11028e5e5e844e1bdbeeaf122f911de9d908cdf8b7cce77fab1",
    "integrations/binance_usdm/__init__.py": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "integrations/binance_usdm/demo.py": "c5ec1f89d645dcd124a71cdf9cb39884cc9cfa5a2493636baf1c08db2c581a81",
    "integrations/binance_usdm/demo_snapshot.py": "02e5d789280f3ed8aa2667319248982d5cd4eedd2fb8b72e70aef8785e57ed6a",
    "integrations/binance_usdm/filters.py": "0279613f1a17a2bc7ffd50e30be2b6fd1aed8ba240219e8e893b754a067d95ec",
    "integrations/binance_usdm/orders.py": "2ab366265f7d35356ee9636c6aad4b594b518beeb636407515a57386b3e8441f",
    "integrations/binance_usdm/private.py": "f7f67c4e17bd0b32c6844840dc1997bdb6fa0f4b705dd01af518ca319d2ff459",
    "integrations/binance_usdm/recovery_transport.py": "11d66dd5e05b4707b5794707df0fa889be4cbb1204fcd7a0ec23d9c6008ea791",
    "integrations/binance_usdm/rest.py": "9a14edc40fa6365a50fe57c9ddeff4e866044e00287e7c5b680d8bb3dbd0ad52",
    "integrations/binance_usdm/streams.py": "aeff30cd4df3635921a659e63d2889aa6311fc021abe8b470c76293b86248be0",
    "integrations/telegram/README.md": "c1a4bff7a0985a7cf1440ddacf455872ee7323795dcc0e94cfe0f80a0dcad0c4",
    "migrations/env.py": "4256345fc24dd52ba706aa9b712268b9df436d52bafa7238234272d754734086",
    "migrations/script.py.mako": "67042994cfc495007c508ccae15e44d21057d90222461630f9bc04d3657f5f6d",
    "migrations/versions/0001_public_market_data.py": "b62afcb18d6d6c42d710ca0cb0eb42001e174934f11678443dc5ac24d86932f7",
    "migrations/versions/0002_paper.py": "91ffad2a439b9f47e2636939a5aba091490942db7a87bb0d87124a531870c77d",
    "migrations/versions/0003_demo.py": "6b2a26ba34855a3dee6d3b2c67eb9b3ecac644b4e2e31ad6353e907a3c233762",
    "migrations/versions/0004_demo_urgent_alerts.py": "da9e4de16f1f9d4c15d70293d3b252084648fbbcb060f8ec7740b9a85f83e8ad",
    "packages/__init__.py": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "packages/domain/__init__.py": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "packages/domain/config.py": "c2bd7a039e3ea007a1e34a6dbdd058cc626e2690cc8d55b0761cfd2085bf311d",
    "packages/domain/contracts.py": "71c0a95faad586d6e3f342d83b6b95a4772cb6e2c1808b44fc51fdf9f1332947",
    "packages/observability/__init__.py": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "packages/persistence/__init__.py": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "packages/persistence/demo.py": "40f9a33b8eeda28c96f36de35656e4667a2d2461ce9de79dc4b19a687cd5cd5a",
    "packages/persistence/demo_alerts.py": "fb8986d57ef850c7b707d59730b002ead125429e1d23d310a89b3c7e69385330",
    "packages/persistence/health.py": "d8847cac2894f93759d85fa2e65dee648e830b01dcc80e4d712be618b3688275",
    "packages/persistence/market.py": "89265a7bc7d181863983f4d24e6bdbe7499bb5b8154a6b22c6aea46c0d216050",
    "packages/persistence/paper.py": "312f2ab4478e2cb7f980045c56ac1329d080d8e54d60f960a93ae0f2fe1d2bd7",
    "pyproject.toml": "54760a9fa52fc4cc877d2302c7952688ddd13e12f1efc8e44a0974aae8914019",
    "scripts/__init__.py": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "scripts/backfill_market.py": "eea3f8c1b64a34f5cc01c4724c092a34ecfbb8be44fef274a4a49f3f41ff142d",
    "scripts/check_demo_alert_pipeline.py": "2aa3757bf21040d2abd38e2271ef74459ba9f98c54ef0346d7d0fb3702c18eb6",
    "scripts/check_demo_disconnect.py": "c85c013412053237eda7ed82a8948aa4b50f9da1951d173360a1ecfb46228a1e",
    "scripts/check_demo_empty_db_restart.py": "4f9c0af5a54fba6902bfe376f3c532fd3c35af3a8aeb683f7ef7a988b61fc0a6",
    "scripts/check_demo_empty_worker_recovery.py": "3b925f4a632140e6cd8ac9c5f23f92ae2545d5fa27ea7636469c44a7421cb5ee",
    "scripts/check_demo_entry_response_loss.py": "cde455c7c6eb60e31bd1146e738b15b665f1d45346732317c912f1fcdb4ddb62",
    "scripts/check_demo_open_api_restart.py": "184a307e808afa3a7efca33ab7386c8ffd3a6b2bd0b9ccdb4d87175ca3428853",
    "scripts/check_demo_open_disconnect.py": "4aff1742378a74530331cab783ebfe753feda2dd06f043bdcfc6f1b8aa248e5a",
    "scripts/check_demo_private_stability.py": "c9c3ba429ca4dd3706fb1e7d09f4cf81a52a9073b722966a31063b6b28031131",
    "scripts/check_demo_session_ready.py": "400d60be1e2c8c48115c74bb7c9c99918e626d4263a0c4eb879504d738101e60",
    "scripts/check_demo_sl_fault.py": "0bdefce38870129b75805d4cd1abe6dec6a517e398c2694898e03223b8f95200",
    "scripts/check_demo_tp_fault.py": "76f8a08318c0f4477cfb8423ca32c4ce20255479f6be06cb291ac0ea71057819",
    "scripts/check_demo_tp_trigger.py": "a5501056db126dde5de8a5a298182de0681668da1e95a985767d1988e81a72d3",
    "scripts/collect_market.py": "d43f69c960ac1f1d8101e20f856270b84d3169bea2b95aae7f8e4dd65a9788a3",
    "scripts/compose_cloud.py": "af1eaf80c4f40bea7a774d39e943482b425fb0a055e0a091a76ad301059526ee",
    "scripts/demo_alert_email_session.py": "5f8bacfeeec2c8fc3285150c24b493a559b3ba22e439e6d03c40b4bd010cbc15",
    "scripts/demo_key_session.py": "85c698bc8bbad98bad4051c346a5e4e0a3a3bd22f8bbb90a362f835cadc633dd",
    "scripts/demo_probe.py": "264a9c77b302f20dbc7cea7565ef1dbb2d3dfb2b608409d83509aec0f864bf64",
    "scripts/diagnose_demo_ledger.py": "25dc71896231be7ed6a6c100b2aab2a35894ee3992550d97667580b54d0edba4",
    "scripts/generate_schemas.py": "b4ab6035622c35b2200064581d94d8cdad646a0b371c69d4525e3c17ccb75a00",
    "scripts/observe_demo_private.py": "842c9f03621ea1f98b4aa8a9628c36eb0582156823c7efbac89ae0c7dcc8e20c",
    "scripts/request_demo_trade_export.py": "87341ddc9c21adcd735b41c74008179e2bb0c0a07fd4e20626affee95935459c",
    "scripts/review_demo_alerts.py": "a19eeb699d3a8c12cfc7bb1735637e1ff7c112688d92401bde1db72dea34489a",
    "scripts/review_demo_attested_day.py": "fc04c1c005f84f3ac6e773cd9ec7ce03d540b1830c740f01e05fc3209f453a58",
    "scripts/review_demo_cancelled_correction.py": "5eba7c10c109ab1c83b407a4460f13a344fd071e394b8cc6d560862a5bd99d6a",
    "scripts/review_demo_cancelled_history.py": "9b2ed811756e41d1202c61448e7bef9a52c4236d6c8132b64b1bd223f6e0e19b",
    "scripts/review_demo_day_boundary.py": "a1458743ff4ba7346be8e651052fd398d5d506ab6c3bc72769f5fd7ae57f3d28",
    "scripts/review_demo_exit_day.py": "18ed5be7b80d3c371b716df70e623ec787db64a2cf6def7924d850ffee9f9a34",
    "scripts/review_demo_flat_history.py": "887dede95666485fe9df66aa2adf334d068a3c706ab7702af85f442a19b12d07",
    "scripts/review_demo_paused_day.py": "bf3289471325a2d9435eae3b374e3f0d090db9e4b7b70800b772bf72bd42f496",
    "scripts/review_demo_paused_periods.py": "6638836d9f629a86376920b1dd1b1fcce7acc6b3bd0d418aa86c8f4951521892",
    "scripts/review_demo_periods.py": "f6257964485fc855335738c02bb0a8aeedca955a5e9423e6ae21b04ea3b3c629",
    "scripts/review_demo_recovery.py": "dad0a79f584f8b660b0240254d03666a8bc12bbdbaa7073ba7843824c913e675",
    "scripts/run_backtest.py": "e7da70036bdf746ca753724f846d24e2cb2431b3187fcc42e2886098217c27e7",
    "scripts/run_demo.py": "36bd74984f5cb1ab63d1278a03ea57f156759435c6f3e9045f0e9533ce21462f",
    "scripts/run_isolated_phase4_fault_check.py": "e1fc92d88bfbd8fd059bc4700b14b1ca678ed324694e28d33f72359960e8b1a2",
    "scripts/run_paper.py": "a19ac8812c2d000a6232b70c27b22f0324db4b1a6b09b953b821ab73e05d6beb",
    "scripts/send_demo_alert_email_test.py": "7595fca8f0bf9584845dd8096b4620789f842cd25dec618222b5c6926c4cd809",
    "scripts/smoke.py": "ed18eac0706a34a2a839306725103c8dfbf3167054f7ddd72cb005b46565db2c",
    "scripts/wait_demo_restart_ready.py": "e6f2f3d5cbbc06155c953f0cef9d3851a1216a9e14fe1e41c5cb1e8ac8776da4",
    "scripts/watch_demo_alert_email.py": "df5fb1353c71be7e0137301850e01d2e5d2c4f8519e5c166e67c76d0e76b5164",
    "services/__init__.py": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "services/ai/README.md": "eb41f6d8d96c7ae346d8b0dd1672ca9223316dcdc3bcbded0d16e7dcdba33efc",
    "services/execution/README.md": "e35cdd4d063a821365b82132a1a11536ef71c52b0dbd5aac8fc2d185df2a59cd",
    "services/execution/demo.py": "deb90dd8ddd9df627054a11c76f8dd8b09e364f2aaaca8f82b7fd0c237c444ab",
    "services/execution/demo_api_restart_check.py": "b96ca788094995dafb7a69d9bbbd7f6a6dd16687d30bc9bd4271164c307ab239",
    "services/execution/demo_cancelled_correction.py": "0b16429d200d1bc1dd7203f2a2e9623179d8afc2c09b6ab841a6a1f5f4b93831",
    "services/execution/demo_cancelled_history.py": "e8c71d0b8db439e216c75e37a00cc7e3bfb549e7d19a6dccfd0eba28d5b7eaa5",
    "services/execution/demo_day_reconstruction.py": "546e8f5e53c7a100fcf7dd64d843f87193b5e1b2ddbe4eaef6fd57b1c4c365c0",
    "services/execution/demo_day_review.py": "fa43255b3a220e762c88e633e2a5a14a8bc394828d8cdf44e0965c95807d24b2",
    "services/execution/demo_empty_db_restart.py": "6adcc8284b43050bc4a115f2796c001d424ba7e0261654c099075fb3d950e39f",
    "services/execution/demo_empty_worker_recovery.py": "8e3cac8da89fb80ef9f3654ae8591ffea7be1db1c7dc60070da72b72851b2070",
    "services/execution/demo_entry_response_loss.py": "3010ad04f3289bd0cb3a6310565f3074d0c31265fb008bd5a5126f8d1b4ca96d",
    "services/execution/demo_event_clock.py": "924f3b88c9092355bb4b4ada3114944848208ab5b44ab73ee5b45d5fc1a29bfb",
    "services/execution/demo_event_inbox.py": "6d9be8c64e144592a5c2343c1db6e4dfc1dee65aa65eeebc08bd52b5aa633281",
    "services/execution/demo_execution_proof.py": "09c36ceab43021c5cf0d10da08af897124008be2e083deb560572640b3cbe0d4",
    "services/execution/demo_exit_day_review.py": "1f24385259fb7b3c480af2324ef39a19321171454a05b4e31900e72f217a53bd",
    "services/execution/demo_flat_transport.py": "93f878c9869ad397a52546f0aa976bbe8071366eff36c7d0be6b1329df757401",
    "services/execution/demo_history_review.py": "3f4de05ad41cab2b8450304519c128231f24cbf3d44463af4ea7697e485eda4d",
    "services/execution/demo_initial_fill.py": "aa5bcaa7f8b9c6112893c89e8e8e90c74eb16704f1dc16becc6c22bdaec24ba5",
    "services/execution/demo_models.py": "175def10d7378661e82616b02ec87d6dbee4ffdeb4eb94437ce682206168dfb0",
    "services/execution/demo_open_disconnect_check.py": "0247ca4f9f4f4a63a8b1ff1fdf4f710bc338409b98eeb5ecb0ba812f3bbe206d",
    "services/execution/demo_paused_day.py": "c31df683cc31e1c29b954bb9cd3c4f7e92dccfd7579e4cc3a26f81e9230bfc93",
    "services/execution/demo_paused_period.py": "8356051fa4a5d7d3aadf78d1c5269bcc85b66da57333e8189043d78c551ff52c",
    "services/execution/demo_period_review.py": "3702915fdbf7d6da8cc5e048cd3607f9e549399860e6412aa2f751a57a0d5043",
    "services/execution/demo_preview.py": "58ba6376f61f8467d2b3c9e75923444105f5fe610f9bde4455a94b5fb5d6f267",
    "services/execution/demo_private_stability.py": "d3aee78f2da73c15c3eff5f89403fae666de5109ad3c2402585f2150df1a5123",
    "services/execution/demo_reconciliation.py": "7554e0fdcdab08dc222700bde8254ba7979c44c0ec4d82c1d2009ea0e0bb5040",
    "services/execution/demo_recovery.py": "ca663f098d2f7c462d1f225f4ade91d743169175f125c574794dc58175c8c76e",
    "services/execution/demo_recovery_budget.py": "2c7aa260fd708948b0ae7854257de03bc8b59c86da85180ea5230b07e8df772b",
    "services/execution/demo_session_diagnostics.py": "78d2bbeadf90bda14a08f5c7dcd8cc8285f9ee55389b07ffb4a8742d052d520b",
    "services/execution/demo_sl_fault_check.py": "bd8275656045ef0b951fd6a3fc9e766cfe8784c9c4cc808638bb30e24b6d1cab",
    "services/execution/demo_status.py": "b142ff90c0684d2a3d362ae444105ed4156766e4729542825c606f8f6aaf7a08",
    "services/execution/demo_stream.py": "32eb57dab93b5adf9df2544300faa12b8e1d6ed36eb2b97fc23e188afc5deb93",
    "services/execution/demo_tp_fault_check.py": "aaa1b4f3dfd8db86629f251d4781c78b624726ccefba1a0ed37a6f04dd4a2b1c",
    "services/execution/demo_tp_trigger_check.py": "4d7b9a85f0ff9dbbbf242f5a35aa482a44eb9ea9df6e0cfefb575f232ea3cd6f",
    "services/execution/demo_trade_export.py": "26a7b5f402ae3d4b198b50b769d1c3599d8db042680ee032ffe5217908e74dbb",
    "services/execution/demo_validation.py": "8163fd58984d9893bbf80d1be9184c126119e49b079fa85a0acfb0d85db2d38f",
    "services/execution/models.py": "5d362e33788a304e6f2f63f22868454b3804b103277a6fe4a1297c7e50e10a5d",
    "services/execution/paper.py": "1a847e50fc78d48846fadc9953fad07aed5bbdf83f1e30986d39fef0e0d9fc13",
    "services/execution/simulator.py": "fa3955b49de8b2a92ae67bea4b85d1f8d1e50581f967df2b96708bdfb3cdc2bd",
    "services/execution/status.py": "e1e0b2425aedc82eb12d4264d787fc0e2b0b621b40d44db3678fce03ea8f7209",
    "services/market_data/README.md": "d2ffe4baef7466c83c642ce212b25fc41118cb5519d762c0cb2f08f0c5b9718b",
    "services/market_data/__init__.py": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "services/market_data/collector.py": "e07371e4560aaf1064fac5efa92a7b2331affe9aec7492af804f7e2da6040c19",
    "services/market_data/integrity.py": "4669f0339610bf1fd183913f542fef7aae9a447ad72d5e57fe2b34e7724d3d8b",
    "services/market_data/normalization.py": "ba06f00a0778cea08c39442fa9911d4140f1b0b1cf2f916ef7bc50c54cf6bb64",
    "services/operations/README.md": "ec8e0e455196b34a98a2330710e7d5ccc90df7084dfd62a798ac40ecea022a46",
    "services/operations/__init__.py": "f098e7b66c4910d40daed69d32d7f665c2f1886209c721c61ec3c565c5c90aa4",
    "services/operations/demo_alert_delivery.py": "9f20edf93e8ed37df7fd4f63f31693f0fe1bce17428bd11a237362d5912bdb60",
    "services/operations/demo_alert_email.py": "b5d3bb564297a256b1e3b7d6ad713b0bd84e91b5e6ad37af7babb48b37e5405e",
    "services/operations/demo_alert_pipeline.py": "fe25c7dd940f481008c3ee781360949844bcab4f880a32347c9faedf99c5da51",
    "services/portfolio/README.md": "2374eae1ec2dc820f9987295e9f7119b6339e0fdf8d657115ff3924bcef89e8e",
    "services/protection/README.md": "09546e59900d62cb0083493ccb8a32c5c1a96cdb4308279af5977d36e7f58495",
    "services/protection/paper.py": "b60ac5ae41db6e7f1bbd8cb294e5adec18685220720a597a18828d83a411655a",
    "services/risk/README.md": "fa63d415380dea0c2c9827e7564eef83c25a7938411e646a19c6d854eccfc05e",
    "services/risk/paper.py": "7afe00460abae04dda795ab0dba8b8ad84877fa25686342c1fbce3f12ac80832",
    "services/strategies/README.md": "893ec6790cf4951658110fbf4f014ac0a0ca961443cc8a602fd9d991506ecfcb",
    "services/strategies/__init__.py": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "services/strategies/indicators.py": "e215c55f54737a6f7c6bfa0b208f3e81d213e37e348f306fa49a3b4fc3ae030f",
    "services/strategies/rules.py": "87517d9e83c5303f25a3b3001296e6e6c8f963b97a8dbe96f934babafc15c5c1",
    "services/universe/README.md": "5c2c6264c6949af5fc32620e1660ae06fbc51685e1d54a8aa88d882a79834e72",
    "tests/__init__.py": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "tests/conftest.py": "5341ed5047d1a5b706d3c80418c2527cf23f8e7830e1f1a93a66d12af338e2ca",
    "tests/contract/test_binance_contracts.py": "8af2749641abf759d595909436247678bf9817f18294fde1a3679f9b4fa544ba",
    "tests/contract/test_schema.py": "7e6f13bcadbc5fe0ce280314bd6b7501ca9a4338305b510e6c8711527eeb85a8",
    "tests/e2e/README.md": "c1a4bff7a0985a7cf1440ddacf455872ee7323795dcc0e94cfe0f80a0dcad0c4",
    "tests/fault_injection/README.md": "c1a4bff7a0985a7cf1440ddacf455872ee7323795dcc0e94cfe0f80a0dcad0c4",
    "tests/fault_injection/test_demo_empty_disconnect_check.py": "a2773791c4676210f9451833316bc46a782276f64d7b8d481ba3fcaea3fd8965",
    "tests/fault_injection/test_demo_inbox_worker_failure.py": "b15e0464bf6dc5514c09dff44f4d81bb557afdb591a81899766605551c682f48",
    "tests/fault_injection/test_demo_session_diagnostic.py": "426208d2702ca971ed4193b1cd56f40e3c7011e936ffc10dd96279bed4ac7001",
    "tests/fault_injection/test_demo_stream.py": "0607a6ecd19fdb77e1f2c708f4ad45b2e11846a98d452531fb4e365631f4e389",
    "tests/fault_injection/test_stream_recovery.py": "84e3bc90f029254198480827cc948501727a1607e7ff01eae005315454775299",
    "tests/fault_injection/test_websocket_transport.py": "6ed6f9114e6a125c14851e962363703b7ea9fc8a3c002a9630906bfb7533ac03",
    "tests/fixtures/__init__.py": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "tests/fixtures/binance.py": "17a2fb2e9eda58179843b2cb717195a9572549d2eb0571f82f59a16366dd8d1f",
    "tests/fixtures/demo.py": "6f2e606aef0a4efe3330620f3fe0ba2e5923d0d7baab0589df06e9b8690114eb",
    "tests/fixtures/demo_protected_worker.py": "829d634b1242a6d7bad354ff56c00c906e9d53b07f60fe9b6824fc94f9459e88",
    "tests/fixtures/research.py": "b3984c3a7e3e3bc7b64e390a1b94d32ae97fd0f7d967cfdbf87d20e0f72c27c9",
    "tests/integration/conftest.py": "b667c7e478c871a466e34ddfc6ee775cc0cd9c030ae602742d20588e6b315d41",
    "tests/integration/test_api.py": "ef01daae59d1a4466c03f61df18992e064b1af50e27a8f4eac585a36ed5caedd",
    "tests/integration/test_api_migrated_ready.py": "f8972f2303e5008866616042ca3ccec404a45157e1910375f5cab4a0cdffac97",
    "tests/integration/test_demo.py": "26ca4551fe665de2afcb98758cdef56adada25614040aee107797e8f9ce9274b",
    "tests/integration/test_demo_alert_pipeline.py": "76d2d9ac8723691c537106232a656807edb4aa275535082e7118a7ff00b2f9f2",
    "tests/integration/test_demo_cancelled_correction.py": "d68993bb2f52498b87a7dd3f33f9ab60b686c3678a3919b2dd8bd3fed86c9682",
    "tests/integration/test_demo_cancelled_history.py": "acb2deb3c4324203db888c53981384576a0e6da40351c6016e450bd03b11c705",
    "tests/integration/test_demo_database_disconnect.py": "a23215ba4744285f99825968addacb4b41e966d6b0b23b1f8e2f9313868b9ee1",
    "tests/integration/test_demo_day_long_history.py": "66e0903f1c4fb31e6caa1d1d4e15961f6ca3ac61da16434b55ae377cf3b44440",
    "tests/integration/test_demo_day_reconstruction.py": "5c3d9ba1087dfba3924f98f6b4138b954d68d27618bc8791124449b4b37757f9",
    "tests/integration/test_demo_day_review.py": "4bfe26499c01d162babec9a9612052c6824ae8cc97d783b4c3c4c6493468fbfb",
    "tests/integration/test_demo_disconnect_drain.py": "67c3f6da32c55823244055e589b14d76df670c09dd771e29ac87e12e17f8815f",
    "tests/integration/test_demo_empty_db_restart.py": "72ef1f08e4b5226be19c914e94f1afffb27a89381d4da0481a70439bd9e6e383",
    "tests/integration/test_demo_empty_worker_recovery.py": "bcc1bc3940fa5f8d3fd463f21913ddbdf631485dab9c8f5731cde8ee3ab3470b",
    "tests/integration/test_demo_entry_response_loss.py": "7b7769e4d85869be74ce40ed61f58a7e5114e9744fbaf7b2938ccdc2957dbf9c",
    "tests/integration/test_demo_event_inbox_validation.py": "4aaf5d880b14c12ca4df5559f06013ce6d42a42c5e2016cd04ac4c3f89ba75af",
    "tests/integration/test_demo_exchange_event_clock.py": "b9e3d54248e7059af9b5cdc30f48dfe9b785c2dc5ff78b371cf5f5cb70883e05",
    "tests/integration/test_demo_exit_day_review.py": "234746e97470c5f7ef6266a11ad6e5a8c32445e0342f454fc92beebff6a454cc",
    "tests/integration/test_demo_fill_snapshot_changes.py": "07ad2f70e790bde839857c3a288c01f3094aacd5e435d7056708a32c9b5f78f8",
    "tests/integration/test_demo_flat_confirmation.py": "49acbbbf5924cb4e1ac9163d0ed1eab42cc4286b706d70173df615db9d0edd6b",
    "tests/integration/test_demo_flat_history_review.py": "d14dda0392d6c2c4e78b722c4e5b9abf77d526d477312bcea4dd7cf4364ef44a",
    "tests/integration/test_demo_flat_transport.py": "2189e192a7ee0a1787bfc8e924d2ae4a79cace163a437c339807894c6a4f297d",
    "tests/integration/test_demo_income_time_precision.py": "89a8402b478560e577f97ba31b7278af1369a21f50636c01eb172bb25e2fa00f",
    "tests/integration/test_demo_initial_fill_settlement.py": "30f5651bc154a891cc60f703fe950d7e53e722e9d76c0ea208cb0e2d7f0b1c25",
    "tests/integration/test_demo_isolated.py": "88e06ca16dff14c19e67adc8998a8c0c060f847d9c5f4a187e20ec133a103868",
    "tests/integration/test_demo_key_session_cli.py": "f3ceb5d18ab803ca86f93042c606e7662aebb2c727d22971df4bd89b3dda5220",
    "tests/integration/test_demo_ledger_diagnostic.py": "c530453e4010d192fe0de286a2a694aea54979eaf8ae4a92356caea901ccdad6",
    "tests/integration/test_demo_multiple_initial_executions.py": "9506a0cdab018afd545ce07f4b5683e04af922e72dd758c8ed1bbfde49b4c1a3",
    "tests/integration/test_demo_one_key_flow.py": "7ed369e9cf5b537fcf32f3a15adb7ba33cc04be65a123a7f88b751375ea4076a",
    "tests/integration/test_demo_open_api_restart.py": "2be6dd6f2d4205f5d71327ca08992c52a57dcbdd94a9f16627e6848c41e14123",
    "tests/integration/test_demo_open_disconnect.py": "327da13e8845f4feb0c3d49f8ff8644d1d71b978830d93ac6e3d0f33030ab205",
    "tests/integration/test_demo_operational_latency.py": "0a09520cc4a0811523008a1c7b8d1ec275fc752e9cd6f9e918f9cabc4258b627",
    "tests/integration/test_demo_opposite_quote.py": "e1c5f993bcd7e1e718181ef71a333fc9c3d08d033b2e5cb2c06ea7dc045a2fbd",
    "tests/integration/test_demo_paused_day.py": "3323d6af48c87b8ef94b2f427561db7feaa4fe3d0f356596a26a4b328551a4cc",
    "tests/integration/test_demo_paused_observer.py": "2f4800cd733ff16cbdc78273f60c62da8be517eab4ae5b90aedd300026a4bb86",
    "tests/integration/test_demo_paused_period.py": "07489465adae7dc1f039ffbe14e9395d517850a9106ff55eb6e5c4dfabb78bbd",
    "tests/integration/test_demo_paused_period_apply.py": "515f56cec7967236feb98227dac38635fab8bddbde644bd5c334f67775af5963",
    "tests/integration/test_demo_period_review.py": "36c304c05ec4c0e4035c5e4b1a9bf9ef26618c45e8ed682d705772c6b6f6d46e",
    "tests/integration/test_demo_preview.py": "479e7410771d6a296f084063e718aa70cb2e4678e5c032d34ac3588a151a6090",
    "tests/integration/test_demo_private_stability.py": "f0abd10a73a80abd55841c2bc18c648bd46f79db2bb0ca2210fe49d45b1c5069",
    "tests/integration/test_demo_protected_worker_sigkill.py": "83d76a50390b4195a3f34e3e77d355b8c930575edfac7328fbd9ef9a0ef9e2ee",
    "tests/integration/test_demo_quantity_cap.py": "0ab905a11d49ecf2ad3196be7b9f14dadf5769ddf9f5d1f322913e427a7480ab",
    "tests/integration/test_demo_reconcile_diagnostics.py": "ffc4bd079113de038609da6d2c3a8bbfda096c64a4ebfa6f8256f907f834585e",
    "tests/integration/test_demo_recovery.py": "d0d26d2641b548666578f3e2c0391c25e89fc6dbb6b6a0a067f006cb639c25db",
    "tests/integration/test_demo_recovery_batches.py": "055903c4c1bb68c5b5fb2abd38510293a034b6cfe88658336b9dac57b4c572cd",
    "tests/integration/test_demo_recovery_diagnostics.py": "2c0528293cbb2f13674ed93342191142d1512a1fb88272f00764e83933e9b901",
    "tests/integration/test_demo_recovery_https.py": "c6c9d3907f2ba3001c30022c28751cf9fb5a82b46420b41bfbb79617fb071366",
    "tests/integration/test_demo_request_no_send.py": "c54ef1da7d383503134878e1b9683f1bbafa4689e7c6ee9ddac100843c08437b",
    "tests/integration/test_demo_restart_handoff.py": "5711247b3679bdb82522d2968447695841f03fd9d03b15c4e4af5878c09f8f3d",
    "tests/integration/test_demo_sl_fault_check.py": "fa72ef8777f050e2dbeb23ac314d63493feb0a0f889f2adc77ca0df4a83376ee",
    "tests/integration/test_demo_terminal_unfilled_close.py": "cd27b6b36253ff6aa2b01d716408dbe87e3b90557f8ae4cd7d3bd0518ad4c24c",
    "tests/integration/test_demo_tp_fault_check.py": "7dd7c5250323cb1e1e757597569c678fb341279148cf3f706d92ea44a20469b4",
    "tests/integration/test_demo_tp_trigger_check.py": "bb2b02d2a64bb5c4b49b3c987a64fdd335b6d8853cf01fff110a60f85c5ebf4e",
    "tests/integration/test_demo_trade_export.py": "b47e47013920fac95f038a9a060a6dbf51e5c71ea6d15ee7a5c32076457fbcb2",
    "tests/integration/test_demo_urgent_alerts.py": "9685eef426319ada05d6fd66611d95983cf7d39f04d0659b9f246535d67aee0d",
    "tests/integration/test_demo_validation.py": "9e0d9355ba3813cb1b2c0e0978828e213ad6322c5257ceb1c73ffceb8d8a6d29",
    "tests/integration/test_demo_valuation_bounds.py": "158827539cdbefa0d14211bc5fbca35f507d8b6c0cafc128feb9ee5501a5bf3f",
    "tests/integration/test_demo_worker_drain.py": "5806b0b1546912d652a41079d53c0e8799589679ac37c1629b40c5e637c08ad8",
    "tests/integration/test_market_persistence.py": "451918618827ce2e202658e504a8e021d2bb0908fc8946cb66ffe92a19397a1e",
    "tests/integration/test_paper.py": "0f0f50ee79d92b7812539c4e5536f6f80ec531399bde0731944e26d3716f7bac",
    "tests/integration/test_postgres.py": "5a5831835725a9f5de19614b764809d1b34576a19c6813b7e33d78273e36ea20",
    "tests/integration/test_research_cli.py": "133ac4f10225c52e62d41c52b4487626b5bb6251fac4e819fafca6bb4e5d494f",
    "tests/unit/test_backtest_execution.py": "1f7fbaebf8a9d857a93833dd8d34696d9a4700b0841b6ce4906226a351456080",
    "tests/unit/test_binance_rest.py": "67dbf6b60fff642f310e6f7173fbf1b70b3ebeafae70cc2122ffd12bb3d119a5",
    "tests/unit/test_demo_alert_delivery.py": "46be208013d551c300449d486e90b2b0a5e581a00830ed4f60fa8813aeaf57db",
    "tests/unit/test_demo_alert_email_session.py": "170aae647e8ea31d1e9026ddf1005315470abe2439c20cf2e34d10c847aead01",
    "tests/unit/test_demo_alert_email_wire.py": "b7455a2c61f76c9c84d139beb5f3f262bf1af10df1ac0cd1074a5b0e46f76d7a",
    "tests/unit/test_demo_alert_pipeline_cli.py": "912c35e8e40e88c0ad880b31193794df65ffaaab3219eb600ccfe398f92567f6",
    "tests/unit/test_demo_api_restart_check.py": "54d67ed71fb798b490b3162ad07080f7425a778c3b76085f92198ef96742f0b1",
    "tests/unit/test_demo_disconnect_cli.py": "a0570ab23b2f76c18cedffefb38537c936891fe7894ffa08acc5fc7b4f3a4c09",
    "tests/unit/test_demo_empty_db_restart_cli.py": "a9ba1cd2b845faa4c02c8186a1d882e1c2bb653634f00f1fe5a6bf438684253f",
    "tests/unit/test_demo_empty_worker_recovery_cli.py": "8630aac965c6f38488fea34c30e856c6855da29d3570a2e4decf939c914907ad",
    "tests/unit/test_demo_entry_loss_cli.py": "ce9e29da106ac1b740ab621499d8d759bbede2ff3217b93bf22fd9a790b5a64c",
    "tests/unit/test_demo_event_clock.py": "b0c07566bf17834a23261119d1e3bd44e22e3313f42cfcddd318c6f8f45cecbc",
    "tests/unit/test_demo_event_inbox.py": "1202def1353fe6993978f6d0f64d2fcbec477c53238d3dc06671af9531eda1f7",
    "tests/unit/test_demo_execution_proof.py": "fb7b831b613fd9961a59bec25cb5c0ac532b3d9ffd0d0d4317e5ed851233625c",
    "tests/unit/test_demo_flat_transport_guards.py": "ce762366c47d382ba384d3e33a3815cdbc1a5a2c104a039daf6be6f6813259e3",
    "tests/unit/test_demo_historical_span.py": "6caaa10d308cf9737870bbe251ec935984862023ecdc3924f84fd25851c1e030",
    "tests/unit/test_demo_income_window.py": "a15236eafb72dfcaff9d0a8747b6a6064eb28ed583a5703bba9707cdbdfccaac",
    "tests/unit/test_demo_key_session.py": "2a5d33fb9742fdf18147ff8e60cc12807562482c12ff8346eb370bf4dfe998dc",
    "tests/unit/test_demo_key_session_reuse.py": "cfd1a2b0a2a215c79f4693c422e67292a040559474b284f5d1aed3426cb81513",
    "tests/unit/test_demo_metadata_preflight.py": "aef5cdbb755c41535e6db068142fc36a5db2b5a28094e34db277de33229baf63",
    "tests/unit/test_demo_open_api_restart_cli.py": "f1fd08d8e22835a35b19ef77eaacbadc1c806e06df0dffeeae8ec1c2690df612",
    "tests/unit/test_demo_open_disconnect_cli.py": "10f100b77cbc3076508419036e033f323ea6f858a92a897e821d8213ec871551",
    "tests/unit/test_demo_opposite_cli.py": "deae2a5f04fae37a053cb0ed94f1c623c66bbdab2338842ddc5f8a005df02331",
    "tests/unit/test_demo_paused_day_cli.py": "8a53cb58514cd24c8b9a8fdcbdc0be6483f3e7edba546fee503bfe13f6324f29",
    "tests/unit/test_demo_paused_period_cli.py": "1e396242c16819cf9569c81df12e0b5c8b9cdaba2f10e7dbc06c011d00ce1c70",
    "tests/unit/test_demo_preview_cli.py": "731ff604ae3aee4098c7aed70c87167edf524939dd0cc276fab0f2c3a69234f5",
    "tests/unit/test_demo_private_check.py": "3b2f00ff25171fbcac59b72443a34a54fec9765441cbe1ef12e7860208a1e940",
    "tests/unit/test_demo_private_stability_cli.py": "37c0a9fabb126ae38f70e858d83a5e41d9878f2bcd8768a4963180a45b563b08",
    "tests/unit/test_demo_protected_worker_scope.py": "53c682d8fbe1ea52b00450c51b21a0a164c8ce009d1736f8dce5130fefd7b89e",
    "tests/unit/test_demo_recovery_budget.py": "f2e2d95f3655530126075c0c9fc87657a58cdca5a36e208e4d185648ccbcb6a5",
    "tests/unit/test_demo_restart_waiter_cli.py": "a1c26ceb02c3245df8d9cbf796a92c249f680388bc1b2014a2b7cd9e1bf8d783",
    "tests/unit/test_demo_session_diagnostics.py": "ffc0c75223316935e2fcc8874be74977f6a3c1b9af9582c1aba46e1b9f336b85",
    "tests/unit/test_demo_sl_fault_cli.py": "508c29053a7c10d0329c409a981756b25737aa57a181757f12ff24f8e9874909",
    "tests/unit/test_demo_socket_session_drain.py": "d57089d1f6c246126a6ad451bfc639e244e57a4a52d6907a57bdfefb7c9812fc",
    "tests/unit/test_demo_tp_fault_cli.py": "67e3ca18bd13529996b2e81432308cf076f93aa33d647467798295589234b208",
    "tests/unit/test_demo_tp_trigger_cli.py": "a08435f2ac07efb992c63ad4e798cc8dd7e73b449aec0918dce469cb3a2d62c1",
    "tests/unit/test_demo_trade_history_window.py": "663a5a281e97296c29145b521f37c52b72c5c9a0446ad1684eb58571bf9b1a14",
    "tests/unit/test_demo_transport.py": "ec66466f869cb42d8bee8d7d4ca992f06c23005335ca467f7e09b6d1a93a255a",
    "tests/unit/test_demo_validation_cli.py": "1fe9a53b1350d8e7c544b8a5e6cc38222f518784e55d5b64c90f4e4bba94df92",
    "tests/unit/test_demo_validation_contract.py": "66231f7f357ed4300939f67fbb4b98d938f88b82f3d178bf7f0c5394f8add7f8",
    "tests/unit/test_domain.py": "889d487cfde58281a2309f361ab08e288cc020a12113c3f2223145a3650860ac",
    "tests/unit/test_health_migration_head.py": "d870f5b01505225c8ec7eb8446d92b4e7d95fdffa7e172211d607f7c5a29e9cc",
    "tests/unit/test_isolated_phase4_fault_scope.py": "095d7d45a9c161bd425b74f0b1c20877921c73a8bc524b3fd74e9ffb4d2637d9",
    "tests/unit/test_market_data.py": "1e1619af8bb23e5faaf7d1277c9a7d501b6a313d0b2aadcb64632f660cdcef63",
    "tests/unit/test_private_stream.py": "3e34bb03742bf0065efe50205194792aeb84bdffdfead37fc4a7f7f41ab1532d",
    "tests/unit/test_recovery_https_transport.py": "dccf7982f0b130035d4426c027b7286a518cb6ee107cfef21114434be0fae769",
    "tests/unit/test_research_causality.py": "7357e1ea361374df9fed9dc50c1b05863fd8594fb2d0260882a80487302d7688",
    "tests/unit/test_research_evaluation.py": "b061275805160f8a7111ad00e32f0f4d99fb4c8456e3b29327ebb24c20ac4aec",
    "tests/unit/test_safety.py": "b07dc7e1a7ee6e9e12e5f663ac71c647c5f352bf5800280d6252437c9b8f74dd",
    "uv.lock": "49bbe38dc3f559466c4666febe686926db6503413a45bd766088ed2454e01097",
}
OVERLAY = {
    "services/execution/demo_stream.py": '"""Private DEMO WSS supervision. Events invalidate state; REST establishes truth."""\n\nimport asyncio\nimport logging\nimport time\nfrom collections.abc import Callable\nfrom contextlib import AbstractAsyncContextManager\nfrom datetime import timedelta\nfrom typing import Any, Protocol\nfrom uuid import uuid4\n\nfrom pydantic import SecretStr\nfrom websockets.asyncio.client import connect\n\nfrom integrations.binance_usdm.demo import WS_HOST, DemoFailure\nfrom services.execution.demo import DemoCoordinator\nfrom services.execution.demo_event_clock import validate_event_time_async\nfrom services.execution.demo_event_inbox import EventInbox\nfrom services.execution.demo_models import PrivateSessionDiagnostic\nfrom services.execution.demo_session_diagnostics import event_info, failure_diagnostic\n\n\nasync def settled_call[T](function: Callable[..., T], *args: Any) -> T:\n    """Drain an in-flight thread before cancellation starts another DB operation.\n\n    Cancelling to_thread\'s awaiter does not stop the worker or release its row\n    lock. Shield it and consume completion before the caller\'s finally cleanup.\n    Repeated cancellation must not strand the worker either.\n    """\n    worker = asyncio.create_task(asyncio.to_thread(function, *args))\n    try:\n        return await asyncio.shield(worker)\n    except asyncio.CancelledError:\n        while not worker.done():\n            try:\n                await asyncio.shield(worker)\n            except asyncio.CancelledError:\n                continue\n            except Exception:\n                break\n        if not worker.cancelled():\n            worker.exception()  # Consume failure without logging any private details.\n        raise\n\n\ndef entry_wait_seconds(coordinator: DemoCoordinator) -> float:\n    """Bound idle receipt wait by the nearest outstanding entry expiry.\n\n    This is scheduling only: expire/cancel still establishes durable intent and\n    reconciles fills under the existing lease and fencing rules.\n    """\n    ledger = coordinator.store.read(coordinator.lease.account_id)\n    now = coordinator.store.now()\n    remaining = [\n        (order.signal.expires_at - now).total_seconds()\n        for order in ledger.orders.values()\n        if order.remaining\n    ]\n    return max(0.001, min(5.0, min(remaining, default=5.0)))\n\n\nclass Connection(Protocol):\n    async def recv(self) -> str | bytes: ...\n    async def ping(self) -> Any: ...\n\n\ndef private_connect(url: SecretStr) -> AbstractAsyncContextManager[Connection]:\n    value = url.get_secret_value()\n    if not value.startswith(WS_HOST + "/private/ws/"):\n        raise ValueError("DEMO private URL must remain isolated")\n    logger = logging.Logger("demo-private-redacted")\n    logger.disabled = True\n    return connect(\n        value,\n        open_timeout=5,\n        close_timeout=2,\n        max_size=1_048_576,\n        ping_interval=20,\n        ping_timeout=10,\n        logger=logger,\n    )\n\n\nasync def session(\n    coordinator: DemoCoordinator,\n    *,\n    connector: Callable[[SecretStr], AbstractAsyncContextManager[Connection]] = private_connect,\n    on_ready: Callable[[], None] | None = None,\n    max_messages: int | None = None,\n) -> None:\n    """One session. Caller may restart after backoff; a reconnect always reconciles first."""\n    store, lease, client = coordinator.store, coordinator.lease, coordinator.client\n    coordinator.session_failed = False\n    coordinator.session_diagnostic = PrivateSessionDiagnostic(stage="SESSION_CREATE")\n    try:\n        key = store.change(lease, "DEMO_SESSION_CREATE", lambda ledger: client.listen_key("POST"))\n        if key is None:\n            raise DemoFailure("DEMO private session unavailable")\n    except Exception as error:\n        coordinator.session_failed = True\n        coordinator.session_diagnostic = failure_diagnostic(error, coordinator.session_diagnostic)\n        try:\n            store.change(\n                lease,\n                "DEMO_PRIVATE_SESSION_FAILED",\n                lambda ledger: setattr(\n                    ledger,\n                    "last_private_session_failure",\n                    coordinator.session_diagnostic.model_copy(deep=True),\n                ),\n            )\n        except Exception:\n            pass\n        raise DemoFailure("DEMO private connection/session failed; entries blocked") from None\n    renewed = store.now()\n    inbox: EventInbox | None = None\n    reader: asyncio.Task[None] | None = None\n    failure_recorded = False\n\n    def receive_failed() -> None:\n        coordinator.session_failed = True\n\n    def metrics() -> None:\n        if inbox is not None:\n            coordinator.session_diagnostic.received_events = inbox.received\n            coordinator.session_diagnostic.coalesced_events = inbox.coalesced\n\n    async def record_failure(error: Exception) -> None:\n        nonlocal failure_recorded\n        coordinator.session_failed = True\n        callback_ms = coordinator.session_diagnostic.ready_callback_ms\n        if inbox is not None and inbox.failure is not None:\n            coordinator.session_diagnostic = inbox.failure.model_copy(deep=True)\n            coordinator.session_diagnostic.ready_callback_ms = callback_ms\n        else:\n            coordinator.session_diagnostic = failure_diagnostic(\n                error, coordinator.session_diagnostic\n            )\n        metrics()\n        failure_recorded = True\n        try:\n            await settled_call(\n                store.change,\n                lease,\n                "DEMO_PRIVATE_SESSION_FAILED",\n                lambda ledger: setattr(\n                    ledger,\n                    "last_private_session_failure",\n                    coordinator.session_diagnostic.model_copy(deep=True),\n                ),\n            )\n        except Exception:\n            pass\n\n    try:\n        coordinator.session_diagnostic.stage = "CONNECT"\n        async with connector(client.private_url(key)) as websocket:\n            inbox = EventInbox(\n                lambda: int(store.now().timestamp() * 1000),\n                receive_failed,\n                validate_time=lambda stamp, detail: validate_event_time_async(\n                    client, stamp, detail\n                ),\n            )\n            reader = asyncio.create_task(inbox.run(websocket))\n            try:\n                # Begin receiving before slow REST setup or an entry callback.\n                await asyncio.sleep(0)\n                inbox.raise_if_failed()\n                coordinator.session_diagnostic.stage = "RECONCILE"\n                await settled_call(coordinator.connected)\n                inbox.raise_if_failed()\n                if on_ready:\n                    await settled_call(store.renew, lease)\n                    await settled_call(client.sync_clock)\n                    inbox.raise_if_failed()\n                    coordinator.session_diagnostic.stage = "READY_CALLBACK"\n                    callback_start = time.monotonic()\n                    try:\n                        await settled_call(on_ready)\n                    finally:\n                        coordinator.session_diagnostic.ready_callback_ms = min(\n                            3600000, max(0, int((time.monotonic() - callback_start) * 1000))\n                        )\n                    inbox.raise_if_failed()\n                coordinator.session_diagnostic.stage = "EXPIRY"\n                await settled_call(coordinator.expire)\n                inbox.raise_if_failed()\n                count = 0\n                while max_messages is None or count < max_messages:\n                    coordinator.session_diagnostic.stage = "HEARTBEAT"\n                    await settled_call(store.renew, lease)\n                    await settled_call(client.sync_clock)\n                    inbox.raise_if_failed()\n                    if store.now() - renewed >= timedelta(minutes=25):\n                        coordinator.session_diagnostic.stage = "KEY_RENEW"\n                        await settled_call(\n                            store.change,\n                            lease,\n                            "DEMO_SESSION_RENEW",\n                            lambda ledger: client.listen_key("PUT"),\n                        )\n                        renewed = store.now()\n                        inbox.raise_if_failed()\n                    coordinator.session_diagnostic.stage = "EXPIRY"\n                    await settled_call(coordinator.expire)\n                    inbox.raise_if_failed()\n                    wait_seconds = await settled_call(entry_wait_seconds, coordinator)\n                    inbox.raise_if_failed()\n                    try:\n                        coordinator.session_diagnostic.stage = "RECEIVE"\n                        coordinator.session_diagnostic.event_kind = "NONE"\n                        coordinator.session_diagnostic.event_age_ms = None\n                        coordinator.session_diagnostic.event_receive_age_ms = None\n                        coordinator.session_diagnostic.event_clock_wait_ms = 0\n                        hint = await inbox.take(timeout=wait_seconds)\n                        coordinator.session_diagnostic.stage = "EVENT"\n                        (\n                            coordinator.session_diagnostic.event_kind,\n                            coordinator.session_diagnostic.event_age_ms,\n                        ) = event_info(hint.event(), int(store.now().timestamp() * 1000))\n                        coordinator.session_diagnostic.event_receive_age_ms = hint.receive_age_ms\n                        coordinator.session_diagnostic.event_clock_wait_ms = hint.clock_wait_ms\n                        metrics()\n                        # Still checks original E against NOW and establishes\n                        # strict REST truth. Never rewrites/relaxes an old hint.\n                        await settled_call(coordinator.event, hint.event())\n                        count += 1\n                        inbox.raise_if_failed()\n                    except TimeoutError:\n                        inbox.raise_if_failed()\n                        coordinator.session_diagnostic.stage = "EXPIRY"\n                        await settled_call(coordinator.expire)\n                        inbox.raise_if_failed()\n                        coordinator.session_diagnostic.stage = "PING"\n                        pong = await websocket.ping()\n                        await asyncio.wait_for(pong, timeout=5)\n                        inbox.raise_if_failed()\n                        await settled_call(coordinator.connected)\n                        inbox.raise_if_failed()\n                    coordinator.session_diagnostic.stage = "EXPIRY"\n                    await settled_call(coordinator.expire)\n                    inbox.raise_if_failed()\n            finally:\n                # Only the receiver reads the socket; stop it before intentional\n                # socket closure so closure cannot become a fabricated failure.\n                current_task = asyncio.current_task()\n                cancellations = current_task.cancelling() if current_task is not None else 0\n                reader.cancel()\n                while not reader.done():\n                    try:\n                        await asyncio.shield(reader)\n                    except asyncio.CancelledError:\n                        continue\n                if not reader.cancelled():\n                    reader.exception()\n                metrics()\n                if current_task is not None and current_task.cancelling() > cancellations:\n                    raise asyncio.CancelledError\n    except Exception as error:\n        await record_failure(error)\n        try:\n            await settled_call(coordinator.disconnect)\n        except Exception:\n            pass\n        raise DemoFailure("DEMO private connection/session failed; entries blocked") from None\n    finally:\n        # Validation cancellation must not hide a receiver failure observed\n        # while a DB worker was draining. Capture before normal cleanup.\n        if inbox is not None and inbox.failure is not None and not failure_recorded:\n            await record_failure(DemoFailure("DEMO private receiver failed; entries blocked"))\n        # Session closure never cancels SL/TP. Fencing prevents a stale worker deleting a new leader\'s key.\n        try:\n            await settled_call(client.sync_clock)\n            await settled_call(coordinator.command, uuid4(), "PAUSE_ENTRIES")\n        except Exception:\n            pass\n        try:\n            await settled_call(coordinator.disconnect)\n            await settled_call(\n                store.change,\n                lease,\n                "DEMO_SESSION_CLOSE",\n                lambda ledger: client.listen_key("DELETE"),\n            )\n        except Exception:\n            pass\n',
    "tests/unit/test_demo_expiry_wait.py": '"""Actual session control flow with synthetic clock, stores and socket only."""\n\nimport asyncio\nfrom contextlib import asynccontextmanager\nfrom datetime import UTC, datetime, timedelta\nfrom types import SimpleNamespace\n\nimport pytest\nfrom pydantic import SecretStr\n\nfrom integrations.binance_usdm.demo import DemoFailure\nfrom services.execution import demo_stream as module\n\n\n@pytest.mark.parametrize("path", ["idle", "event", "slow_callback"])\ndef test_expiry_runs_after_callback_wait_and_reconciliation(monkeypatch, path):\n    async def run():\n        base = datetime(2026, 11, 3, tzinfo=UTC)\n        clock = [0]\n        order = SimpleNamespace(\n            remaining=1, signal=SimpleNamespace(expires_at=base + timedelta(seconds=10))\n        )\n        account = SimpleNamespace(orders={"target": order})\n        trace = []\n        ledger = SimpleNamespace()\n\n        def record(name, advance=0):\n            clock[0] += advance\n            trace.append((name, clock[0]))\n\n        class Store:\n            def now(self):\n                return base + timedelta(seconds=clock[0])\n\n            def read(self, account_id):\n                return account\n\n            def renew(self, lease):\n                record("renew")\n\n            def change(self, lease, kind, apply):\n                record(kind)\n                return apply(ledger)\n\n        class Inbox:\n            received = coalesced = 0\n            failure = None\n\n            def __init__(self, *args, **kwargs):\n                pass\n\n            async def run(self, websocket):\n                record("reader_started")\n                await asyncio.Future()\n\n            def raise_if_failed(self):\n                pass\n\n            async def take(self, timeout=5):\n                assert timeout == (5 if path == "slow_callback" else 2)\n                if path != "event":\n                    record("deadline_wait", timeout)\n                    raise TimeoutError\n                record("event_received", 1)\n                return SimpleNamespace(\n                    event=lambda: {"e": "ACCOUNT_UPDATE", "E": int(base.timestamp() * 1000)},\n                    receive_age_ms=0,\n                    clock_wait_ms=0,\n                )\n\n        class Socket:\n            async def ping(self):\n                record("ping")\n                assert not order.remaining\n                raise ValueError("STOP_AFTER_VERIFYING_CANCEL_PRECEDES_PING")\n\n        @asynccontextmanager\n        async def connector(url):\n            yield Socket()\n\n        def connected():\n            # Initial reconciliation has no delay; idle pong reconciliation does.\n            record("connected", 2 if "deadline_wait" in [x[0] for x in trace] else 0)\n\n        def event(raw):\n            record("event_reconcile", 4)\n\n        def expire():\n            record("expire")\n            if clock[0] >= 10 and order.remaining:\n                order.remaining = 0\n                record("cancel")\n                if path == "event":\n                    raise ValueError("STOP_AFTER_EVENT_EXPIRY")\n\n        def callback():\n            assert any(name == "reader_started" for name, _ in trace)\n            record("callback_finished", 14 if path == "slow_callback" else 8)\n\n        coordinator = SimpleNamespace(\n            store=Store(),\n            lease=SimpleNamespace(account_id="DEMO-test"),\n            connected=connected,\n            event=event,\n            expire=expire,\n            command=lambda *args: record("cleanup_pause"),\n            disconnect=lambda: record("disconnect"),\n            client=SimpleNamespace(\n                listen_key=lambda method: SecretStr("synthetic"),\n                private_url=lambda key: SecretStr("synthetic"),\n                sync_clock=lambda: record("clock_sync"),\n            ),\n        )\n        monkeypatch.setattr(module, "EventInbox", Inbox)\n        with pytest.raises(DemoFailure):\n            await module.session(coordinator, connector=connector, on_ready=callback)\n        canceled = [stamp for name, stamp in trace if name == "cancel"]\n        assert canceled == [14 if path == "slow_callback" else 13 if path == "event" else 10]\n        names = [name for name, _ in trace]\n        assert names.index("expire") < names.index("clock_sync", names.index("callback_finished"))\n        if path != "event":\n            assert names.index("cancel") < names.index("ping")\n        assert names.index("cleanup_pause") > names.index("cancel")\n\n    asyncio.run(run())\n\n\n@pytest.mark.parametrize(\n    "seconds,expected", [(None, 5), (-1, 0.001), (0, 0.001), (0.2, 0.2), (12, 5)]\n)\ndef test_wait_uses_nearest_remaining_entry_only(seconds, expected):\n    now = datetime(2026, 11, 3, tzinfo=UTC)\n    orders = {\n        "filled": SimpleNamespace(\n            remaining=0, signal=SimpleNamespace(expires_at=now - timedelta(seconds=50))\n        )\n    }\n    if seconds is not None:\n        orders["entry"] = SimpleNamespace(\n            remaining=1, signal=SimpleNamespace(expires_at=now + timedelta(seconds=seconds))\n        )\n        orders["later"] = SimpleNamespace(\n            remaining=1, signal=SimpleNamespace(expires_at=now + timedelta(seconds=20))\n        )\n    c = SimpleNamespace(\n        store=SimpleNamespace(read=lambda _: SimpleNamespace(orders=orders), now=lambda: now),\n        lease=SimpleNamespace(account_id="DEMO-test"),\n    )\n    assert module.entry_wait_seconds(c) == expected\n',
    "tests/integration/test_demo_expiry_fill_race.py": '"""Expiry cancellation still reconciles a fill racing with an unfilled ledger."""\n\nfrom datetime import timedelta\nfrom decimal import Decimal\n\nimport pytest\n\nfrom tests.integration.test_demo import (\n    enter,\n    posts,\n    system,  # noqa: F401\n)\n\n\n@pytest.mark.parametrize("partial", [False, True])\ndef test_expiry_reconciles_racing_partial_fill_and_preserves_protection(system, partial):  # noqa: F811\n    store, c, fake = system\n    sig, order = enter(system)\n    filled = order.quantity / 2 if partial else Decimal(0)\n    if partial:\n        # No prior event/reconcile: the cancellation races an unseen venue fill.\n        fake.fill(order.client_id, filled)\n    fake.at = sig.expires_at + timedelta(milliseconds=1)\n    store.renew(c.lease)\n    c.client.sync_clock()\n    c.expire()\n    current = store.read("DEMO-test").orders[str(sig.signal_id)]\n    assert current.remaining == 0 and current.filled == filled\n    assert len(posts(fake)) == 1  # Never creates a replacement entry.\n    if partial:\n        assert current.protected and current.algo_id and current.tp_algo_id\n        assert c._stop_ok(\n            current,\n            {\n                k: str(v).lower() if isinstance(v, bool) else v\n                for k, v in fake.algos[current.algo_id].items()\n            },\n        )\n        assert fake.algos[current.tp_algo_id]["algoStatus"] == "NEW"\n        assert fake.algos[current.tp_algo_id]["orderType"] == "TAKE_PROFIT_MARKET"\n        assert fake.algos[current.tp_algo_id]["closePosition"] is True\n        assert current.open_quantity == filled\n        assert len(posts(fake, "/fapi/v1/algoOrder")) == 2\n        assert not any(m == "DELETE" and p == "/fapi/v1/algoOrder" for m, p, _ in fake.calls)\n    else:\n        assert not current.open_quantity\n        assert not posts(fake, "/fapi/v1/algoOrder")\n    before = len(fake.calls)\n    c.expire()\n    assert len(fake.calls) == before\n',
}
SELECTED = [
    "tests/unit/test_demo_expiry_wait.py",
    "tests/unit/test_demo_event_inbox.py",
    "tests/fault_injection/test_demo_stream.py",
    "tests/integration/test_demo_event_inbox_validation.py",
    "tests/integration/test_demo_worker_drain.py",
    "tests/integration/test_demo_disconnect_drain.py",
    "tests/integration/test_demo_tp_trigger_check.py",
    "tests/integration/test_demo_expiry_fill_race.py",
    "tests/integration/test_demo_validation.py",
    "tests/integration/test_demo.py",
]


class Counts:
    def __init__(self):
        self.collected = self.passed = self.failed = self.skipped = 0

    def pytest_collection_finish(self, session):
        self.collected = len(session.items)

    def pytest_runtest_logreport(self, report):
        if report.when == "call" and report.passed:
            self.passed += 1
        if report.failed:
            self.failed += 1
        if report.skipped:
            self.skipped += 1


def scope():
    if (
        os.getenv("ISOLATED_PHASE4_FAULT_CHECK") != "1"
        or os.getenv("TEST_DATABASE_URL") != DATABASE
        or os.getenv("LIVE_TRADING_ENABLED", "false").lower() != "false"
        or os.getenv("TRADING_MODE", "PAPER").upper() != "PAPER"
        or "DATABASE_URL" in os.environ
        or any(name.startswith("BINANCE_") for name in os.environ)
        or Path("/run/demo-keys").exists()
        or Path.cwd() != Path("/app")
    ):
        raise ValueError("ISOLATED_SCOPE_REQUIRED")


def main():
    temporary = None
    try:
        scope()
        temporary = tempfile.TemporaryDirectory(prefix="expiry-review-")
        root = Path(temporary.name)
        for name, digest in BASE_HASHES.items():
            path = Path("/app") / name
            if (
                path.is_symlink()
                or hashlib.sha256(path.read_bytes()).hexdigest() != digest
            ):
                raise ValueError("TEST_IMAGE_SOURCE_MISMATCH")
            target = root / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(path.read_bytes())
        for name, source in OVERLAY.items():
            (root / name).write_text(source)
        os.chdir(root)
        sys.path.insert(0, str(root))
        import pytest
        from sqlalchemy import create_engine, text

        engine = create_engine(DATABASE, connect_args={"connect_timeout": 2})
        try:
            with engine.connect() as conn:
                if (
                    conn.execute(text("SELECT current_database()")).scalar_one()
                    != "hybrid_fault_review"
                ):
                    raise ValueError("DEDICATED_DATABASE_REQUIRED")
        finally:
            engine.dispose()
    except Exception:  # noqa: BLE001 -- fixed classification; never print private context
        print(
            json.dumps(
                {
                    "expiry_check": "BLOCKED_SCOPE_IMAGE_OR_TEST_DATABASE",
                    "details_logged": False,
                    "orders_enabled": False,
                    "live_trading_enabled": False,
                }
            ),
            flush=True,
        )
        if temporary is not None:
            temporary.cleanup()
        raise SystemExit(2) from None
    try:
        counts = Counts()
        result = pytest.main(
            ["-q", "-p", "no:cacheprovider", *SELECTED], plugins=[counts]
        )
        passed = (
            result == 0
            and counts.collected == counts.passed == 96
            and counts.failed == counts.skipped == 0
        )
        print(
            json.dumps(
                {
                    "expiry_check": "ISOLATED_SYNTHETIC_EXPIRY_CHECK_PASSED"
                    if passed
                    else "NOT_ACCEPTED",
                    "collected": counts.collected,
                    "passed": counts.passed,
                    "failed": counts.failed,
                    "skipped": counts.skipped,
                    "scope": "SYNTHETIC_TRANSPORT_LOOPBACK_WS_DEDICATED_TMPFS_PG",
                    "checked_base_files": len(BASE_HASHES),
                    "overlay_files": len(OVERLAY),
                    "real_exchange_calls": 0,
                    "real_demo_account_verified": False,
                    "orders_enabled": False,
                    "live_trading_enabled": False,
                }
            ),
            flush=True,
        )
        return 0 if passed else 2
    finally:
        os.chdir("/app")
        temporary.cleanup()


if __name__ == "__main__":
    raise SystemExit(main())
