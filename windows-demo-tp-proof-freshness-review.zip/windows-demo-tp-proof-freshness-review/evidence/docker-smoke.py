import json
from tempfile import TemporaryDirectory
from uuid import uuid4
from pathlib import Path
from datetime import UTC,datetime,timedelta
from pydantic import SecretStr
from integrations.binance_usdm.demo_tp_admission import TPModelProfile
from integrations.binance_usdm.demo_tp_weight_model import MODELED_TP_ROUTE_COSTS
from integrations.binance_usdm.demo_tp_window_budget import ProofDeferred
from integrations.binance_usdm.rest import RESTResponse
from packages.persistence.demo_shared_weight import SharedWeightJournal,STARTUP_HOLD
from packages.persistence.demo_order_quota import LocalQuotaStopped
from services.execution.demo_managed_runtime import OwnedSharedBudget,assemble_managed_runtime
seconds=[0.0];calls=[]
def send(method,path,query,key):
    calls.append(path)
    return RESTResponse(200,b'{}',{'x-mbx-used-weight-1m':'600'})
with TemporaryDirectory() as directory:
    j=SharedWeightJournal.create(Path(directory),'DEMO-smoke',uuid4(),monotonic=lambda:seconds[0],wall_clock=lambda:datetime(2026,11,10,tzinfo=UTC)+timedelta(seconds=seconds[0]),boot=lambda:'smoke')
    seconds[0]=STARTUP_HOLD
    # Gate-only smoke: no order bridge, assembly, PostgreSQL, or order paths.
    b=OwnedSharedBudget(send,TPModelProfile(0),MODELED_TP_ROUTE_COSTS,bridge=None,shared=j,allow_synthetic_model_execution=True,monotonic=lambda:seconds[0])
    try:
        b.require_proof(100)
        raise AssertionError('missing observation admitted')
    except ProofDeferred:pass
    assert not calls and not b.stopped
    b('GET','/fapi/v1/time',SecretStr(''),None)
    b.require_proof(100)
    seconds[0]+=6
    try:
        b.require_proof(100)
        raise AssertionError('stale observation admitted')
    except ProofDeferred:pass
    assert len(calls)==1 and b.total_charge==1 and j.view()['pending_attempts']==0
    b('GET','/fapi/v1/time',SecretStr(''),None)
    b.require_proof(100)
    assert len(calls)==2 and b.total_charge==2 and not b.stopped
try:
    assemble_managed_runtime(None,None,None,None,None)
    raise AssertionError('execution enabled')
except LocalQuotaStopped as e:assert str(e)=='RUNTIME_REAL_EXECUTION_DISABLED'
print(json.dumps(dict(smoke='PASSED',network='NONE',scope='GATE_ONLY_SQLITE_NO_ORDER_BRIDGE',missing_and_stale_observation_deferred=True,explicit_read_recovers=True,implicit_reads=0,default_execution_refused=True,actual_exchange_requests=0)))
