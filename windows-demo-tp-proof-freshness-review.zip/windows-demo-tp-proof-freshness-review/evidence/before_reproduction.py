"""Require current authoritative metadata before starting a full proof batch."""

# ruff: noqa: F811
import sqlite3

import pytest
from pydantic import SecretStr

from integrations.binance_usdm.demo_tp_window_budget import ProofDeferred
from integrations.binance_usdm.rest import RESTResponse
from tests.integration.test_demo import system as demo_system  # noqa: F401
from tests.integration.test_managed_order_quota import managed  # noqa: F401
from tests.integration.test_managed_runtime_assembly import assembly  # noqa: F401
from tests.integration.test_quota_startup_review import snapshot
from tests.integration.test_runtime_header_provenance import prepared
from tests.unit.test_quota_startup_read_only import files


@pytest.mark.parametrize('age', [5.001, 6.0, 60.002])
def test_stale_observation_defers_full_proof_before_reservation_or_send(assembly, age):
    calls = []

    def send(method, path, query, key):
        calls.append((method, path))
        return RESTResponse(200, b'{}', {'x-mbx-used-weight-1m': '600'})
    session, b = prepared(assembly, send)
    try:
        assembly[3].seconds += age
        before = b.shared.read_only_snapshot()
        domain, disk = (snapshot(assembly[0]), files(assembly[8].order_directory))
        shared_disk = files(b.shared.directory)
        previous = (b.total_charge, b.forwarded, b.header_at, b.header_sequence, len(calls))
        with pytest.raises(ProofDeferred):
            b.require_proof(session.coordinator.proof_batch)
        assert b.shared.read_only_snapshot() == before
        assert snapshot(assembly[0]) == domain
        assert files(assembly[8].order_directory) == disk and files(b.shared.directory) == shared_disk
        assert (b.total_charge, b.forwarded, b.header_at, b.header_sequence, len(calls)) == previous
        assert not b.stopped and (not b.untrusted)
    finally:
        session.close()
