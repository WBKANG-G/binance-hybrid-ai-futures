import json
from unittest.mock import patch
from packages.persistence.demo_order_quota import LocalQuotaStopped
from services.execution.demo_managed_runtime import assemble_managed_runtime
from services.execution.demo_runtime_observation import RuntimeObservationCoordinator
c=object.__new__(RuntimeObservationCoordinator)
c._require_confirmation_bindings=lambda:None
c.session_failed=False
c._confirmation_base=object();c._confirmation_lease=object()
seen=[]
def reject(store,lease):
 assert store is c._confirmation_base and lease is c._confirmation_lease
 seen.append(True)
 raise LocalQuotaStopped('RUNTIME_CURRENT_LEASE_REQUIRED')
with patch('services.execution.demo_runtime_observation.current_runtime_ledger',reject):
 try:
  c._require_owned_flat_observation()
 except LocalQuotaStopped as error:
  assert str(error)=='RUNTIME_CURRENT_LEASE_REQUIRED'
 else:
  raise AssertionError('lost lease admitted')
assert seen==[True]
try:
 assemble_managed_runtime(None,None,None,None,None)
except LocalQuotaStopped as error:
 assert str(error)=='RUNTIME_REAL_EXECUTION_DISABLED'
else:
 raise AssertionError('execution enabled')
print(json.dumps(dict(smoke='PASSED',network='NONE',scope='CURRENT_LEASE_GUARD_WITH_STUBBED_BINDING_AND_DEFAULT_REFUSAL',real_postgresql_checked_here=False,actual_exchange_requests=0,execution_approved=False)))
