"""Scheduler-only deadline checks; no synthetic flat proof is fabricated."""

# ruff: noqa: F811
import asyncio
from decimal import Decimal
from types import SimpleNamespace

import pytest

from integrations.binance_usdm.demo_tp_window_budget import ProofDeferred
from integrations.binance_usdm.rest import RESTResponse
from services.execution import demo_tp_budget_integration as legacy
from tests.integration.test_demo import system as demo_system  # noqa: F401
from tests.integration.test_managed_order_quota import managed  # noqa: F401
from tests.integration.test_managed_runtime_assembly import assembly  # noqa: F401
from tests.integration.test_runtime_header_provenance import prepared


def scheduler(assembly, monkeypatch, scenario):
    def send(method, path, query, key):
        return RESTResponse(200, b"{}", {"x-mbx-used-weight-1m": "600"})

    session, b = prepared(assembly, send)
    c = session.coordinator
    state = dict(now=0.0, calls=[], sleeps=[])
    amounts = {
        "renew": 120,
        "refresh": 120,
        "position": 120,
        "proof": 120,
        "defer": 119,
        "clip": 119.5,
    }

    def stage(name):
        state["calls"].append(name)
        if (
            (name == "renew" and scenario in {"renew", "defer", "clip"})
            or (name == "clock" and scenario == "refresh")
            or (name == "position" and scenario == "position")
            or (name == "proof" and scenario == "proof")
        ):
            state["now"] += amounts[scenario]

    def clock():
        return state["now"]

    async def pause(delay):
        stage("sleep")
        state["sleeps"].append(delay)
        state["now"] += delay
        await asyncio.sleep(0)

    def physical():
        stage("position")
        b.flat_observed = True
        return Decimal(0), Decimal(0)

    def require(cost):
        stage("admit")
        if scenario in {"defer", "clip"}:
            raise ProofDeferred

    def confirm():
        stage("proof")
        return "UNKNOWN"

    monkeypatch.setattr(legacy, "time", SimpleNamespace(monotonic=clock))
    monkeypatch.setattr(
        legacy, "asyncio", SimpleNamespace(to_thread=asyncio.to_thread, sleep=pause)
    )
    monkeypatch.setattr(c.store, "renew", lambda lease: stage("renew"))
    monkeypatch.setattr(c.client, "sync_clock", lambda: stage("clock"))
    monkeypatch.setattr(c, "_physical_position", physical)
    monkeypatch.setattr(c, "confirm_flat", confirm)
    monkeypatch.setattr(b, "require_proof", require)
    monkeypatch.setattr(b, "_fresh", lambda now: scenario != "refresh")
    b.flat_observed = scenario != "position"
    c._confirmation_clock = clock
    c._confirmation_sleep = pause
    return session, c, state


@pytest.mark.parametrize('scenario,expected', [('renew', ['renew']), ('refresh', ['renew', 'clock']), ('position', ['renew', 'position']), ('proof', ['renew', 'admit', 'proof']), ('defer', ['renew', 'position', 'admit', 'sleep']), ('clip', ['renew', 'position', 'admit', 'sleep'])])
def test_no_new_confirmation_phase_starts_after_admission_deadline(assembly, monkeypatch, scenario, expected):
    session, c, state = scheduler(assembly, monkeypatch, scenario)
    try:
        assert asyncio.run(c.confirm_exit_budgeted()) == 'UNKNOWN'
        assert state['calls'] == expected
        if scenario == 'clip':
            assert state['sleeps'] == [0.5]
        assert c.budgeted_flat_confirmation == 'UNKNOWN'
    finally:
        session.close()
