import json
from services.execution.demo_runtime_confirmation import ConfirmationWindow,ConfirmationWindowClosed,RuntimeConfirmationCoordinator
from services.execution.demo_managed_order_quota import ManagedQuotaTPTriggerCoordinator
from services.execution.demo_managed_runtime import assemble_managed_runtime
from packages.persistence.demo_order_quota import LocalQuotaStopped
seconds=[0.0]
w=ConfirmationWindow(lambda:seconds[0])
seconds[0]=119.5
assert w.remaining()==0.5
seconds[0]=120.0
try:
    w.remaining()
    raise AssertionError('expired window admitted work')
except ConfirmationWindowClosed as error:assert error.reason=='START_DEADLINE_REACHED'
try:
    ConfirmationWindow(lambda:float('nan'))
    raise AssertionError('invalid clock accepted')
except ConfirmationWindowClosed as error:assert error.reason=='CLOCK_UNTRUSTED'
assert issubclass(RuntimeConfirmationCoordinator,ManagedQuotaTPTriggerCoordinator)
try:
    assemble_managed_runtime(None,None,None,None,None)
    raise AssertionError('execution enabled')
except LocalQuotaStopped as error:assert str(error)=='RUNTIME_REAL_EXECUTION_DISABLED'
print(json.dumps(dict(smoke='PASSED',network='NONE',scope='WINDOW_ARITHMETIC_IMPORTS_DEFAULT_REFUSAL_ONLY',expired_window_refused=True,invalid_clock_refused=True,original_coordinator_inherited=True,default_execution_refused=True,actual_exchange_requests=0)))
