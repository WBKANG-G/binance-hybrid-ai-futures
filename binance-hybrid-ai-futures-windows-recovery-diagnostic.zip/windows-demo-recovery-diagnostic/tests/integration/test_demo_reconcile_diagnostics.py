"""Fail-closed diagnostics and protection guards; no remote exchange access."""

import pytest

import services.execution.demo as module
from integrations.binance_usdm.demo import DemoFailure
from packages.domain.contracts import PositionState
from tests.integration.test_demo import (
    enter,
    posts,
    system,  # noqa: F401
)


@pytest.mark.parametrize("blocked", ["closed", "exit_pending", "zero"])
def test_protection_does_not_post_for_ineligible_position(system, blocked):  # noqa: F811
    store, c, fake = system
    sig, order = enter(system)
    fake.fill(order.client_id, order.quantity)
    c.reconcile()

    def block(ledger):
        current = ledger.orders[str(sig.signal_id)]
        current.algo_id = None
        current.tp_algo_id = None
        ledger.requests = {}
        if blocked == "closed":
            current.position_state = PositionState.CLOSED
        elif blocked == "exit_pending":
            current.position_state = PositionState.EXIT_PENDING
        else:
            current.open_quantity = 0

    store.change(c.lease, "TEST_BLOCK_PROTECTION", block)
    before = len(posts(fake, "/fapi/v1/algoOrder"))
    c._protect(str(sig.signal_id), "SL")
    c._protect(str(sig.signal_id), "TP")
    assert len(posts(fake, "/fapi/v1/algoOrder")) == before


def test_changed_snapshot_retains_emergency_exit_and_safe_reason(system, monkeypatch):  # noqa: F811
    store, c, fake = system
    _, order = enter(system)
    fake.fill(order.client_id, order.quantity)
    real = module.snapshot
    calls = 0

    def changing(*args):
        nonlocal calls
        result = real(*args)
        calls += 1
        if calls == 2:
            result.fingerprint = "changed"
        return result

    monkeypatch.setattr(module, "snapshot", changing)
    with pytest.raises(DemoFailure, match="changed mid-reconciliation"):
        c.reconcile()
    assert store.read("DEMO-test").reconciliation_failure_code == "SNAPSHOT_CHANGED"
    assert fake.positions["BTCUSDT"] == 0
    assert len(posts(fake, "/fapi/v1/algoOrder")) == 0
    assert all(p["type"] == "LIMIT" or p.get("reduceOnly") == "true" for p in posts(fake))
