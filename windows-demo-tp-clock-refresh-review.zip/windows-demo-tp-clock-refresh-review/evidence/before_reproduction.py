"""A rejected SDK clock response cannot authorize proof through its weight header."""
# ruff: noqa: F811

import asyncio
import sqlite3

import pytest

from integrations.binance_usdm.demo import DemoClockSample, DemoFailure
from integrations.binance_usdm.demo_tp_admission import TPAdmissionStopped
from integrations.binance_usdm.demo_tp_window_budget import ProofDeferred
from integrations.binance_usdm.rest import RESTResponse
from tests.integration.test_demo import system as demo_system  # noqa: F401
from tests.integration.test_managed_order_quota import managed  # noqa: F401
from tests.integration.test_managed_runtime_assembly import assembly  # noqa: F401
from tests.integration.test_runtime_header_provenance import prepared


@pytest.mark.parametrize('fault', ['missing_time', 'wrong_shape', 'malformed_json', 'boolean_time', 'offset', 'slow_rtt'])
def test_rejected_clock_body_or_sample_cannot_leave_proof_admissible(assembly, fault):
    calls = []
    bodies = {'missing_time': b'{}', 'wrong_shape': b'[]', 'malformed_json': b'{', 'boolean_time': b'{"serverTime":true}', 'offset': b'{"serverTime":1005000}', 'slow_rtt': b'{"serverTime":1000000}'}

    def send(method, path, query, key):
        calls.append(path)
        return RESTResponse(200, bodies[fault], {'x-mbx-used-weight-1m': '600'})
    session, b = prepared(assembly, send)
    client = session.coordinator.client
    client.synced_at = 999000
    client.clock_sample = DemoClockSample(999000, 999000, 999000)
    ticks = iter([1000000, 1000000, 1001001] if fault == 'slow_rtt' else [1000000] * 3)
    client.clock_ms = lambda: next(ticks, 1001001 if fault == 'slow_rtt' else 1000000)
    try:
        assembly[3].seconds += 6
        with pytest.raises(ProofDeferred):
            b.require_proof(session.coordinator.proof_batch)
        with pytest.raises(DemoFailure):
            client.sync_clock()
        assert b.untrusted and b.stopped
        assert not b._fresh(b.clock())
        assert client.synced_at is None and client.clock_sample is None
        with pytest.raises(TPAdmissionStopped):
            b.require_proof(session.coordinator.proof_batch)
        assert calls == ['/fapi/v1/time'] * 2 and b.total_charge == 2
        assert b.shared.read_only_snapshot()['pending_attempts'] == 0
    finally:
        session.close()
