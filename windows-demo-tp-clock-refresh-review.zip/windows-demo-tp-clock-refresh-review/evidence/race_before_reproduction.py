"""A rejected SDK clock response cannot authorize proof through its weight header."""
# ruff: noqa: F811

import asyncio
import sqlite3

import pytest

from integrations.binance_usdm.demo import DemoClockSample, DemoFailure
from integrations.binance_usdm.demo_tp_admission import TPAdmissionStopped
from integrations.binance_usdm.demo_tp_window_budget import ProofDeferred
from integrations.binance_usdm.rest import RESTResponse
from tests.integration.test_demo import system as demo_system  # noqa: F401
from tests.integration.test_managed_order_quota import managed  # noqa: F401
from tests.integration.test_managed_runtime_assembly import assembly  # noqa: F401
from tests.integration.test_runtime_header_provenance import prepared


def test_proof_cannot_enter_while_clock_response_validation_is_pending(assembly):
    from concurrent.futures import ThreadPoolExecutor
    from threading import Event
    validation_pending, release_validation, proof_started = (Event(), Event(), Event())

    def send(method, path, query, key):
        return RESTResponse(200, b'{"serverTime":true}', {'x-mbx-used-weight-1m': '600'})
    session, b = prepared(assembly, send)
    client = session.coordinator.client
    reads = 0

    def clock_ms():
        nonlocal reads
        reads += 1
        if reads == 3:
            validation_pending.set()
            assert release_validation.wait(5)
        return 1000000
    client.clock_ms = clock_ms

    def proof():
        proof_started.set()
        b.require_proof(session.coordinator.proof_batch)
    try:
        with ThreadPoolExecutor(max_workers=2) as workers:
            refreshing = workers.submit(client.sync_clock)
            try:
                assert validation_pending.wait(5)
                checking = workers.submit(proof)
                assert proof_started.wait(5)
                with pytest.raises(TimeoutError):
                    checking.result(timeout=0.2)
            finally:
                release_validation.set()
            with pytest.raises(DemoFailure):
                refreshing.result(timeout=5)
            with pytest.raises(TPAdmissionStopped):
                checking.result(timeout=5)
        assert b.untrusted and b.stopped
    finally:
        release_validation.set()
        session.close()
