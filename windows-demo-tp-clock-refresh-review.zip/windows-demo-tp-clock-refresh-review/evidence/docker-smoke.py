import json,yaml
from tempfile import TemporaryDirectory
from uuid import uuid4
from pathlib import Path
from datetime import UTC,datetime,timedelta
from pydantic import SecretStr
from integrations.binance_usdm.demo import DemoSettings,DemoCredentials,DemoFailure
from integrations.binance_usdm.demo_tp_admission import TPModelProfile,TPAdmissionStopped
from integrations.binance_usdm.demo_tp_weight_model import MODELED_TP_ROUTE_COSTS
from integrations.binance_usdm.rest import RESTResponse
from packages.persistence.demo_shared_weight import SharedWeightJournal,STARTUP_HOLD
from packages.persistence.demo_order_quota import LocalQuotaStopped
from services.execution.demo_managed_runtime import OwnedSharedBudget,assemble_managed_runtime
from services.execution.demo_runtime_guards import RuntimeBoundClient
seconds=[0.0];calls=[]
def send(method,path,query,key):
    calls.append(path)
    return RESTResponse(200,b'{',{'x-mbx-used-weight-1m':'600'})
with TemporaryDirectory() as directory:
    j=SharedWeightJournal.create(Path(directory),'DEMO-smoke',uuid4(),monotonic=lambda:seconds[0],wall_clock=lambda:datetime(2026,11,10,tzinfo=UTC)+timedelta(seconds=seconds[0]),boot=lambda:'smoke')
    seconds[0]=STARTUP_HOLD
    b=OwnedSharedBudget(send,TPModelProfile(0),MODELED_TP_ROUTE_COSTS,bridge=None,shared=j,allow_synthetic_model_execution=True,monotonic=lambda:seconds[0])
    settings=DemoSettings.model_validate(yaml.safe_load(Path('/app/configs/demo-isolated.example.yaml').read_text()))
    c=RuntimeBoundClient(settings,DemoCredentials(SecretStr('synthetic-key'),SecretStr('synthetic-secret')),send=b,clock_ms=lambda:1_000_000,on_clock_failure=b.invalidate_clock_observation,clock_guard=b.lifetime)
    try:
        c.sync_clock()
        raise AssertionError('invalid JSON accepted')
    except DemoFailure:pass
    assert b.stopped and b.untrusted and c.synced_at is None and c.clock_sample is None
    try:
        b.require_proof(100)
        raise AssertionError('invalid refresh authorized proof')
    except TPAdmissionStopped:pass
    assert len(calls)==1 and b.total_charge==1 and j.view()['pending_attempts']==0
try:
    assemble_managed_runtime(None,None,None,None,None)
    raise AssertionError('execution enabled')
except LocalQuotaStopped as e:assert str(e)=='RUNTIME_REAL_EXECUTION_DISABLED'
print(json.dumps(dict(smoke='PASSED',network='NONE',scope='CLIENT_AND_GATE_ONLY_SQLITE_NO_ORDER_BRIDGE',rejected_sdk_refresh_stops_proof=True,known_response_retains_completed_weight=True,transport_retries=0,default_execution_refused=True,actual_exchange_requests=0)))
