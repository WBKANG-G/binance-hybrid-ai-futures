"""Malformed public filters must not prevent observation or permit writes."""

from copy import deepcopy
from types import SimpleNamespace

import pytest

from integrations.binance_usdm.demo import DemoFailure
from services.execution.demo import DemoCoordinator
from tests.fixtures.binance import exchange_info


def coordinator(enabled=False):
    info = deepcopy(exchange_info())
    bad = deepcopy(info["symbols"][0])
    bad["symbol"] = "TUSDT"
    for f in bad["filters"]:
        if f["filterType"] == "LOT_SIZE":
            f["stepSize"] = "0"
    info["symbols"].append(bad)
    settings = SimpleNamespace(policy="synthetic", demo_trading_enabled=enabled)
    client = SimpleNamespace(settings=settings, public=lambda path: info)
    store = SimpleNamespace(read=lambda account: SimpleNamespace(policy="synthetic"))
    return DemoCoordinator(store, SimpleNamespace(account_id="DEMO-test"), client), info


def test_read_only_reports_invalid_symbol_without_weakening_valid_rules():
    c, info = coordinator()
    c.refresh_metadata()
    assert c.excluded_symbols == {"TUSDT": "INVALID_SYMBOL_FILTERS"}
    assert "TUSDT" not in c.rules
    assert info["symbols"][0]["symbol"] in c.rules
    assert c.rules[info["symbols"][0]["symbol"]].step_size > 0


def test_write_enabled_startup_with_invalid_filters_fails_closed_and_clears_cache():
    c, _ = coordinator()
    c.refresh_metadata()
    c.client.settings.demo_trading_enabled = True
    with pytest.raises(DemoFailure, match="write-enabled startup blocked"):
        c.refresh_metadata()
    assert c.rules == {}


def test_corrected_metadata_removes_stale_exclusions():
    c, info = coordinator()
    c.refresh_metadata()
    info["symbols"].pop()
    c.client.settings.demo_trading_enabled = True
    c.refresh_metadata()
    assert not c.excluded_symbols
    assert c.rules
