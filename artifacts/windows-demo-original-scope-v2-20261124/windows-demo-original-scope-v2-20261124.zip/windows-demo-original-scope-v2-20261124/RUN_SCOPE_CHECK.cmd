@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_SCOPE.ps1" -ManifestSHA256 371ed6bfa384039e403f4bfb73456f0c333f58af22d200ef28a92208f467ae53
exit /b %errorlevel%
