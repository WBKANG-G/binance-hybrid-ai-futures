@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0POST_ADOPTION_GATE.ps1" -ManifestSHA256 d8e6be1391ec2e4198822c9354bb41af367c1abecb40c5bb6126efadecd27aea
exit /b %errorlevel%
