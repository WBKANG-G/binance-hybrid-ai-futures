@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0PLAN.ps1" -ManifestSHA256 c769457f65762af6cdbd0b020e7e9df46a3d30302dd041b60981aae70ffb7436
exit /b %errorlevel%
