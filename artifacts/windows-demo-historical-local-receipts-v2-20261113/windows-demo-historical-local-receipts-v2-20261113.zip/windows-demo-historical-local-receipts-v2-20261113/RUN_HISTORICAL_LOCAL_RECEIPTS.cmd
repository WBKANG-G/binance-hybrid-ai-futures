@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0HISTORICAL_LOCAL_RECEIPTS.ps1" -ManifestSHA256 94add4a072d2f06166ef1032f0f790a95c70fcc1dbef3bec83a6ace490b32791
exit /b %errorlevel%
