function Restore-CanonicalMetadataJson([object]$Value,[int]$Depth=0) {
    if ($Depth -gt 16) { throw 'RESTORE_METADATA_DEPTH_INVALID' }
    if ($null -eq $Value) { return 'null' }
    if ($Value -is [string] -or $Value -is [ValueType]) { return (ConvertTo-Json -InputObject $Value -Compress) }
    if ($Value -is [System.Array]) {
        $parts=@()
        foreach ($entry in $Value) { $parts+=,(Restore-CanonicalMetadataJson $entry ($Depth+1)) }
        return ('['+($parts -join ',')+']')
    }
    $parts=@()
    foreach ($property in @($Value.PSObject.Properties | Sort-Object -Property Name)) {
        $key=ConvertTo-Json -InputObject ([string]$property.Name) -Compress
        $parts+=,($key+':'+(Restore-CanonicalMetadataJson $property.Value ($Depth+1)))
    }
    return ('{'+($parts -join ',')+'}')
}
function Resolve-RestoreImageMatch([string]$Reference,[string]$Expected) {
    if ($Reference -cnotmatch '^sha256:[0-9a-f]{64}$' -or $Expected -cnotmatch '^sha256:[0-9a-f]{64}$') { return $false }
    $values=@(Backup-Docker @('image','inspect','--format','{{.Id}}',$Reference) 1)
    return ($values.Count -eq 1 -and $values[0] -ceq $Expected)
}
function Restore-SnapshotComparableJson([object]$Item) {
    # Mount list order is not a Docker identity. Preserve EVERY mount field/value.
    $record=[ordered]@{}
    foreach ($property in $Item.PSObject.Properties) {
        if ($property.Name -ceq 'mounts') { $record[$property.Name]=@($Item.mounts | Sort-Object -Property Destination) }
        else { $record[$property.Name]=$property.Value }
    }
    return (Restore-CanonicalMetadataJson ([pscustomobject]$record))
}
function Assert-RestoreSourceSnapshot([object[]]$Original,[string[]]$Helpers,[bool]$Frozen=$false) {
    if ($Frozen) { throw 'RESTORE_SNAPSHOT_MODE_INVALID' }
    $current=@(Container-Ids)
    $expected=@(@($Original | ForEach-Object {$_.id})+$Helpers | Sort-Object)
    if (($current -join '|') -cne ($expected -join '|')) { $script:RestoreScopeProbe=[pscustomobject]@{step='FRESH_CONTAINER_SET';expected_count=$expected.Count;actual_count=$current.Count}; throw 'COLD_CONTAINER_SET_CHANGED' }
    foreach ($old in $Original) {
        $fresh=Read-Container $old.id
        if ($fresh.running -ne $old.running -or $fresh.restarting -or $fresh.paused -or $fresh.dead) { throw 'COLD_SOURCE_RUNNING_STATE_CHANGED' }
        if ((Restore-SnapshotComparableJson $fresh) -cne (Restore-SnapshotComparableJson $old)) {
            $fields=@()
            foreach ($field in @('id','name','image','labels','mounts','running','restarting','paused','dead','restart','networks')) {
                if ($null -eq $old.PSObject.Properties[$field] -or $null -eq $fresh.PSObject.Properties[$field]) { continue }
                $a=$old.$field; $b=$fresh.$field
                if ($field -ceq 'mounts') { $a=@($a | Sort-Object -Property Destination); $b=@($b | Sort-Object -Property Destination) }
                if ((ConvertTo-Json -InputObject $a -Depth 12 -Compress) -cne (ConvertTo-Json -InputObject $b -Depth 12 -Compress)) { $fields+=,$field }
            }
            $script:RestoreScopeProbe=[pscustomobject]@{step='FRESH_SNAPSHOT_MISMATCH';fields=$fields}
            throw 'COLD_SOURCE_CONFIGURATION_CHANGED'
        }
    }
}
function Restore-MountDiagnosticValues([object[]]$Mounts) {
    # Normalize known metadata values ONLY for diagnosis; no authorization uses this.
    $values=@()
    foreach ($mount in @($Mounts | Sort-Object -Property Destination)) {
        $record=[ordered]@{}
        foreach ($field in @('Type','Source','Destination','RW','Name','Driver','Mode','Propagation')) {
            $record[$field]=$null
            if ($null -ne $mount.PSObject.Properties[$field]) { $record[$field]=$mount.$field }
        }
        $values+=,[pscustomobject]$record
    }
    return (ConvertTo-Json -InputObject $values -Depth 8 -Compress)
}
function Assert-RestoredWorkerReport([object]$restored,[object]$receipt) {
    if ((@($restored.PSObject.Properties.Name | Sort-Object) -join '|') -cne (@(@('status','file_counts','pg_uid','pg_gid','clone_pid_removed','source_changed') | Sort-Object) -join '|') -or $restored.status -cne 'CLONE_BYTES_AND_METADATA_RESTORED' -or $restored.source_changed -isnot [bool] -or $restored.source_changed -or $restored.clone_pid_removed -isnot [bool]) { throw 'RESTORE_WORKER_OUTPUT_INVALID' }
    foreach ($name in @('pg_uid','pg_gid')) { $minimum=0; if ($name -ceq 'pg_uid') { $minimum=1 }; if (($restored.$name -isnot [int] -and $restored.$name -isnot [long]) -or $restored.$name -lt $minimum -or $restored.$name -gt 65535) { throw 'RESTORE_WORKER_OUTPUT_INVALID' } }
    if ($restored.file_counts -isnot [pscustomobject] -or (@($restored.file_counts.PSObject.Properties.Name | Sort-Object) -join '|') -cne 'database|runtime') { throw 'RESTORE_WORKER_OUTPUT_INVALID' }
    foreach ($group in @('database','runtime')) { if (($restored.file_counts.$group -isnot [int] -and $restored.file_counts.$group -isnot [long]) -or $restored.file_counts.$group -lt 1 -or $restored.file_counts.$group -gt 50000 -or $restored.file_counts.$group -ne $receipt.file_counts.$group) { throw 'RESTORE_WORKER_OUTPUT_INVALID' } }
}
# Only freshly created clone IDs may be started or signalled. No source-volume mounts.
function Restore-Hash([string]$Path) { return (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant() }
function Read-RestoreJson([string]$Path,[long]$Maximum=1048576) {
    $file=Get-Item -LiteralPath $Path
    if ($file.Length -lt 2 -or $file.Length -gt $Maximum -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'RESTORE_INPUT_INVALID' }
    return (Get-Content -Raw -LiteralPath $Path | ConvertFrom-Json)
}
function Find-RetainedBackup([object]$Config) {
    $base=Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) 'WBKANG-DEMO-Backups'
    $folders=@(Get-ChildItem -LiteralPath $base -Directory -Filter 'cold-20261114-*')
    if ($folders.Count -gt 32) { throw 'RESTORE_BACKUP_SEARCH_LIMIT' }
    $matches=@()
    foreach ($folder in $folders) {
        if (($folder.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'RESTORE_INPUT_INVALID' }
        $receipt=Join-Path $folder.FullName 'BACKUP_RECEIPT.json'
        if ([IO.File]::Exists($receipt)) {
            Assert-PrivateBackupDirectory $folder.FullName
            Assert-PrivateBackupFiles $folder.FullName
            if ((Restore-Hash $receipt) -ceq $Config.receipt_sha256) { $matches+=,$folder.FullName }
        }
    }
    if ($matches.Count -ne 1) { throw 'RESTORE_RETAINED_RECEIPT_NOT_UNIQUE' }
    return $matches[0]
}
function Assert-InputHashes([string]$Directory,[object]$Config,[object]$Receipt) {
    Assert-PrivateBackupDirectory $Directory; Assert-PrivateBackupFiles $Directory
    if ((Restore-Hash (Join-Path $Directory 'BACKUP_RECEIPT.json')) -cne $Config.receipt_sha256 -or (Restore-Hash (Join-Path $Directory 'manifest.json')) -cne $Config.manifest_sha256 -or $Receipt.manifest_sha256 -cne $Config.manifest_sha256) { throw 'RESTORE_RETAINED_HASH_MISMATCH' }
    if ($Receipt.status -cne 'STOPPED_RAW_COPY_VERIFIED_NOT_RECOVERY_PROOF' -or $Receipt.source_reference -cne $Config.preservation_source_reference) { throw 'RESTORE_RECEIPT_INVALID' }
    foreach ($flag in @('source_containers_started','source_clean_shutdown_verified','account_pause_rechecked','source_data_archive_restore_tested','offline_handoff_performed','automatic_resume','automatic_retry','execution_approved','orders_enabled','live_trading_enabled')) {
        if ($Receipt.$flag -isnot [bool] -or $Receipt.$flag) { throw 'RESTORE_RECEIPT_INVALID' }
    }
    if ($Receipt.source_services_observed_stopped -isnot [bool] -or -not $Receipt.source_services_observed_stopped -or $Receipt.order_writes -ne 0 -or $Receipt.actual_http_attempts -ne 0) { throw 'RESTORE_RECEIPT_INVALID' }
    foreach ($pair in @(@('BACKUP_STATE.json',$Receipt.state_sha256),@('images.tar',$Receipt.image_archive_sha256))) {
        if ($pair[1] -isnot [string] -or $pair[1] -cnotmatch '^[0-9a-f]{64}$' -or (Restore-Hash (Join-Path $Directory $pair[0])) -cne $pair[1]) { throw 'RESTORE_INPUT_HASH_MISMATCH' }
    }
    foreach ($group in @('database','runtime')) {
        $record=$Receipt.archives.$group
        $file=Get-Item -LiteralPath (Join-Path $Directory ($group+'.tar'))
        if ($record.sha256 -cnotmatch '^[0-9a-f]{64}$' -or $file.Length -ne $record.bytes -or (Restore-Hash $file.FullName) -cne $record.sha256) { throw 'RESTORE_INPUT_HASH_MISMATCH' }
    }
}
