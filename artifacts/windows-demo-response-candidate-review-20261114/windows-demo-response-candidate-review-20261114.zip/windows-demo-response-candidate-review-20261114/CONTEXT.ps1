function Digest([string]$Text) {
    $sha=[Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Text)))).Replace('-','').ToLowerInvariant() }
    finally { $sha.Dispose() }
}
function Docker-Lines([string[]]$Arguments,[int]$Maximum=128) {
    $lines=@(& docker @Arguments 2>$null)
    if ($LASTEXITCODE -ne 0 -or $lines.Count -gt $Maximum) { throw 'BACKUP_PLAN_DOCKER_READ_FAILED' }
    foreach ($line in $lines) { if (([string]$line).Length -gt 65536) { throw 'BACKUP_PLAN_DOCKER_READ_FAILED' } }
    return $lines
}
function Set-TopologyProbe([string]$Operation,[string]$Field,[string]$Id='') {
    $reference=$null
    if ($Id -cmatch '^[0-9a-f]{64}$') { $reference=$Id }
    $script:TopologyProbe=[pscustomobject]@{operation=$Operation;field=$Field;container_ref=$reference}
}
function Container-Ids {
    Set-TopologyProbe 'LIST_CONTAINERS' 'IDS'
    $values=@(Docker-Lines @('ps','--all','--quiet','--no-trunc'))
    if ($values.Count -eq 0 -or @($values | Select-Object -Unique).Count -ne $values.Count) { throw 'BACKUP_PLAN_CONTEXT_INVALID' }
    foreach ($id in $values) { if ($id -isnot [string] -or $id -cnotmatch '^[0-9a-f]{64}$') { throw 'BACKUP_PLAN_CONTEXT_INVALID' } }
    return @($values | Sort-Object)
}
function Convert-TopologyJson([string]$Text,[string]$Field,[string]$Id='') {
    Set-TopologyProbe 'PARSE_JSON_FIELD' $Field $Id
    try {
        # Wrap each field so PS5 primitive/array pipeline unrolling cannot alter its type.
        $parsed=ConvertFrom-Json -InputObject ('{"value":'+$Text+'}')
        return ,$parsed
    } catch { throw 'BACKUP_PLAN_TOPOLOGY_JSON_INVALID' }
}
function Assert-TopologyProperties([object]$Value,[string[]]$Fields,[string]$Field,[string]$Id='') {
    Set-TopologyProbe 'VALIDATE_FIELD' $Field $Id
    if ($Value -isnot [pscustomobject]) { throw 'BACKUP_PLAN_TOPOLOGY_FIELD_INVALID' }
    foreach ($name in $Fields) { if ($null -eq $Value.PSObject.Properties[$name]) { throw 'BACKUP_PLAN_TOPOLOGY_FIELD_INVALID' } }
}
function Read-Container([string]$Id) {
    $names=@('id','name','image','labels','mounts','running','restarting','paused','dead','restart','networks')
    $paths=@('.Id','.Name','.Image','.Config.Labels','.Mounts','.State.Running','.State.Restarting','.State.Paused','.State.Dead','.HostConfig.RestartPolicy','.NetworkSettings.Networks')
    # All JSON quoting is produced by Docker, never literal quotes in native argv.
    $format=(@($paths | ForEach-Object {'{{json '+$_+'}}'}) -join '{{println}}')
    Set-TopologyProbe 'INSPECT_CONTAINER' 'RECORD' $Id
    $lines=@(Docker-Lines @('inspect','--format',$format,$Id) 11)
    if ($lines.Count -ne 11 -or ($lines -join '').Length -gt 65536) { throw 'BACKUP_PLAN_TOPOLOGY_FIELD_COUNT' }
    $record=[ordered]@{}
    for ($index=0;$index -lt $names.Count;$index++) {
        $wrapped=Convert-TopologyJson ([string]$lines[$index]) $names[$index] $Id
        $record[$names[$index]]=$wrapped.value
    }
    $value=[pscustomobject]$record
    Set-TopologyProbe 'VALIDATE_FIELD' 'id' $Id
    if ($value.id -isnot [string] -or $value.id -cne $Id) { throw 'BACKUP_PLAN_CONTEXT_INVALID' }
    Set-TopologyProbe 'VALIDATE_FIELD' 'image' $Id
    if ($value.image -isnot [string] -or $value.image -cnotmatch '^sha256:[0-9a-f]{64}$') { throw 'BACKUP_PLAN_CONTEXT_INVALID' }
    Set-TopologyProbe 'VALIDATE_FIELD' 'name' $Id
    if ($value.name -isnot [string]) { throw 'BACKUP_PLAN_CONTEXT_INVALID' }
    foreach ($flag in @('running','restarting','paused','dead')) {
        Set-TopologyProbe 'VALIDATE_FIELD' $flag $Id
        if ($value.$flag -isnot [bool]) { throw 'BACKUP_PLAN_CONTEXT_INVALID' }
    }
    Assert-TopologyProperties $value.restart @('Name','MaximumRetryCount') 'restart' $Id
    if (@('no','always','unless-stopped','on-failure') -cnotcontains $value.restart.Name -or ($value.restart.MaximumRetryCount -isnot [int] -and $value.restart.MaximumRetryCount -isnot [long]) -or $value.restart.MaximumRetryCount -lt 0 -or $value.restart.MaximumRetryCount -gt 100000) { throw 'BACKUP_PLAN_CONTEXT_INVALID' }
    Set-TopologyProbe 'VALIDATE_FIELD' 'labels' $Id
    if ($null -ne $value.labels -and $value.labels -isnot [pscustomobject]) { throw 'BACKUP_PLAN_TOPOLOGY_FIELD_INVALID' }
    Set-TopologyProbe 'VALIDATE_FIELD' 'mounts' $Id
    if ($null -ne $value.mounts -and $value.mounts -isnot [System.Array]) { throw 'BACKUP_PLAN_CONTEXT_INVALID' }
    if (@($value.mounts).Count -gt 32) { throw 'BACKUP_PLAN_CONTEXT_INVALID' }
    foreach ($mount in @($value.mounts)) {
        if ($null -eq $mount) { continue }
        Assert-TopologyProperties $mount @('Type','Source','Destination','RW') 'mounts' $Id
        if ($mount.Type -isnot [string] -or $mount.Source -isnot [string] -or $mount.Destination -isnot [string] -or $mount.RW -isnot [bool] -or $mount.Source.Length -gt 4096 -or $mount.Destination.Length -gt 1024) { throw 'BACKUP_PLAN_CONTEXT_INVALID' }
    }
    Set-TopologyProbe 'VALIDATE_FIELD' 'networks' $Id
    if ($null -ne $value.networks -and $value.networks -isnot [pscustomobject]) { throw 'BACKUP_PLAN_TOPOLOGY_FIELD_INVALID' }
    if ($null -ne $value.networks) {
        foreach ($network in $value.networks.PSObject.Properties) {
            Assert-TopologyProperties $network.Value @('NetworkID') 'networks' $Id
            if ($network.Value.NetworkID -isnot [string]) { throw 'BACKUP_PLAN_TOPOLOGY_FIELD_INVALID' }
        }
    }
    Set-TopologyProbe 'CONTAINER_VALIDATED' 'NONE' $Id
    return $value
}
function Project([object]$Item) {
    if ($null -eq $Item.labels -or $Item.labels -isnot [pscustomobject]) { return '' }
    $prop=$Item.labels.PSObject.Properties['com.docker.compose.project']
    if ($null -eq $prop -or $prop.Value -isnot [string]) { return '' }
    return $prop.Value
}
function Service([object]$Item) {
    if ($null -eq $Item.labels -or $Item.labels -isnot [pscustomobject]) { return '' }
    $prop=$Item.labels.PSObject.Properties['com.docker.compose.service']
    if ($null -eq $prop -or $prop.Value -isnot [string]) { return '' }
    return $prop.Value
}
function Volume-Mount([object]$Item,[string]$Destination) {
    $selected=@($Item.mounts | Where-Object { $_.Destination -ceq $Destination })
    if ($selected.Count -ne 1) { throw 'BACKUP_PLAN_VOLUME_LAYOUT_UNSUPPORTED' }
    $mount=$selected[0]
    if ($mount.Type -cne 'volume' -or $mount.RW -ne $true -or $mount.Name -isnot [string] -or $mount.Name -cnotmatch '^[A-Za-z0-9][A-Za-z0-9_.-]{0,254}$' -or -not $mount.Source.StartsWith('/') -or $mount.Source -ceq '/') { throw 'BACKUP_PLAN_VOLUME_LAYOUT_UNSUPPORTED' }
    Set-TopologyProbe 'INSPECT_VOLUME' 'VOLUME_RECORD' $Item.id
    $format='{{json .Driver}}{{println}}{{json .Scope}}{{println}}{{json .Options}}'
    $lines=@(Docker-Lines @('volume','inspect','--format',$format,$mount.Name) 3)
    if ($lines.Count -ne 3) { throw 'BACKUP_PLAN_TOPOLOGY_FIELD_COUNT' }
    $volume=[pscustomobject]@{driver=(Convert-TopologyJson $lines[0] 'driver' $Item.id).value;scope=(Convert-TopologyJson $lines[1] 'scope' $Item.id).value;options=(Convert-TopologyJson $lines[2] 'options' $Item.id).value}
    if ($volume.driver -cne 'local' -or $volume.scope -cne 'local') { throw 'BACKUP_PLAN_VOLUME_LAYOUT_UNSUPPORTED' }
    if ($null -ne $volume.options -and @($volume.options.PSObject.Properties).Count -ne 0) { throw 'BACKUP_PLAN_VOLUME_OPTIONS_REQUIRE_REVIEW' }
    return $mount
}
function Uses-Source([object]$Item,[object]$Mount) {
    foreach ($other in @($Item.mounts)) {
        if ($null -eq $other) { continue }
        $a=$other.Source.TrimEnd('/')
        $b=$Mount.Source.TrimEnd('/')
        if ($a -ceq $b -or $a.StartsWith(($b+'/'),[StringComparison]::Ordinal) -or ($a -ne '' -and $b.StartsWith(($a+'/'),[StringComparison]::Ordinal))) { return $true }
    }
    return $false
}