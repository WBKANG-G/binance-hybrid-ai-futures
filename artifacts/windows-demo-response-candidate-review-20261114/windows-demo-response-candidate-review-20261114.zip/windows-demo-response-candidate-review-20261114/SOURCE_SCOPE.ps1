# Only file reads, new destination files, and local Docker metadata queries.
function Find-RestoreEvidence([object]$Config) {
    $base=Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) 'WBKANG-DEMO-Backups'
    $found=@(); $folders=@(Get-ChildItem -LiteralPath $base -Directory -Filter 'cold-20261114-*')
    if ($folders.Count -gt 32) { throw 'HANDOFF_SEARCH_LIMIT' }
    foreach ($folder in $folders) {
        if (($folder.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'HANDOFF_REPARSE_POINT' }
        $path=Join-Path $folder.FullName 'ISOLATED_RESTORE_RECEIPT.json'
        if ([IO.File]::Exists($path)) {
            Assert-PrivateBackupDirectory $folder.FullName; Assert-PrivateBackupFiles $folder.FullName
            if ((Restore-Hash $path) -ceq $Config.restore_receipt_sha256) { $found+=,$path }
        }
    }
    if ($found.Count -ne 1) { throw 'HANDOFF_RESTORE_RECEIPT_NOT_UNIQUE' }
    return $found[0]
}
function Assert-RestoreEvidence([object]$Value,[object]$Config) {
    if ($Value.isolated_restore -cne 'COPY_RECOVERED_AND_ACCOUNT_READS_VERIFIED' -or $Value.source_reference -cne $Config.restore_source_reference -or $Value.backup_manifest_sha256 -cne $Config.manifest_sha256 -or $Value.backup_receipt_sha256 -cne $Config.receipt_sha256 -or $Value.clone_network -cne 'none') { throw 'HANDOFF_RESTORE_RECEIPT_INVALID' }
    foreach ($flag in @('input_hashes_reverified','archive_bytes_and_metadata_verified_before_clone_recovery','clone_stopped','clone_clean_exit_verified')) { if ($Value.$flag -isnot [bool] -or -not $Value.$flag) { throw 'HANDOFF_RESTORE_RECEIPT_INVALID' } }
    foreach ($flag in @('original_services_started','original_volume_mounted_in_restore_helpers','financial_write_attempted','full_financial_proof_verified','offline_handoff_performed','installation_ready','automatic_retry','execution_approved','orders_enabled','live_trading_enabled')) { if ($Value.$flag -isnot [bool] -or $Value.$flag) { throw 'HANDOFF_RESTORE_RECEIPT_INVALID' } }
    if ($Value.order_writes -ne 0 -or $Value.actual_http_attempts -ne 0 -or $Value.account.paused -isnot [bool] -or -not $Value.account.paused -or $Value.account.orders -ne 34 -or $Value.account.unresolved_requests -ne 4 -or $Value.account.daily_key -cne '2026-11-13' -or $Value.account.weekly_key -cne '2026-11-09' -or $Value.account.transaction_read_only -cne 'on' -or $Value.account.account_state_sha256 -cnotmatch '^[0-9a-f]{64}$') { throw 'HANDOFF_RESTORE_RECEIPT_INVALID' }
    if (@($Value.retained_helper_ids).Count -ne 2 -or @($Value.retained_clone_volumes).Count -ne 2 -or $Value.clone_container_id -cne $Value.retained_helper_ids[1]) { throw 'HANDOFF_RESTORE_RECEIPT_INVALID' }
    foreach ($id in $Value.retained_helper_ids) { if ($id -cnotmatch '^[0-9a-f]{64}$') { throw 'HANDOFF_RESTORE_RECEIPT_INVALID' } }
    foreach ($name in $Value.retained_clone_volumes) { if ($name -cnotmatch '^demo-restore-(database|runtime)-[0-9a-f]{32}$') { throw 'HANDOFF_RESTORE_RECEIPT_INVALID' } }
}
function Assert-HandoffStoppedScope([object]$Config,[object]$Backup,[object]$State,[object]$Recovery) {
    if ($State.protocol -cne 'STOPPED_UNCLEAN_PRESERVATION_V1' -or $State.source_reference -cne $Config.preservation_source_reference -or @($State.canonical_images).Count -ne 2 -or @(@($State.database_volume,$State.runtime_volume,$Backup.output_volume)+@($Recovery.retained_clone_volumes) | Select-Object -Unique).Count -ne 5) { throw 'HANDOFF_SCOPE_INVALID' }
    $items=@(@(Container-Ids) | ForEach-Object {Read-Container $_})
    $sourceIds=@($State.source_snapshots | ForEach-Object {$_.id})
    $helperIds=@($Backup.helper_container_ids)+@($Recovery.retained_helper_ids)
    if ($sourceIds.Count -ne 6 -or $helperIds.Count -ne 3 -or @(@($sourceIds+$helperIds) | Select-Object -Unique).Count -ne 9) { throw 'HANDOFF_SCOPE_INVALID' }
    $keys=@($items | Where-Object {(Project $_) -ceq 'hybrid-windows' -and (Service $_) -ceq 'key-session' -and $helperIds -cnotcontains $_.id})
    if ($keys.Count -ne 1) { throw 'HANDOFF_SCOPE_INVALID' }
    $expected=@($sourceIds+$helperIds+@($keys[0].id))
    foreach ($item in $items) {
        if ((Project $item) -ceq 'hybrid-windows' -and $expected -cnotcontains $item.id) { throw 'HANDOFF_UNREVIEWED_PROJECT_CONTAINER' }
    }
    foreach ($id in $expected) {
        $selected=@($items | Where-Object {$_.id -ceq $id})
        if ($selected.Count -ne 1 -or $selected[0].running -or $selected[0].paused -or $selected[0].dead -or $selected[0].restarting -or $selected[0].restart.Name -cne 'no' -or $selected[0].restart.MaximumRetryCount -ne 0) { throw 'HANDOFF_CONTAINER_NOT_STOPPED' }
    }
    foreach ($saved in $State.source_snapshots) {
        $now=@($items | Where-Object {$_.id -ceq $saved.id})[0]
        if ((Project $now) -cne 'hybrid-windows' -or (Service $now) -cne $saved.service -or $now.image -cne $saved.image -or (Restore-CanonicalMetadataJson $now.restart) -cne (Restore-CanonicalMetadataJson $saved.restart) -or (Restore-CanonicalMetadataJson @($now.mounts | Where-Object {$_.Destination -cne '/run/demo-keys'} | Sort-Object Destination)) -cne (Restore-CanonicalMetadataJson @($saved.mounts | Sort-Object Destination))) { throw 'HANDOFF_ORIGINAL_CONFIGURATION_CHANGED' }
    }
    $api=@($items | Where-Object {$_.id -ceq $Config.api_container_id})[0]; $db=@($items | Where-Object {$_.id -ceq $Config.database_container_id})[0]
    $runtime=Volume-Mount $api '/app/demo-export-state'; $database=Volume-Mount $db '/var/lib/postgresql'
    if ($runtime.Name -cne $State.runtime_volume -or $database.Name -cne $State.database_volume) { throw 'HANDOFF_SCOPE_INVALID' }
    foreach ($item in $items) {
        if ($expected -cnotcontains $item.id -and ((Uses-Source $item $runtime) -or (Uses-Source $item $database))) { throw 'HANDOFF_EXTERNAL_SOURCE_CONSUMER' }
    }
    for ($i=0;$i -lt 3;$i++) {
        $helper=@($items | Where-Object {$_.id -ceq $helperIds[$i]})[0]
        $image=$State.canonical_images[0]; if ($i -eq 2) { $image=$State.canonical_images[1] }
        if (-not (Resolve-RestoreImageMatch $helper.image $image)) { throw 'HANDOFF_HELPER_CONFIGURATION_CHANGED' }
        if ($i -eq 0) { $specs=@(@('/source/database','volume',$State.database_volume,$false),@('/source/runtime','volume',$State.runtime_volume,$false),@('/output','volume',$Backup.output_volume,$true)) }
        elseif ($i -eq 1) { $specs=@(@('/bundle','bind','',$false),@('/clone/database','volume',$Recovery.retained_clone_volumes[0],$true),@('/clone/runtime','volume',$Recovery.retained_clone_volumes[1],$true)) }
        else { $specs=,@('/var/lib/postgresql','volume',$Recovery.retained_clone_volumes[0],$true) }
        if (@($helper.mounts).Count -ne $specs.Count) { throw 'HANDOFF_HELPER_CONFIGURATION_CHANGED' }
        foreach ($spec in $specs) {
            $mount=@($helper.mounts | Where-Object {$_.Destination -ceq $spec[0]})
            if ($mount.Count -ne 1 -or $mount[0].Type -cne $spec[1] -or $mount[0].RW -ne $spec[3] -or ($spec[1] -ceq 'volume' -and $mount[0].Name -cne $spec[2])) { throw 'HANDOFF_HELPER_CONFIGURATION_CHANGED' }
        }
        $network=@(Backup-Docker @('inspect','--format','{{.HostConfig.NetworkMode}}',$helper.id) 1)
        if ($network.Count -ne 1 -or $network[0] -cne 'none') { throw 'HANDOFF_HELPER_CONFIGURATION_CHANGED' }
    }
    $exit=@(Backup-Docker @('inspect','--format','{{.State.ExitCode}} {{.State.OOMKilled}}',$Recovery.clone_container_id) 1)
    if ($exit.Count -ne 1 -or $exit[0] -cne '0 false') { throw 'HANDOFF_CLONE_EXIT_CHANGED' }
    Assert-RestoreSourceSnapshot $items @() $false
    return ,$items
}
