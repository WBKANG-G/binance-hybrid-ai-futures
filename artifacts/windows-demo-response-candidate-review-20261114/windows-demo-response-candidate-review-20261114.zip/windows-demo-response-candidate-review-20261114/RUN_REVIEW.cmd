@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0REVIEW.ps1" -ManifestSHA256 851cf71ee51365cf54168330a21d607f4f13f6ccd4da811c3b02836b39a5a0e1
exit /b %errorlevel%
