@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_FINANCIAL.ps1" -ManifestSHA256 54e5ae4a49da6ab1e4f2b9106d84bef40e56bbdddd9ed728ad9d3df2f41f39c4 -CheckOnly
exit /b %errorlevel%
