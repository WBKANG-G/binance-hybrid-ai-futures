@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_COMPARE.ps1" -ManifestSHA256 74283bab56a2d5f1da42699cf75a8f878bbcb37e8110217486662fa958b29444 -CheckOnly
exit /b %errorlevel%
