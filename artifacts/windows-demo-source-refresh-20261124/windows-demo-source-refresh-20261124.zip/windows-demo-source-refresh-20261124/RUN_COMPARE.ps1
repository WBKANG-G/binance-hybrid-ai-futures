[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$ManifestSHA256,[switch]$CheckOnly,[switch]$CompareOnce)
$ErrorActionPreference='Stop';Set-StrictMode -Version Latest
$handles=@();$helper=$null;$helperStopped=$false;$directory=$null;$mutex=$null;$locked=$false;$stage='TRANSFER';$loadedModule='NONE';$required=@();$script:ScopeDockerDiagnostic=$null
try {
 $path=Join-Path $PSScriptRoot 'TRANSFER_MANIFEST.json'
 if($ManifestSHA256 -cnotmatch '^[0-9a-f]{64}$' -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() -cne $ManifestSHA256){throw 'SCOPE_TRANSFER_INVALID'}
 $manifest=Get-Content -Raw -LiteralPath $path|ConvertFrom-Json
 $required=@('CONTEXT.ps1','COMMON.ps1','SUPPORT.ps1','SOURCE_SCOPE.ps1','COPY_CORE.ps1','COPY_EXT.ps1','COMPARE_ADMISSION.ps1','FINANCIAL_EXT.ps1','READ_CORE.ps1','BASELINE_CORE.ps1','PLAN_CORE.ps1','CONFIG.json','DOCKER_READ.ps1','README_KO.md','SOURCE_ACCEPTANCE.json','SOURCE_PROPOSAL.json','worker.py','READ_LIBRARY.py','REFRESH_CORE.ps1','RUN_COMPARE.ps1')
 if((@($manifest.files.PSObject.Properties.Name|Sort-Object)-join '|') -cne (@($required|Sort-Object)-join '|')){throw 'SCOPE_TRANSFER_INVALID'}
 foreach($p in $manifest.files.PSObject.Properties){if($p.Value -cnotmatch '^[0-9a-f]{64}$' -or (Get-FileHash -LiteralPath (Join-Path $PSScriptRoot $p.Name) -Algorithm SHA256).Hash.ToLowerInvariant() -cne $p.Value){throw 'SCOPE_TRANSFER_INVALID'}}
 Write-Output 'TRANSFER_FILES_VERIFIED'
 $stage='LOAD_MODULES'
 foreach($name in @('DOCKER_READ.ps1','CONTEXT.ps1','COMMON.ps1','SUPPORT.ps1','SOURCE_SCOPE.ps1','COPY_CORE.ps1','COPY_EXT.ps1','COMPARE_ADMISSION.ps1','READ_CORE.ps1','BASELINE_CORE.ps1','PLAN_CORE.ps1','FINANCIAL_EXT.ps1')){$loadedModule=$name;. (Join-Path $PSScriptRoot $name)}
 if(([int][bool]$CheckOnly+[int][bool]$CompareOnce) -ne 1){throw 'COMPARE_EXPLICIT_MODE_REQUIRED'}
 . (Join-Path $PSScriptRoot 'REFRESH_CORE.ps1')
 $stage='READ_CONFIG'
 $config=Read-RestoreJson (Join-Path $PSScriptRoot 'CONFIG.json')
 $stage='CHECK_ACCEPTANCE'
 $receiptPath=Join-Path $PSScriptRoot 'SOURCE_ACCEPTANCE.json'
 if((Get-FileHash -LiteralPath $receiptPath -Algorithm SHA256).Hash.ToLowerInvariant() -cne $config.source_acceptance_file_sha256){throw 'SCOPE_ACCEPTANCE_MISMATCH'}
 $accepted=ConvertFrom-Json -InputObject ([IO.File]::ReadAllText($receiptPath,[Text.Encoding]::UTF8))
 if($accepted.review_id -cne $config.accepted_review_id -or $accepted.proposal_sha256 -cne $config.accepted_proposal_sha256 -or $accepted.source_accepted -isnot [bool] -or -not $accepted.source_accepted -or $accepted.conditional_reuse_approved -isnot [bool] -or -not $accepted.conditional_reuse_approved){throw 'SCOPE_ACCEPTANCE_MISMATCH'}
 foreach($flag in @('original_database_write_authorized','original_database_start_authorized','original_owner_lease_takeover_authorized','existing_guard_bypass_authorized','request_resolution_authorized','resend_authorized','execution_approved','orders_enabled','live_trading_enabled')){if($accepted.$flag -isnot [bool] -or $accepted.$flag){throw 'SCOPE_ACCEPTANCE_AUTHORITY_INVALID'}}
 $stage='FIND_BACKUP'
 $backup=Find-RetainedBackup $config
 $stage='READ_BACKUP_RECEIPT'
 $receipt=Read-RestoreJson (Join-Path $backup 'BACKUP_RECEIPT.json')
 $stage='VERIFY_BACKUP_INITIAL'
 Assert-InputHashes $backup $config $receipt
 $stage='LOCK_INPUT_STREAMS'
 foreach($name in @('BACKUP_RECEIPT.json','BACKUP_STATE.json','manifest.json','database.tar','runtime.tar','images.tar')){$handles+=,(New-Object IO.FileStream((Join-Path $backup $name),[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read))}
 $stage='VERIFY_BACKUP_LOCKED'
 Assert-InputHashes $backup $config $receipt
 $stage='READ_BACKUP_STATE'
 $state=Read-RestoreJson (Join-Path $backup 'BACKUP_STATE.json')
 $stage='CHECK_ORIGINAL_SCOPE'
 $original=Read-CopySources $config $receipt $state
 # Source admission still filters exactly the re-admitted stopped reader here.
 Assert-RestoreSourceSnapshot $original @() $false
 Assert-InputHashes $backup $config $receipt
 if($CheckOnly){Write-Output 'SOURCE_REFRESH_CHECK_PASSED_NO_HELPER_START';exit 0}
 $stage='ACQUIRE_EXCLUSIVE_COMPARE'
 $mutex=New-Object Threading.Mutex($false,'Global\WBKANG_DEMO_COLD_BACKUP')
 $locked=$mutex.WaitOne(0);if(-not $locked){throw 'COLD_ANOTHER_BACKUP_ACTIVE'}
 Assert-RestoreSourceSnapshot $original @() $false
 $stage='ADMIT_EXISTING_READ_ONLY_HELPER'
 Assert-RefreshReader $config $state $original
 $helper=$config.comparison_helper_id
 $directory=New-PrivateBackupDirectory ([Guid]::NewGuid().ToString('N'))
 Write-BackupJson (Join-Path $directory 'INTENT.json') @{source_reference=$config.source_reference;helper_id=$helper;helper_reused=$true;original_services_started=$false;automatic_retry=$false}
 # From this point the one owned reader is visible in container-set snapshots.
 $script:RefreshHelperVisible=$true
 Assert-RestoreSourceSnapshot $original @($helper) $false
 $stage='READ_ONLY_TWO_PASS_COMPARISON'
 Write-Output 'SOURCE_REFRESH_STAGE=READ_ONLY_TWO_PASS_COMPARISON'
 $worker=[Convert]::ToBase64String([IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'worker.py')))
 $library=[Convert]::ToBase64String([IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'READ_LIBRARY.py')))
 $manifest=[Convert]::ToBase64String([IO.File]::ReadAllBytes((Join-Path $backup 'manifest.json')))
 $payload="import base64,json`nREAD_LIBRARY=base64.b64decode('$library')`nMANIFEST=json.loads(base64.b64decode('$manifest'))`nexec(compile(base64.b64decode('$worker'),'<source-refresh>','exec'))"
 $value=Invoke-RefreshPayload $config $state $original $payload
 $stage='REVERIFY_STOPPED_READER_AND_SOURCES'
 Assert-RefreshReader $config $state $original
 $helperStopped=$true
 Assert-RestoreSourceSnapshot $original @($helper) $false
 Assert-InputHashes $backup $config $receipt
 $m=Read-RestoreJson (Join-Path $backup 'manifest.json') 16777216
 Assert-RefreshResult $value $m
 $result=[ordered]@{source_refresh='STOPPED_ORIGINAL_BYTES_AND_METADATA_MATCH_PINNED_BACKUP';source_reference=$config.source_reference;manifest_sha256=$config.manifest_sha256;backup_receipt_sha256=$config.receipt_sha256;passes=2;file_counts=$value.file_counts;logical_bytes=$value.logical_bytes;source_bytes_compared=$true;source_data_written=$false;comparison_helper_reused=$true;comparison_helper_id=$helper;helper_stopped_verified=$true;source_container_snapshots_rechecked=$true;source_acceptance_recorded=$true;conditional_reuse_approved=$true;restored_sql_reference_sha256=$script:FinancialPrior.account_state_sha256;current_original_sql_queried=$false;current_original_fence_verified=$false;original_services_started_by_tool=$false;original_database_write_authorized=$false;original_apply_ready=$false;containers_created=0;volumes_created=0;fresh_account_evidence_checked=$false;baseline_adopted=$false;request_states_changed=$false;execution_approved=$false;automatic_retry=$false;actual_http_attempts=0;order_writes=0;orders_enabled=$false;live_trading_enabled=$false}
 Write-BackupJson (Join-Path $directory 'SOURCE_REFRESH_RECEIPT.json') $result
 $result['private_report_directory']=$directory
 $result['receipt_file_sha256']=Restore-Hash (Join-Path $directory 'SOURCE_REFRESH_RECEIPT.json')
 $result|ConvertTo-Json -Depth 6 -Compress|Write-Output
 Write-Output 'SOURCE_REFRESH_MATCHED_HELPER_STOPPED_NO_ORIGINAL_START_NO_ORDERS'
 exit 0
} catch {
 $reason='SCOPE_CHECK_BLOCKED';if($_.Exception.Message -cmatch '^(SCOPE|RESTORE|COLD|HANDOFF|FINANCIAL|COMPARE|BACKUP_PLAN|BASELINE|INSPECT|READ|REFERENCE|INCOME)_[A-Z0-9_]{1,100}$'){$reason=$_.Exception.Message}
 $file='UNKNOWN';$line=0;$type='UNKNOWN'
 if($null -ne $_.InvocationInfo){
  $baseName=[IO.Path]::GetFileName($_.InvocationInfo.ScriptName)
  if(@($required) -ccontains $baseName){$file=$baseName;$line=[int]$_.InvocationInfo.ScriptLineNumber}
 }
 if($null -ne $_.Exception){$typeName=$_.Exception.GetType().Name;if(@('RuntimeException','RemoteException','PropertyNotFoundException','CommandNotFoundException','MethodException','MethodInvocationException','PSArgumentException','ParameterBindingException','ItemNotFoundException','UnauthorizedAccessException','IOException','InvalidOperationException') -ccontains $typeName){$type=$typeName}}
 if($null -ne $helper -and -not $helperStopped){try{Assert-RefreshReader $config $state $original;$helperStopped=$true}catch{}}
 if($null -ne $directory){try{Write-BackupJson (Join-Path $directory 'FAILURE.json') @{failure_stage=$stage;failure_category=$reason;helper_id=$helper;helper_stopped_verified=$helperStopped;start_attempted=$script:RefreshStartAttempted;automatic_retry=$false}}catch{}}
 [pscustomobject]@{helper_stopped_verified=$helperStopped;retained_helper_id=$helper;private_report_directory=$directory;scope_check='BLOCKED_KEEP_STOPPED_NO_RETRY';failure_category=$reason;docker_read_diagnostic=$script:ScopeDockerDiagnostic;failure_stage=$stage;loading_module=$(if($stage -ceq 'LOAD_MODULES' -and @($required) -ccontains $loadedModule){$loadedModule}else{$null});failure_script=$file;failure_line=$line;exception_type=$type;original_database_started=$false;original_database_changed=$false;original_apply_ready=$false;order_writes=0;orders_enabled=$false;live_trading_enabled=$false}|ConvertTo-Json -Depth 5 -Compress|Write-Output
 exit 2
} finally {
 if($locked){$mutex.ReleaseMutex()};if($null -ne $mutex){$mutex.Dispose()}
 foreach($handle in $handles){$handle.Dispose()}
 if($null -ne (Get-Variable -Name CopyRestoreHandle -Scope Script -ErrorAction SilentlyContinue) -and $null -ne $script:CopyRestoreHandle){$script:CopyRestoreHandle.Dispose()}
}
