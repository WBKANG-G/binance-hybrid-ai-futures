@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN_EXPORT.ps1" -ManifestSHA256 26671c2a3f52fba86c68f1e879e441dd6ce62a7e932f0e97b8481db71c00dfe4 -StatusOnce
exit /b %errorlevel%
