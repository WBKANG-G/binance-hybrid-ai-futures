@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0HISTORICAL_LOCAL_RECEIPTS.ps1" -ManifestSHA256 6a644475fb445d2eeaded16b5b439c19e0aefc28cb2904ec79ce14f6a638eb8e
exit /b %errorlevel%
