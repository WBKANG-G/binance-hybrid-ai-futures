@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_SCOPE.ps1" -ManifestSHA256 e4d4cacf2759a837f326c0b5b6a496ec1598391721b7135de46daaeed59b7784
exit /b %errorlevel%
