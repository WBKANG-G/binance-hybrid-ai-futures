function Digest([string]$Text) {
    $sha=[Security.Cryptography.SHA256]::Create()
    try { return ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($Text)))).Replace('-','').ToLowerInvariant() }
    finally { $sha.Dispose() }
}
function Docker-Lines([string[]]$Arguments,[int]$Maximum=128) {
    $lines=@(& docker @Arguments 2>$null)
    if ($LASTEXITCODE -ne 0 -or $lines.Count -gt $Maximum) { throw 'BACKUP_PLAN_DOCKER_READ_FAILED' }
    foreach ($line in $lines) { if (([string]$line).Length -gt 65536) { throw 'BACKUP_PLAN_DOCKER_READ_FAILED' } }
    return $lines
}
function Container-Ids {
    $values=@(Docker-Lines @('ps','--all','--quiet','--no-trunc'))
    if ($values.Count -eq 0 -or @($values | Select-Object -Unique).Count -ne $values.Count) { throw 'BACKUP_PLAN_CONTEXT_INVALID' }
    foreach ($id in $values) { if ($id -isnot [string] -or $id -cnotmatch '^[0-9a-f]{64}$') { throw 'BACKUP_PLAN_CONTEXT_INVALID' } }
    return @($values | Sort-Object)
}
function Read-Container([string]$Id) {
    $format='{"id":{{json .Id}},"name":{{json .Name}},"image":{{json .Image}},"labels":{{json .Config.Labels}},"mounts":{{json .Mounts}},"running":{{json .State.Running}},"restarting":{{json .State.Restarting}},"paused":{{json .State.Paused}},"dead":{{json .State.Dead}},"restart":{{json .HostConfig.RestartPolicy}},"networks":{{json .NetworkSettings.Networks}}}'
    $lines=@(Docker-Lines @('inspect','--format',$format,$Id) 1)
    if ($lines.Count -ne 1) { throw 'BACKUP_PLAN_CONTEXT_INVALID' }
    $value=$lines[0] | ConvertFrom-Json
    if ($value -isnot [pscustomobject] -or $value.id -cne $Id -or $value.image -cnotmatch '^sha256:[0-9a-f]{64}$' -or $value.name -isnot [string]) { throw 'BACKUP_PLAN_CONTEXT_INVALID' }
    foreach ($flag in @('running','restarting','paused','dead')) { if ($value.$flag -isnot [bool]) { throw 'BACKUP_PLAN_CONTEXT_INVALID' } }
    if (@('no','always','unless-stopped','on-failure') -cnotcontains $value.restart.Name -or ($value.restart.MaximumRetryCount -isnot [int] -and $value.restart.MaximumRetryCount -isnot [long]) -or $value.restart.MaximumRetryCount -lt 0 -or $value.restart.MaximumRetryCount -gt 100000) { throw 'BACKUP_PLAN_CONTEXT_INVALID' }
    if ($null -ne $value.mounts -and $value.mounts -isnot [System.Array]) { throw 'BACKUP_PLAN_CONTEXT_INVALID' }
    if (@($value.mounts).Count -gt 32) { throw 'BACKUP_PLAN_CONTEXT_INVALID' }
    foreach ($mount in @($value.mounts)) {
        if ($null -eq $mount) { continue }
        if ($mount.Type -isnot [string] -or $mount.Source -isnot [string] -or $mount.Destination -isnot [string] -or $mount.RW -isnot [bool] -or $mount.Source.Length -gt 4096 -or $mount.Destination.Length -gt 1024) { throw 'BACKUP_PLAN_CONTEXT_INVALID' }
    }
    return $value
}
function Project([object]$Item) {
    if ($null -eq $Item.labels -or $Item.labels -isnot [pscustomobject]) { return '' }
    $prop=$Item.labels.PSObject.Properties['com.docker.compose.project']
    if ($null -eq $prop -or $prop.Value -isnot [string]) { return '' }
    return $prop.Value
}
function Service([object]$Item) {
    if ($null -eq $Item.labels -or $Item.labels -isnot [pscustomobject]) { return '' }
    $prop=$Item.labels.PSObject.Properties['com.docker.compose.service']
    if ($null -eq $prop -or $prop.Value -isnot [string]) { return '' }
    return $prop.Value
}
function Volume-Mount([object]$Item,[string]$Destination) {
    $selected=@($Item.mounts | Where-Object { $_.Destination -ceq $Destination })
    if ($selected.Count -ne 1) { throw 'BACKUP_PLAN_VOLUME_LAYOUT_UNSUPPORTED' }
    $mount=$selected[0]
    if ($mount.Type -cne 'volume' -or $mount.RW -ne $true -or $mount.Name -isnot [string] -or $mount.Name -cnotmatch '^[A-Za-z0-9][A-Za-z0-9_.-]{0,254}$' -or -not $mount.Source.StartsWith('/') -or $mount.Source -ceq '/') { throw 'BACKUP_PLAN_VOLUME_LAYOUT_UNSUPPORTED' }
    $format='{"driver":{{json .Driver}},"scope":{{json .Scope}},"options":{{json .Options}}}'
    $lines=@(Docker-Lines @('volume','inspect','--format',$format,$mount.Name) 1)
    if ($lines.Count -ne 1) { throw 'BACKUP_PLAN_VOLUME_LAYOUT_UNSUPPORTED' }
    $volume=$lines[0] | ConvertFrom-Json
    if ($volume.driver -cne 'local' -or $volume.scope -cne 'local') { throw 'BACKUP_PLAN_VOLUME_LAYOUT_UNSUPPORTED' }
    if ($null -ne $volume.options -and @($volume.options.PSObject.Properties).Count -ne 0) { throw 'BACKUP_PLAN_VOLUME_OPTIONS_REQUIRE_REVIEW' }
    return $mount
}
function Uses-Source([object]$Item,[object]$Mount) {
    foreach ($other in @($Item.mounts)) {
        if ($null -eq $other) { continue }
        $a=$other.Source.TrimEnd('/')
        $b=$Mount.Source.TrimEnd('/')
        if ($a -ceq $b -or $a.StartsWith(($b+'/'),[StringComparison]::Ordinal) -or ($a -ne '' -and $b.StartsWith(($a+'/'),[StringComparison]::Ordinal))) { return $true }
    }
    return $false
}