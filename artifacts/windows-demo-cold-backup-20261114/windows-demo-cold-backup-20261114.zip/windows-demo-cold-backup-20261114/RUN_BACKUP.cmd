@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_BACKUP.ps1" -ManifestSHA256 526301b20fcc2db68d48cd2c84238de63495053f8f122b8d64167077c6a007cd -ExecuteColdBackup
exit /b %errorlevel%
