@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0PLAN.ps1" -ManifestSHA256 fb3417b3d03b0984730dfa53190850b3b51268bbe83c46423ea4c81e9eb66e96
exit /b %errorlevel%
