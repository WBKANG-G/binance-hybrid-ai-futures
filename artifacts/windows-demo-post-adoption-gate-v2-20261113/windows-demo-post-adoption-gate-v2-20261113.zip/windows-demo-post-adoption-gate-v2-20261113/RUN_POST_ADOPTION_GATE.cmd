@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0POST_ADOPTION_GATE.ps1" -ManifestSHA256 0fd25f4990c67ba312c6e3fcff8d1d4572878ac5bde6d591889d91581a03c22d
exit /b %errorlevel%
