@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_CURRENT.ps1" -ManifestSHA256 f36597fa985a7faa52de8769c63fe3c878f8c9a7b9db87a408d52725d35ba410 -CheckOnly
exit /b %errorlevel%
