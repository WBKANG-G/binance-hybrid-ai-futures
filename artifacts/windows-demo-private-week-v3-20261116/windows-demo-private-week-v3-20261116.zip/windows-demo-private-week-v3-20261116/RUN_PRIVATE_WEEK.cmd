@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_COPY.ps1" -ManifestSHA256 f6abfc541eab83717cddac7b02bcc93ac71f3117c40ea1c5b32af6f9f375dc27 -ExecuteReview
exit /b %errorlevel%
