@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_PRESERVE.ps1" -ManifestSHA256 3b6f3bd0a034870e8c1ba2043ccdb30029b134054202c462b1d880032a53a908 -CheckOnly
exit /b %errorlevel%
