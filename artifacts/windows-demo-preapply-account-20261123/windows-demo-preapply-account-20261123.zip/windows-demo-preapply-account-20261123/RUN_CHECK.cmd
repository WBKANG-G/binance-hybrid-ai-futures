@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_CURRENT.ps1" -ManifestSHA256 907a0f97f2cfe421493bd04969ae1d86da120b160308ab69432e5090fa38c7ba -CheckOnly
exit /b %errorlevel%
