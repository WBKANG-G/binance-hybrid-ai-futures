@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0REVIEW.ps1" -ManifestSHA256 69da9d75964fe1de4bd7a25ecdb0ec468fdef8511b1be8c094f3be0b271e926a
exit /b %errorlevel%
