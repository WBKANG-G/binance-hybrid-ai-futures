@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0PREFLIGHT.ps1" -ManifestSHA256 2f3c15ffc41678e3d0c23ed893e6906bd8f80ed8aace7096ee977749cdec3af2
exit /b %errorlevel%
