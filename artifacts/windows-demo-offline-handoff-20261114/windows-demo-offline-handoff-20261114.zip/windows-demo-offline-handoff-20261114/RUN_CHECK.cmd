@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_HANDOFF.ps1" -ManifestSHA256 6c03e6eab318da253c2d8aa49206398bba1248433f79acdb6fa165871e458e2d -CheckOnly
exit /b %errorlevel%
