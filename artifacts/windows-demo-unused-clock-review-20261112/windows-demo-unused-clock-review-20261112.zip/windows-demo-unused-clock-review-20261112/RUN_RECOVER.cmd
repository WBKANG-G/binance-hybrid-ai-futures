@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0REVIEW.ps1" -ManifestSHA256 8ebb5354641c3b37938d7e099e4e21630e961d205de151b2f5cd1a97aa8dfd1c -WaitStartupHold
exit /b %errorlevel%
