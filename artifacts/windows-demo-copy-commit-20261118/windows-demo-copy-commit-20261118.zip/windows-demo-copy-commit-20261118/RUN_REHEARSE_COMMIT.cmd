@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_FINANCIAL.ps1" -ManifestSHA256 3bec054723781f4e12a1710df2844ad40cccad525b3ba99d761c9ad3955371c7 -ExecuteRead
exit /b %errorlevel%
