@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_HANDOFF.ps1" -ManifestSHA256 7b772010991514804d55a68c0b43c069afe4968f1bf34fb6652860b67aba32af -CheckOnly
exit /b %errorlevel%
