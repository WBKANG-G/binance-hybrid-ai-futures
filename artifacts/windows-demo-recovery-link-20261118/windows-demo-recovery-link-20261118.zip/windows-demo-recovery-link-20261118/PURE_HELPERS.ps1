function Income-Integer([object]$Value,[string]$Code) {
 Inspect-Require ($null -ne $Value -and ($Value -is [string] -or $Value -is [int] -or $Value -is [long] -or $Value -is [decimal])) $Code
 $text=[Convert]::ToString($Value,[Globalization.CultureInfo]::InvariantCulture)
 Inspect-Require ($text -cmatch '^[0-9]{1,20}$') $Code
 return $text
}
function Income-Decimal([object]$Value) {
 Inspect-Require ($Value -is [string] -and $Value -cmatch '^-?[0-9]{1,12}(\.[0-9]{1,8})?$') 'INCOME_AMOUNT_INVALID'
 try {return [decimal]::Parse($Value,[Globalization.CultureInfo]::InvariantCulture)} catch {throw 'INCOME_AMOUNT_INVALID'}
}
function Income-Text([decimal]$Value) {return $Value.ToString('0.00000000',[Globalization.CultureInfo]::InvariantCulture)}
function Income-Boundaries([long]$Now,[int]$WeekStart) {
 Inspect-Require ($WeekStart -ge 0 -and $WeekStart -le 6) 'INCOME_WEEK_POLICY_INVALID'
 $offset=[TimeSpan]::FromHours(9);$kst=[DateTimeOffset]::FromUnixTimeMilliseconds($Now).ToOffset($offset)
 $day=New-Object DateTimeOffset($kst.Date,$offset)
 $weekday=([int]$kst.DayOfWeek+6)%7;$days=($weekday-$WeekStart+7)%7;$week=$day.AddDays(-$days)
 return [pscustomobject]@{day_key=$day.ToString('yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture);week_key=$week.ToString('yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture);day_ms=$day.ToUnixTimeMilliseconds();week_ms=$week.ToUnixTimeMilliseconds();week_start_kst=$WeekStart}
}
function Income-Account([string]$Body) {
 $data=Export-Decode $Body
 Inspect-Require ($data.GetType() -eq [System.Management.Automation.PSCustomObject] -and $data.assets -is [Array] -and $data.positions -is [Array]) 'INCOME_ACCOUNT_SCHEMA_INVALID'
 $usdt=@($data.assets|Where-Object {$_.asset -ceq 'USDT'});Inspect-Require ($usdt.Count -eq 1) 'INCOME_USDT_ASSET_NOT_UNIQUE'
 $wallet=Income-Decimal $usdt[0].walletBalance;$unrealized=Income-Decimal $usdt[0].unrealizedProfit
 Inspect-Require ($wallet -gt 0) 'INCOME_WALLET_NONPOSITIVE'
 $flat=$unrealized -eq 0
 foreach($position in $data.positions){if((Income-Decimal $position.positionAmt) -ne 0){$flat=$false}}
 return [pscustomobject]@{wallet=$wallet;usdt_unrealized=$unrealized;positions_flat=$flat}
}
function Current-Bool([object]$Value) {Inspect-Require ($Value -is [bool]) 'CURRENT_BOOLEAN_SCHEMA_INVALID';return $Value}
function Current-Mode([string]$Body) {
 $data=Export-Decode $Body;Inspect-Require ($data.GetType() -eq [System.Management.Automation.PSCustomObject]) 'CURRENT_MODE_SCHEMA_INVALID'
 return [pscustomobject]@{one_way=(-not (Current-Bool $data.dualSidePosition));single_asset=(-not (Current-Bool $data.multiAssetsMargin));account_can_trade=(Current-Bool $data.canTrade)}
}
function Current-BtcConfig([string]$Body) {
 $list=Read-List $Body;$rows=@($list.rows|Where-Object {$_.symbol -ceq 'BTCUSDT'});Inspect-Require ($rows.Count -eq 1) 'CURRENT_BTC_CONFIG_NOT_UNIQUE'
 $row=$rows[0];$leverage=Income-Integer $row.leverage 'CURRENT_LEVERAGE_INVALID';Inspect-Require ($leverage -cmatch '^[1-9][0-9]{0,2}$' -and @('ISOLATED','CROSSED') -ccontains $row.marginType) 'CURRENT_BTC_CONFIG_SCHEMA_INVALID'
 $auto=$row.isAutoAddMargin;Inspect-Require ($auto -is [bool] -or ($auto -is [string] -and @('true','false') -ccontains $auto)) 'CURRENT_AUTO_MARGIN_SCHEMA_INVALID'
 $autoOn=$auto -eq $true -or $auto -ceq 'true'
 return [pscustomobject]@{symbol='BTCUSDT';leverage=[int]$leverage;margin_type=$row.marginType;automatic_margin_addition=$autoOn;expected_isolated_2x_no_auto_add=($leverage -ceq '2' -and $row.marginType -ceq 'ISOLATED' -and -not $autoOn)}
}
function Current-Orders([string]$Body,[string]$Role) {
 $list=Read-List $Body;$ids=@{};$other=0
 foreach($row in $list.rows){
  Inspect-Require ($row.symbol -is [string] -and $row.symbol -cmatch '^[A-Z0-9_]{1,32}$') 'CURRENT_ORDER_SYMBOL_INVALID'
  $field='clientOrderId';$stateField='status';$allowed=@('NEW','PARTIALLY_FILLED','PENDING_CANCEL');if($Role -ceq 'ALGO'){$field='clientAlgoId';$stateField='algoStatus';$allowed=@('NEW','WORKING','TRIGGERING','PENDING_CANCEL')}
  $id=Inspect-Member $row $field;$state=Inspect-Member $row $stateField
  Inspect-Require ($id -is [string] -and $id.Length -gt 0 -and $id.Length -le 128 -and $state -is [string] -and $allowed -ccontains $state) 'CURRENT_OPEN_ORDER_SCHEMA_INVALID'
  $hash=Inspect-Hash ([Text.Encoding]::UTF8.GetBytes($id));Inspect-Require (-not $ids.ContainsKey($hash)) 'CURRENT_DUPLICATE_OPEN_ID';$ids[$hash]=$true
  if($row.symbol -cne 'BTCUSDT'){$other++}
 }
 return [pscustomobject]@{count=$list.returned_count;non_btc_count=$other;empty=($list.returned_count -eq 0)}
}
function Current-Positions([string]$Body) {
 $list=Read-List $Body;$keys=@{};$nonzero=0;$other=0;$hedged=0
 foreach($row in $list.rows){
  Inspect-Require ($row.symbol -is [string] -and $row.symbol -cmatch '^[A-Z0-9_]{1,32}$' -and @('BOTH','LONG','SHORT') -ccontains $row.positionSide) 'CURRENT_POSITION_SCHEMA_INVALID'
  $key=$row.symbol+':'+$row.positionSide;Inspect-Require (-not $keys.ContainsKey($key)) 'CURRENT_DUPLICATE_POSITION';$keys[$key]=$true
  $qty=Income-Decimal $row.positionAmt;if($row.positionSide -cne 'BOTH'){$hedged++};if($qty -ne 0){$nonzero++;if($row.symbol -cne 'BTCUSDT'){$other++}}
 }
 return [pscustomobject]@{returned_rows=$list.returned_count;nonzero_positions=$nonzero;nonzero_non_btc_positions=$other;hedge_side_rows=$hedged;flat=($nonzero -eq 0)}
}
function Current-Account([string]$Body) {
 $base=Income-Account $Body;$data=Export-Decode $Body;$usdt=@($data.assets|Where-Object {$_.asset -ceq 'USDT'})[0]
 $margin=Income-Decimal $data.totalInitialMargin;$allPnl=Income-Decimal $data.totalUnrealizedProfit;$available=Income-Decimal $usdt.availableBalance;$assetMargin=Income-Decimal $usdt.marginBalance
 Inspect-Require ($margin -ge 0 -and $available -ge 0) 'CURRENT_ACCOUNT_MARGIN_INVALID'
 return [pscustomobject]@{usdt_wallet=(Income-Text $base.wallet);usdt_available=(Income-Text $available);usdt_margin_balance=(Income-Text $assetMargin);total_initial_margin=(Income-Text $margin);total_unrealized_profit=(Income-Text $allPnl);positions_flat=$base.positions_flat;flat_unencumbered_usdt=($base.positions_flat -and $margin -eq 0 -and $allPnl -eq 0 -and $base.usdt_unrealized -eq 0 -and $available -eq $base.wallet -and $assetMargin -eq $base.wallet)}
}

function Export-Decode([string]$Body) {
 $value=Inspect-Json $Body
 Inspect-Require ($null -ne $value -and $value.GetType() -eq [System.Management.Automation.PSCustomObject]) 'PREVIEW_JSON_OBJECT_REQUIRED'
 return $value
}
