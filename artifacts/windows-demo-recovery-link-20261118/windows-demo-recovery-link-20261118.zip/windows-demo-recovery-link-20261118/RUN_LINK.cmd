@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_LINK.ps1" -ManifestSHA256 9ed837e7aead8b652b98c8423d2c3b04cd1a233485e774c8fce2a900b3c987ff
exit /b %errorlevel%
