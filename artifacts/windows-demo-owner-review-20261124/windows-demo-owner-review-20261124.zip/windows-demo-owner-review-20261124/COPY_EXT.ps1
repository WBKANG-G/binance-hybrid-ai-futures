$script:CopyDiagnosticId=$null
$script:CopySocket=$null
$script:CopyDiagnostic=$null
$script:CopyDiagnosticFailure=$null
$script:CopyRestoreHandle=$null
function Read-CopySources([object]$Config,[object]$Receipt,[object]$State) {
    $path=Find-RestoreEvidence $Config
    $handle=New-Object IO.FileStream($path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
    try {
        if ((Restore-Hash $path) -cne $Config.restore_receipt_sha256) { throw 'HANDOFF_RESTORE_HASH_MISMATCH' }
        $recovery=Read-RestoreJson $path; Assert-RestoreEvidence $recovery $Config
        $items=Assert-HandoffStoppedScope $Config $Receipt $State $recovery
        $script:CopyRestoreHandle=$handle
        return ,$items
    } catch { $handle.Dispose(); throw }
}
function Assert-NewClone([string]$Id,[string]$Volume,[object[]]$Original) {
    if (@($Original | ForEach-Object {$_.id}) -ccontains $Id -or [string]::IsNullOrWhiteSpace($script:CopySocket)) { throw 'RESTORE_CLONE_ID_INVALID' }
    $item=Read-Container $Id
    if ($item.restart.Name -cne 'no' -or @($item.mounts).Count -ne 2 -or (Project $item) -cne 'demo-copy-review') { throw 'RESTORE_CLONE_MOUNT_INVALID' }
    foreach ($spec in @(@('/var/lib/postgresql',$Volume),@('/review-socket',$script:CopySocket))) {
        $mount=@($item.mounts | Where-Object {$_.Destination -ceq $spec[0]})
        if ($mount.Count -ne 1 -or $mount[0].Type -cne 'volume' -or $mount[0].Name -cne $spec[1] -or -not $mount[0].RW) { throw 'RESTORE_CLONE_MOUNT_INVALID' }
    }
    $network=@(Backup-Docker @('inspect','--format','{{.HostConfig.NetworkMode}}',$Id) 1)
    if ($network.Count -ne 1 -or $network[0] -cne 'none') { throw 'RESTORE_CLONE_NETWORK_INVALID' }
}
