@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_FINANCIAL.ps1" -ManifestSHA256 11c746150320419ba595e3d629f0a0c36f4d5b7463d729d901091d0562bf10f7 -CheckOnly
exit /b %errorlevel%
