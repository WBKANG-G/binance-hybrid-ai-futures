BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL statement_timeout='5s';
SET LOCAL lock_timeout='2s';
SET LOCAL search_path=pg_catalog,public;
SET LOCAL timezone='UTC';
WITH source AS (
 SELECT *,jsonb_build_object('daily_key','2026-11-24','weekly_key','2026-11-23','daily_base','4998.74183608','weekly_base','4998.74183608','reconciled',false,'stream_ready',false) AS proposed_fields FROM public.demo_accounts WHERE account_id='DEMO-WINDOWS-ISOLATED-BTC-V1'
), candidate AS (SELECT *,state || proposed_fields AS proposed FROM source)
SELECT json_build_object(
 'paused',state->'paused', 'daily_key',state->>'daily_key', 'weekly_key',state->>'weekly_key',
 'orders',(SELECT count(*) FROM jsonb_object_keys(state->'orders')),
 'unresolved_requests',(SELECT count(*) FROM jsonb_each_text(state->'requests') WHERE value IN ('UNKNOWN','SUBMITTING','CANCEL_REQUESTED','NOT_FOUND_UNRESOLVED')),
 'account_state_sha256',encode(sha256(convert_to(state::text,'UTF8')),'hex'),
 'transaction_read_only',current_setting('transaction_read_only'),
 'financial',json_build_object('daily_base',state->>'daily_base','weekly_base',state->>'weekly_base','high_water',state->>'high_water','available_balance',state->>'available_balance',
 'initial',state->'value'->>'initial','realized',state->'value'->>'realized','unrealized',state->'value'->>'unrealized','fees',state->'value'->>'fees','funding',state->'value'->>'funding','net_deposits',state->'value'->>'net_deposits','value_as_of',state->'value'->>'as_of'),
 'request_states',(SELECT json_agg(json_build_object('request_reference_sha256',encode(sha256(convert_to(key,'UTF8')),'hex'),'request_state',value) ORDER BY key) FROM jsonb_each_text(state->'requests') WHERE value IN ('UNKNOWN','SUBMITTING','CANCEL_REQUESTED','NOT_FOUND_UNRESOLVED')),
 'risk_state',state->>'risk_state','reconciled',state->'reconciled','stream_ready',state->'stream_ready','last_reconciled',state->>'last_reconciled'
, 'owner_review',json_build_object(
 'fence',fence,
 'owner_present',owner IS NOT NULL,
 'owner_sha256',CASE WHEN owner IS NULL THEN NULL ELSE encode(sha256(convert_to(owner,'UTF8')),'hex') END,
 'lease_present',lease_until IS NOT NULL,
 'lease_until_utc',CASE WHEN lease_until IS NULL THEN NULL ELSE to_char(lease_until AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS.US"Z"') END,
 'lease_state',CASE WHEN lease_until IS NULL THEN 'ABSENT' WHEN lease_until > statement_timestamp() THEN 'ACTIVE' ELSE 'EXPIRED' END,
 'ownership_row_sha256',encode(sha256(convert_to(jsonb_build_object('owner',owner,'lease_until',lease_until,'fence',fence,'state_sha256',encode(sha256(convert_to(state::text,'UTF8')),'hex'))::text,'UTF8')),'hex'),
 'lease_clock_scope','COPY_DATABASE_STATEMENT_TIMESTAMP',
 'original_owner_verified',false,
 'row_lock_acquired',false),
 'period_candidate',json_build_object(
 'context','UNAPPROVED_ORIGINAL_RECOVERY_DESIGN_ONLY',
 'proposed_fields',proposed_fields,
 'before_state_pg_text_sha256',encode(sha256(convert_to(state::text,'UTF8')),'hex'),
 'candidate_financial_pg_text_sha256',encode(sha256(convert_to(proposed::text,'UTF8')),'hex'),
 'changed_top_level_fields',(SELECT coalesce(json_agg(name ORDER BY name),'[]'::json) FROM jsonb_object_keys(state || proposed) AS name WHERE state->name IS DISTINCT FROM proposed->name),
 'protected_jsonb_preserved',(state - ARRAY['daily_key','weekly_key','daily_base','weekly_base','reconciled','stream_ready'])::text IS NOT DISTINCT FROM (proposed - ARRAY['daily_key','weekly_key','daily_base','weekly_base','reconciled','stream_ready'])::text,
 'orders_requests_operations_preserved',((state->'orders')::text IS NOT DISTINCT FROM (proposed->'orders')::text) AND ((state->'requests')::text IS NOT DISTINCT FROM (proposed->'requests')::text) AND ((state->'operations')::text IS NOT DISTINCT FROM (proposed->'operations')::text),
 'paused_preserved',(state->'paused' IS NOT DISTINCT FROM proposed->'paused'),
 'candidate_paused',proposed->'paused',
 'audit_record_created',false,
 'commit_payload_verified',false,
 'apply_token_created',false)
)
 FROM candidate;
COMMIT;
