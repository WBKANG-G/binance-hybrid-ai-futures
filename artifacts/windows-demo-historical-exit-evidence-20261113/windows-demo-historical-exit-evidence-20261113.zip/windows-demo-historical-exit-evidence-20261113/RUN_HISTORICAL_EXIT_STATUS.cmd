@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0HISTORICAL_EXIT.ps1" -StatusOnly -ManifestSHA256 9299b1ede821a69b5508b636f48ad956add14b361e4b74d60212068a79f61929
exit /b %errorlevel%
