@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_COPY.ps1" -ManifestSHA256 25369a596f9b0b51219a6f96504f46cf1eb8a3780623ad476658e6cfc0772fa5 -CheckOnly
exit /b %errorlevel%
