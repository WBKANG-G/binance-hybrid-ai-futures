@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_RESTORE.ps1" -ManifestSHA256 e34abc3d238b800165e497c0701c2157dfd7c844ede58da329b8b6b3ff89b4bf -ExecuteRestore
exit /b %errorlevel%
