@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN_CURRENT.ps1" -ManifestSHA256 f933a23fe2e1cc4122581250015a3385057c7fc50a80db345bfa7d188630a53e -CollectOnce
exit /b %errorlevel%
