@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0FLAT_REVIEW.ps1" -ManifestSHA256 530ee90f74ae8a9be283efcf5444435dbfa8f0051d0ba5389d56241e81f3ba0c
exit /b %errorlevel%
