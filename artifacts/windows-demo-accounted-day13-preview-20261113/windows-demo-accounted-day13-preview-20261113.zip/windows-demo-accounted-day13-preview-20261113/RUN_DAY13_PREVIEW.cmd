@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0DAY13_PREVIEW.ps1" -ManifestSHA256 7051d8363f10b4d3905e514a8c9b3a94b49a7a466f2536af57a22aaead5c88fb
exit /b %errorlevel%
