@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0PLAN.ps1" -ManifestSHA256 1ff32197dce96d1e60e744a443b0653cab2df3528194a55c2134663a9273f382
exit /b %errorlevel%
