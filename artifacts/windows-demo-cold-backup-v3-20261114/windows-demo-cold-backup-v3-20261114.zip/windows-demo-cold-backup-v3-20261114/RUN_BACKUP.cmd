@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_BACKUP.ps1" -ManifestSHA256 4cf2d48b321f5094aff3c530b3afdfd211a1eaa9b05d3282bf7963418ad240e1 -ExecuteColdBackup
exit /b %errorlevel%
