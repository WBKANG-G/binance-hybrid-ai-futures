@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_COPY.ps1" -ManifestSHA256 bb123756a18f5feb189a838d1e7f68570eea86c0950d2f8fb9d0dfde683b9b0a -ExecuteReview
exit /b %errorlevel%
