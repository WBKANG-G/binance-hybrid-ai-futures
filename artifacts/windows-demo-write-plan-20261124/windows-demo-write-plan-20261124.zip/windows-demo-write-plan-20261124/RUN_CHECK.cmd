@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_PREPARE.ps1" -ManifestSHA256 2c4357ae216e976ae7069715a0cafd361db9c85599d0bf9581d1f11af1011079 -CheckOnly
exit /b %errorlevel%
