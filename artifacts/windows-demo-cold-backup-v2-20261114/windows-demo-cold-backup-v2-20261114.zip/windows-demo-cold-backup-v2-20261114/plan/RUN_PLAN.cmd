@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0PLAN.ps1" -ManifestSHA256 319919a2e2bff5a743979a9f222143dbd02d60c89450425e1f2384860429179a
exit /b %errorlevel%
