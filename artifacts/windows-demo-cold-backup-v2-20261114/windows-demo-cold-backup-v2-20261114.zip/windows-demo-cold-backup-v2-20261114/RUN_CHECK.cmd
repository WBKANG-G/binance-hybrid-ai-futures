@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_BACKUP.ps1" -ManifestSHA256 4494868bf88f73276a1e3b521a97c54fca55194577f6e28672a664c27a4488bf -CheckOnly
exit /b %errorlevel%
