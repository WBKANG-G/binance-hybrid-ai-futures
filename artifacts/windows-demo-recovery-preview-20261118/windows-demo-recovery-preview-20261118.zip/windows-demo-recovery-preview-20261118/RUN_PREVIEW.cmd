@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_PREVIEW.ps1" -ManifestSHA256 4d8bf9f5d8c5014f2fce052eb265eccf5ac75922f5cb53b83e9f36e480c222a6
exit /b %errorlevel%
