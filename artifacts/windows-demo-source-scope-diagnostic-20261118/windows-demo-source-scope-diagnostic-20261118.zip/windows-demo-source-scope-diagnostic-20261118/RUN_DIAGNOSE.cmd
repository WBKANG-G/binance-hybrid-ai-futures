@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_DIAGNOSE.ps1" -ManifestSHA256 e9f81a72621a99b944df23caf2836a36d7053ed9920c8413224ad83216696df2
exit /b %errorlevel%
