@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0REVIEW.ps1" -ManifestSHA256 98e9a6b70c71cadf8ef43093e5e5bfcac66985a7daf872cdd4b9fe801aee6eb7
exit /b %errorlevel%
