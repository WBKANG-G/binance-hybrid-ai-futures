@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_FINANCIAL.ps1" -ManifestSHA256 27bd318f33eb896a6d3ae43d1298b57a7767634a4385bbf54fbfcc03751fb5c6 -ExecuteRead
exit /b %errorlevel%
