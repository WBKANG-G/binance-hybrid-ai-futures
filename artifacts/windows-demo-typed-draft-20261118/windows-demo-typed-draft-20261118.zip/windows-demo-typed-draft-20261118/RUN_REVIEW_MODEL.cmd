@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_FINANCIAL.ps1" -ManifestSHA256 1b4fbd5d37473486d9dca15409e8b7d9b2ecd3f8a8d9f0511d727d2505d879aa -ExecuteRead
exit /b %errorlevel%
