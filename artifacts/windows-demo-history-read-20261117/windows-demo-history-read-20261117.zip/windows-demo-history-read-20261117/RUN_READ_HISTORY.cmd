@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0RUN_READ.ps1" -ManifestSHA256 345f1e16e21582c303f6d765c8dc80b73577a77606eab815c0c4f55035edadd4 -CollectOnce
exit /b %errorlevel%
