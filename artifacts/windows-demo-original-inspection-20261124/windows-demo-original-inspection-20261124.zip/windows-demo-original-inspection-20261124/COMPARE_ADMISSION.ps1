function Assert-CompareHelper([string]$Id,[object]$State,[object[]]$Original) {
 if($Id -cnotmatch '^[0-9a-f]{64}$' -or @($Original.id) -ccontains $Id){throw 'COMPARE_HELPER_ID_INVALID'}
 $item=Read-Container $Id
 if($item.image -cne $State.canonical_images[0] -or $item.running -or $item.restarting -or $item.paused -or $item.dead -or $item.restart.Name -cne 'no' -or $item.restart.MaximumRetryCount -ne 0 -or @($item.mounts).Count -ne 2){throw 'COMPARE_HELPER_SCOPE_INVALID'}
 foreach($spec in @(@('/source/database',$State.database_volume),@('/source/runtime',$State.runtime_volume))){
  $mount=@($item.mounts|Where-Object {$_.Destination -ceq $spec[0]})
  if($mount.Count -ne 1 -or $mount[0].Type -cne 'volume' -or $mount[0].Name -cne $spec[1] -or $mount[0].RW){throw 'COMPARE_HELPER_MOUNT_INVALID'}
 }
 $lines=@(Backup-Docker @('inspect','--format','{{json .HostConfig}}{{println}}{{json .Config.User}}{{println}}{{json .Config.Entrypoint}}{{println}}{{json .Config.Cmd}}',$Id) 4)
 if($lines.Count -ne 4){throw 'COMPARE_HELPER_SCOPE_INVALID'}
 $hostConfig=ConvertFrom-Json -InputObject $lines[0]
 $user=ConvertFrom-Json -InputObject ('{"value":'+$lines[1]+'}')
 $entry=ConvertFrom-Json -InputObject ('{"value":'+$lines[2]+'}')
 $command=ConvertFrom-Json -InputObject ('{"value":'+$lines[3]+'}')
 if($hostConfig.NetworkMode -cne 'none' -or -not $hostConfig.ReadonlyRootfs -or $hostConfig.Privileged -or $hostConfig.Memory -ne 536870912 -or $hostConfig.PidsLimit -ne 32 -or (@($hostConfig.CapDrop) -join '|') -cne 'ALL' -or @('DAC_OVERRIDE','CAP_DAC_OVERRIDE') -cnotcontains (@($hostConfig.CapAdd) -join '|') -or (@($hostConfig.SecurityOpt) -join '|') -cne 'no-new-privileges' -or @($hostConfig.Devices).Count -ne 0 -or $user.value -cne '0:0' -or (@($entry.value) -join '|') -cne 'python' -or (@($command.value) -join '|') -cne '-I|-B|-'){throw 'COMPARE_HELPER_ISOLATION_INVALID'}
}
