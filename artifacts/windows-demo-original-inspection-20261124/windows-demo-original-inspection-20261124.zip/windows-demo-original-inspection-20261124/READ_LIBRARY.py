"""Explicit offline PG/runtime byte-copy candidate; no service control or network.

Caller must freeze BOTH sources first. This module cannot attest writer quiescence.
Windows plan package does not invoke or distribute this mutation candidate.
"""

import hashlib
import json
import os
import stat
import tarfile
import time
from pathlib import Path
from typing import Any, BinaryIO

MAX_FILES = 50000
MAX_BYTES = 8 * 1024**3
MAX_FILE = 2 * 1024**3
MAX_MANIFEST = 16 * 1024**2
GROUPS = ("database", "runtime")
DIR_FLAGS = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC


def require(ok: bool, code: str) -> None:
    if not ok:
        raise ValueError(code)


def directory(path: Path) -> int:
    require(path.is_absolute(), "COLD_PATH_INVALID")
    fd = os.open("/", DIR_FLAGS)
    try:
        for part in path.parts[1:]:
            require(part not in {"", ".", ".."}, "COLD_PATH_INVALID")
            next_fd = os.open(part, DIR_FLAGS, dir_fd=fd)
            os.close(fd)
            fd = next_fd
        return fd
    except BaseException:
        os.close(fd)
        raise


def metadata(info: os.stat_result) -> dict[str, int]:
    require(0 <= info.st_uid <= 65535 and 0 <= info.st_gid <= 65535, "COLD_OWNER_INVALID")
    require(
        stat.S_IMODE(info.st_mode) <= (0o3777 if stat.S_ISDIR(info.st_mode) else 0o777)
        and info.st_mtime_ns >= 0,
        "COLD_MODE_INVALID",
    )
    return dict(
        uid=info.st_uid, gid=info.st_gid, mode=stat.S_IMODE(info.st_mode), mtime_ns=info.st_mtime_ns
    )


def unchanged(before: os.stat_result, after: os.stat_result) -> None:
    require(
        (
            before.st_dev,
            before.st_ino,
            before.st_mode,
            before.st_uid,
            before.st_gid,
            before.st_size,
            before.st_mtime_ns,
            before.st_ctime_ns,
        )
        == (
            after.st_dev,
            after.st_ino,
            after.st_mode,
            after.st_uid,
            after.st_gid,
            after.st_size,
            after.st_mtime_ns,
            after.st_ctime_ns,
        ),
        "COLD_SOURCE_CHANGED",
    )


def validate_manifest(value: Any) -> None:
    require(
        isinstance(value, dict)
        and set(value)
        == {
            "protocol",
            "groups",
            "external_custody_verified",
            "source_freeze_independently_verified",
            "execution_approved",
            "orders_enabled",
            "live_trading_enabled",
        },
        "COLD_MANIFEST_INVALID",
    )
    require(
        value["protocol"] == "COLD_OFFLINE_BYTE_COPY_CANDIDATE_V1"
        and set(value["groups"]) == set(GROUPS),
        "COLD_MANIFEST_INVALID",
    )
    require(
        all(
            value[k] is False
            for k in (
                "external_custody_verified",
                "source_freeze_independently_verified",
                "execution_approved",
                "orders_enabled",
                "live_trading_enabled",
            )
        ),
        "COLD_MANIFEST_INVALID",
    )
    for group in value["groups"].values():
        require(
            set(group) == {"root", "entries", "logical_bytes", "archive_bytes", "archive_sha256"},
            "COLD_MANIFEST_INVALID",
        )
        require(
            isinstance(group["entries"], list) and len(group["entries"]) <= MAX_FILES,
            "COLD_MANIFEST_INVALID",
        )
        seen = set()
        for item in group["entries"]:
            require(
                set(item) == {"path", "uid", "gid", "mode", "mtime_ns", "kind", "size", "sha256"},
                "COLD_MANIFEST_INVALID",
            )
            name = item["path"]
            require(
                isinstance(name, str)
                and bool(name)
                and not name.startswith("/")
                and "\\" not in name
                and all(p not in {"", ".", ".."} for p in name.split("/"))
                and name not in seen
                and len(name.encode()) <= 2048,
                "COLD_PATH_INVALID",
            )
            seen.add(name)
            require(
                item["kind"] in {"directory", "file"}
                and type(item["size"]) is int
                and 0 <= item["size"] <= MAX_FILE,
                "COLD_MANIFEST_INVALID",
            )
            require(item["kind"] == "file" or item["size"] == 0, "COLD_MANIFEST_INVALID")
        require(set(group["root"]) == {"uid", "gid", "mode", "mtime_ns"}, "COLD_MANIFEST_INVALID")
        for item in [group["root"], *group["entries"]]:
            for k, limit in (
                ("uid", 65535),
                ("gid", 65535),
                (
                    "mode",
                    0o3777 if item is group["root"] or item.get("kind") == "directory" else 0o777,
                ),
                ("mtime_ns", 2**63 - 1),
            ):
                require(type(item[k]) is int and 0 <= item[k] <= limit, "COLD_MANIFEST_INVALID")


def verify_restored_metadata(info: os.stat_result, expected: dict[str, Any]) -> None:
    require(
        metadata(info) == {key: expected[key] for key in ("uid", "gid", "mode", "mtime_ns")},
        "COLD_RESTORE_METADATA_MISMATCH",
    )


