@echo off
setlocal DisableDelayedExpansion
echo ORIGINAL_INSPECTION_START_SCOPE_APPROVED_SINGLE_ATTEMPT_ONLY
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_INSPECT.ps1" -ManifestSHA256 3a4e4fa477de8a0b5a4c06b129a90340c91e29e8a26e74f4028617b8ee79311c -InspectOnce
exit /b %errorlevel%
