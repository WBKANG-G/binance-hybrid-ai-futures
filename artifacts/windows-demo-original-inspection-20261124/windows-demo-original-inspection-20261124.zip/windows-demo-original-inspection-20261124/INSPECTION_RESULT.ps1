$script:OwnerFinancialValidator=(Get-Item Function:Assert-CopyFinancial).ScriptBlock
$script:OwnerProtocolReview=$null
function Owner-Require([bool]$Condition,[string]$Code) {if(-not $Condition){throw $Code}}
function Owner-Bool([object]$Value,[bool]$Expected) {return ($Value -is [bool] -and $Value -eq $Expected)}
function Assert-OriginalRead([object]$Account) {
 Owner-Require ($null -ne $Account.PSObject.Properties['owner_review'] -and $null -ne $Account.PSObject.Properties['period_candidate']) 'OWNER_SQL_SCHEMA_INVALID'
 $o=$Account.owner_review;$p=$Account.period_candidate
 $financial=$Account|Select-Object -Property * -ExcludeProperty owner_review,period_candidate
 & $script:OwnerFinancialValidator $financial
 Owner-Require ((@($o.PSObject.Properties.Name|Sort-Object)-join '|') -ceq 'fence|lease_clock_scope|lease_present|lease_state|lease_until_utc|original_owner_verified|owner_present|owner_sha256|ownership_row_sha256|row_lock_acquired') 'OWNER_SQL_SCHEMA_INVALID'
 Owner-Require (($o.fence -is [int] -or $o.fence -is [long]) -and $o.fence -eq 110) 'OWNER_REFERENCE_FENCE_CHANGED'
 Owner-Require ($o.owner_present -is [bool] -and $o.lease_present -is [bool] -and $o.lease_clock_scope -ceq 'ISOLATED_ORIGINAL_DATABASE_STATEMENT_TIMESTAMP' -and (Owner-Bool $o.original_owner_verified $true) -and (Owner-Bool $o.row_lock_acquired $false) -and $o.ownership_row_sha256 -cmatch '^[0-9a-f]{64}$') 'OWNER_SQL_SCOPE_INVALID'
 if($o.owner_present){Owner-Require ($o.owner_sha256 -is [string] -and $o.owner_sha256 -cmatch '^[0-9a-f]{64}$') 'OWNER_IDENTITY_HASH_INVALID'}else{Owner-Require ($null -eq $o.owner_sha256) 'OWNER_IDENTITY_HASH_INVALID'}
 if($o.lease_present){
  Owner-Require (@('ACTIVE','EXPIRED') -ccontains $o.lease_state) 'OWNER_LEASE_SCHEMA_INVALID'
  $stamp=$o.lease_until_utc
  if($stamp -is [DateTime]){Owner-Require ($stamp.Kind -eq [DateTimeKind]::Utc) 'OWNER_LEASE_SCHEMA_INVALID'}
  elseif($stamp -is [DateTimeOffset]){Owner-Require ($stamp.Offset -eq [TimeSpan]::Zero) 'OWNER_LEASE_SCHEMA_INVALID'}
  else{
   Owner-Require ($stamp -is [string] -and $stamp -cmatch '^[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}\.[0-9]{6}Z$') 'OWNER_LEASE_SCHEMA_INVALID'
   try{$null=[DateTimeOffset]::ParseExact($stamp,"yyyy-MM-dd'T'HH:mm:ss.ffffff'Z'",[Globalization.CultureInfo]::InvariantCulture,[Globalization.DateTimeStyles]::AssumeUniversal)}catch{throw 'OWNER_LEASE_SCHEMA_INVALID'}
  }
 }else{Owner-Require ($null -eq $o.lease_until_utc -and $o.lease_state -ceq 'ABSENT') 'OWNER_LEASE_SCHEMA_INVALID'}
 Owner-Require ((@($p.PSObject.Properties.Name|Sort-Object)-join '|') -ceq 'apply_token_created|audit_record_created|before_state_pg_text_sha256|candidate_financial_pg_text_sha256|candidate_paused|changed_top_level_fields|commit_payload_verified|context|orders_requests_operations_preserved|paused_preserved|proposed_fields|protected_jsonb_preserved') 'OWNER_CANDIDATE_SCHEMA_INVALID'
 Owner-Require ($p.context -ceq 'UNAPPROVED_ORIGINAL_RECOVERY_DESIGN_ONLY' -and $p.before_state_pg_text_sha256 -ceq $Account.account_state_sha256 -and $p.candidate_financial_pg_text_sha256 -cmatch '^[0-9a-f]{64}$' -and $p.candidate_financial_pg_text_sha256 -cne $Account.account_state_sha256) 'OWNER_CANDIDATE_HASH_INVALID'
 foreach($k in @('protected_jsonb_preserved','orders_requests_operations_preserved','paused_preserved','candidate_paused')){Owner-Require (Owner-Bool $p.$k $true) 'OWNER_PROTECTED_STATE_CHANGED'}
 foreach($k in @('audit_record_created','commit_payload_verified','apply_token_created')){Owner-Require (Owner-Bool $p.$k $false) 'OWNER_DRAFT_AUTHORITY_INVALID'}
 $fields=$p.proposed_fields
 Owner-Require ((@($fields.PSObject.Properties.Name|Sort-Object)-join '|') -ceq 'daily_base|daily_key|reconciled|stream_ready|weekly_base|weekly_key' -and $fields.daily_key -is [string] -and $fields.daily_key -ceq '2026-11-24' -and $fields.weekly_key -ceq '2026-11-23' -and $fields.daily_base -is [string] -and $fields.weekly_base -is [string] -and $fields.daily_base -ceq '4998.74183608' -and $fields.weekly_base -ceq '4998.74183608' -and (Owner-Bool $fields.reconciled $false) -and (Owner-Bool $fields.stream_ready $false)) 'OWNER_CANDIDATE_FIELDS_INVALID'
 $changes=@($p.changed_top_level_fields)
 Owner-Require (@($changes|Sort-Object -Unique).Count -eq $changes.Count -and $changes.Count -le 6 -and $changes -ccontains 'daily_key' -and $changes -ccontains 'weekly_key') 'OWNER_CHANGED_FIELDS_INVALID'
 foreach($k in $changes){Owner-Require (@('daily_key','weekly_key','daily_base','weekly_base','reconciled','stream_ready') -ccontains $k) 'OWNER_PROTECTED_STATE_CHANGED'}
}
