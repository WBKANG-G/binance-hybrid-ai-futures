$script:CopyDiagnosticId=$null
$script:CopySocket=$null
$script:CopyDiagnostic=$null
$script:CopyDiagnosticFailure=$null
$script:CopyRestoreHandle=$null
function Read-CopySources([object]$Config,[object]$Receipt,[object]$State) {
    $path=Find-RestoreEvidence $Config
    $handle=New-Object IO.FileStream($path,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
    try {
        if ((Restore-Hash $path) -cne $Config.restore_receipt_sha256) { throw 'HANDOFF_RESTORE_HASH_MISMATCH' }
        $recovery=Read-RestoreJson $path; Assert-RestoreEvidence $recovery $Config
        $items=Assert-HandoffStoppedScope $Config $Receipt $State $recovery
        $script:CopyRestoreHandle=$handle
        return ,$items
    } catch { $handle.Dispose(); throw }
}
