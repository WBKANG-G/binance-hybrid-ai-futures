function Restore-CanonicalMetadataJson([object]$Value,[int]$Depth=0) {
    if ($Depth -gt 16) { throw 'RESTORE_METADATA_DEPTH_INVALID' }
    if ($null -eq $Value) { return 'null' }
    if ($Value -is [string] -or $Value -is [ValueType]) { return (ConvertTo-Json -InputObject $Value -Compress) }
    if ($Value -is [System.Array]) {
        $parts=@()
        foreach ($entry in $Value) { $parts+=,(Restore-CanonicalMetadataJson $entry ($Depth+1)) }
        return ('['+($parts -join ',')+']')
    }
    $parts=@()
    foreach ($property in @($Value.PSObject.Properties | Sort-Object -Property Name)) {
        $key=ConvertTo-Json -InputObject ([string]$property.Name) -Compress
        $parts+=,($key+':'+(Restore-CanonicalMetadataJson $property.Value ($Depth+1)))
    }
    return ('{'+($parts -join ',')+'}')
}
function Resolve-RestoreImageMatch([string]$Reference,[string]$Expected) {
    if ($Reference -cnotmatch '^sha256:[0-9a-f]{64}$' -or $Expected -cnotmatch '^sha256:[0-9a-f]{64}$') { return $false }
    $values=@(Backup-Docker @('image','inspect','--format','{{.Id}}',$Reference) 1)
    return ($values.Count -eq 1 -and $values[0] -ceq $Expected)
}
function Restore-SnapshotComparableJson([object]$Item) {
    # Mount list order is not a Docker identity. Preserve EVERY mount field/value.
    $record=[ordered]@{}
    foreach ($property in $Item.PSObject.Properties) {
        if ($property.Name -ceq 'mounts') { $record[$property.Name]=@($Item.mounts | Sort-Object -Property Destination) }
        else { $record[$property.Name]=$property.Value }
    }
    return (Restore-CanonicalMetadataJson ([pscustomobject]$record))
}
function Assert-RestoreSourceSnapshot([object[]]$Original,[string[]]$Helpers,[bool]$Frozen=$false) {
    if ($Frozen) { throw 'RESTORE_SNAPSHOT_MODE_INVALID' }
    $current=@(Container-Ids)
    $expected=@(@($Original | ForEach-Object {$_.id})+$Helpers | Sort-Object)
    if (($current -join '|') -cne ($expected -join '|')) { $script:RestoreScopeProbe=[pscustomobject]@{step='FRESH_CONTAINER_SET';expected_count=$expected.Count;actual_count=$current.Count}; throw 'COLD_CONTAINER_SET_CHANGED' }
    foreach ($old in $Original) {
        $fresh=Read-Container $old.id
        if ($fresh.running -ne $old.running -or $fresh.restarting -or $fresh.paused -or $fresh.dead) { throw 'COLD_SOURCE_RUNNING_STATE_CHANGED' }
        if ((Restore-SnapshotComparableJson $fresh) -cne (Restore-SnapshotComparableJson $old)) {
            $fields=@()
            foreach ($field in @('id','name','image','labels','mounts','running','restarting','paused','dead','restart','networks')) {
                if ($null -eq $old.PSObject.Properties[$field] -or $null -eq $fresh.PSObject.Properties[$field]) { continue }
                $a=$old.$field; $b=$fresh.$field
                if ($field -ceq 'mounts') { $a=@($a | Sort-Object -Property Destination); $b=@($b | Sort-Object -Property Destination) }
                if ((ConvertTo-Json -InputObject $a -Depth 12 -Compress) -cne (ConvertTo-Json -InputObject $b -Depth 12 -Compress)) { $fields+=,$field }
            }
            $script:RestoreScopeProbe=[pscustomobject]@{step='FRESH_SNAPSHOT_MISMATCH';fields=$fields}
            throw 'COLD_SOURCE_CONFIGURATION_CHANGED'
        }
    }
}
function Restore-MountDiagnosticValues([object[]]$Mounts) {
    # Normalize known metadata values ONLY for diagnosis; no authorization uses this.
    $values=@()
    foreach ($mount in @($Mounts | Sort-Object -Property Destination)) {
        $record=[ordered]@{}
        foreach ($field in @('Type','Source','Destination','RW','Name','Driver','Mode','Propagation')) {
            $record[$field]=$null
            if ($null -ne $mount.PSObject.Properties[$field]) { $record[$field]=$mount.$field }
        }
        $values+=,[pscustomobject]$record
    }
    return (ConvertTo-Json -InputObject $values -Depth 8 -Compress)
}
function Assert-RestoredWorkerReport([object]$restored,[object]$receipt) {
    if ((@($restored.PSObject.Properties.Name | Sort-Object) -join '|') -cne (@(@('status','file_counts','pg_uid','pg_gid','clone_pid_removed','source_changed') | Sort-Object) -join '|') -or $restored.status -cne 'CLONE_BYTES_AND_METADATA_RESTORED' -or $restored.source_changed -isnot [bool] -or $restored.source_changed -or $restored.clone_pid_removed -isnot [bool]) { throw 'RESTORE_WORKER_OUTPUT_INVALID' }
    foreach ($name in @('pg_uid','pg_gid')) { $minimum=0; if ($name -ceq 'pg_uid') { $minimum=1 }; if (($restored.$name -isnot [int] -and $restored.$name -isnot [long]) -or $restored.$name -lt $minimum -or $restored.$name -gt 65535) { throw 'RESTORE_WORKER_OUTPUT_INVALID' } }
    if ($restored.file_counts -isnot [pscustomobject] -or (@($restored.file_counts.PSObject.Properties.Name | Sort-Object) -join '|') -cne 'database|runtime') { throw 'RESTORE_WORKER_OUTPUT_INVALID' }
    foreach ($group in @('database','runtime')) { if (($restored.file_counts.$group -isnot [int] -and $restored.file_counts.$group -isnot [long]) -or $restored.file_counts.$group -lt 1 -or $restored.file_counts.$group -gt 50000 -or $restored.file_counts.$group -ne $receipt.file_counts.$group) { throw 'RESTORE_WORKER_OUTPUT_INVALID' } }
}
# Only freshly created clone IDs may be started or signalled. No source-volume mounts.
function Restore-Hash([string]$Path) { return (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant() }
function Read-RestoreJson([string]$Path,[long]$Maximum=1048576) {
    $file=Get-Item -LiteralPath $Path
    if ($file.Length -lt 2 -or $file.Length -gt $Maximum -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'RESTORE_INPUT_INVALID' }
    return (Get-Content -Raw -LiteralPath $Path | ConvertFrom-Json)
}
function Find-RetainedBackup([object]$Config) {
    $base=Join-Path ([Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)) 'WBKANG-DEMO-Backups'
    $folders=@(Get-ChildItem -LiteralPath $base -Directory -Filter 'cold-20261114-*')
    if ($folders.Count -gt 32) { throw 'RESTORE_BACKUP_SEARCH_LIMIT' }
    $matches=@()
    foreach ($folder in $folders) {
        if (($folder.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'RESTORE_INPUT_INVALID' }
        $receipt=Join-Path $folder.FullName 'BACKUP_RECEIPT.json'
        if ([IO.File]::Exists($receipt)) {
            Assert-PrivateBackupDirectory $folder.FullName
            Assert-PrivateBackupFiles $folder.FullName
            if ((Restore-Hash $receipt) -ceq $Config.receipt_sha256) { $matches+=,$folder.FullName }
        }
    }
    if ($matches.Count -ne 1) { throw 'RESTORE_RETAINED_RECEIPT_NOT_UNIQUE' }
    return $matches[0]
}
function Assert-InputHashes([string]$Directory,[object]$Config,[object]$Receipt) {
    Assert-PrivateBackupDirectory $Directory; Assert-PrivateBackupFiles $Directory
    if ((Restore-Hash (Join-Path $Directory 'BACKUP_RECEIPT.json')) -cne $Config.receipt_sha256 -or (Restore-Hash (Join-Path $Directory 'manifest.json')) -cne $Config.manifest_sha256 -or $Receipt.manifest_sha256 -cne $Config.manifest_sha256) { throw 'RESTORE_RETAINED_HASH_MISMATCH' }
    if ($Receipt.status -cne 'STOPPED_RAW_COPY_VERIFIED_NOT_RECOVERY_PROOF' -or $Receipt.source_reference -cne $Config.preservation_source_reference) { throw 'RESTORE_RECEIPT_INVALID' }
    foreach ($flag in @('source_containers_started','source_clean_shutdown_verified','account_pause_rechecked','source_data_archive_restore_tested','offline_handoff_performed','automatic_resume','automatic_retry','execution_approved','orders_enabled','live_trading_enabled')) {
        if ($Receipt.$flag -isnot [bool] -or $Receipt.$flag) { throw 'RESTORE_RECEIPT_INVALID' }
    }
    if ($Receipt.source_services_observed_stopped -isnot [bool] -or -not $Receipt.source_services_observed_stopped -or $Receipt.order_writes -ne 0 -or $Receipt.actual_http_attempts -ne 0) { throw 'RESTORE_RECEIPT_INVALID' }
    foreach ($pair in @(@('BACKUP_STATE.json',$Receipt.state_sha256),@('images.tar',$Receipt.image_archive_sha256))) {
        if ($pair[1] -isnot [string] -or $pair[1] -cnotmatch '^[0-9a-f]{64}$' -or (Restore-Hash (Join-Path $Directory $pair[0])) -cne $pair[1]) { throw 'RESTORE_INPUT_HASH_MISMATCH' }
    }
    foreach ($group in @('database','runtime')) {
        $record=$Receipt.archives.$group
        $file=Get-Item -LiteralPath (Join-Path $Directory ($group+'.tar'))
        if ($record.sha256 -cnotmatch '^[0-9a-f]{64}$' -or $file.Length -ne $record.bytes -or (Restore-Hash $file.FullName) -cne $record.sha256) { throw 'RESTORE_INPUT_HASH_MISMATCH' }
    }
}
function Read-RestoreSources([object]$Config,[object]$Receipt,[object]$State) {
    $script:RestoreScopeProbe=[pscustomobject]@{step='STATE_HEADER'}
    if ($State.protocol -cne 'STOPPED_UNCLEAN_PRESERVATION_V1' -or $State.source_reference -cne $Config.preservation_source_reference -or $State.pgdata_relative -cne '18/docker' -or $State.key_session_excluded -isnot [bool] -or -not $State.key_session_excluded -or $State.automatic_resume_authorized -isnot [bool] -or $State.automatic_resume_authorized -or @($State.canonical_images).Count -ne 2) { throw 'RESTORE_STATE_INVALID' }
    foreach ($name in @($State.database_volume,$State.runtime_volume,$Receipt.output_volume)) { if ($name -isnot [string] -or $name -cnotmatch '^[A-Za-z0-9][A-Za-z0-9_.-]{0,254}$') { throw 'RESTORE_STATE_INVALID' } }
    if ($State.database_volume -ceq $State.runtime_volume -or @($State.database_volume,$State.runtime_volume) -ccontains $Receipt.output_volume) { throw 'RESTORE_STATE_INVALID' }
    foreach ($id in $State.canonical_images) { if ($id -isnot [string] -or $id -cnotmatch '^sha256:[0-9a-f]{64}$') { throw 'RESTORE_STATE_INVALID' } }
    if (@($Receipt.helper_container_ids).Count -ne 1 -or $Receipt.helper_container_ids[0] -cnotmatch '^[0-9a-f]{64}$') { throw 'RESTORE_STATE_INVALID' }
    $items=@(@(Container-Ids) | ForEach-Object {Read-Container $_})
    $script:RestoreScopeProbe=[pscustomobject]@{step='PRESERVATION_HELPER'}
    $oldWorker=@($items | Where-Object {$_.id -ceq $Receipt.helper_container_ids[0]})
    if ($oldWorker.Count -ne 1 -or $oldWorker[0].running -or $oldWorker[0].paused -or $oldWorker[0].restarting -or $oldWorker[0].dead -or $oldWorker[0].restart.Name -cne 'no' -or $oldWorker[0].restart.MaximumRetryCount -ne 0 -or -not (Resolve-RestoreImageMatch $oldWorker[0].image $State.canonical_images[0]) -or @($oldWorker[0].mounts).Count -ne 3) { throw 'RESTORE_PRESERVATION_HELPER_CHANGED' }
    if (@($State.source_snapshots | ForEach-Object {$_.id}) -ccontains $oldWorker[0].id -or @($Config.api_container_id,$Config.database_container_id) -ccontains $oldWorker[0].id) { throw 'RESTORE_PRESERVATION_HELPER_CHANGED' }
    foreach ($spec in @(@('/source/database',$State.database_volume,$false),@('/source/runtime',$State.runtime_volume,$false),@('/output',$Receipt.output_volume,$true))) {
        $mount=@($oldWorker[0].mounts | Where-Object {$_.Destination -ceq $spec[0]})
        if ($mount.Count -ne 1 -or $mount[0].Type -cne 'volume' -or $mount[0].Name -cne $spec[1] -or $mount[0].RW -ne $spec[2]) { throw 'RESTORE_PRESERVATION_HELPER_CHANGED' }
    }
    $labelled=@($items | Where-Object {(Project $_) -ceq 'hybrid-windows'})
    # Only this verified, receipt-bound reader is excluded, never a label/name pattern.
    $project=@($labelled | Where-Object {$_.id -cne $oldWorker[0].id})
    $script:RestoreScopeProbe=[pscustomobject]@{step='CONTAINER_COUNTS';labelled_project_count=$labelled.Count;project_count=$project.Count;saved_count=@($State.source_snapshots).Count;verified_helper_excluded=$true;helper_had_project_label=((Project $oldWorker[0]) -ceq 'hybrid-windows')}
    if ($project.Count -ne 7 -or @($State.source_snapshots).Count -ne 6) { throw 'RESTORE_SOURCE_SCOPE_CHANGED' }
    foreach ($role in @('api','db','web','alerts','key-session')) {
        $expected=1; if ($role -ceq 'api') { $expected=3 }
        $actual=@($project | Where-Object {(Service $_) -ceq $role}).Count
        $script:RestoreScopeProbe=[pscustomobject]@{step='ROLE_COUNT';role=$role;expected=$expected;actual=$actual}
        if ($actual -ne $expected) { throw 'RESTORE_SOURCE_SCOPE_CHANGED' }
    }
    $script:RestoreScopeProbe=[pscustomobject]@{step='STOPPED_STATE'}
    foreach ($item in $project) {
        if ($item.running -or $item.paused -or $item.dead -or $item.restarting -or $item.restart.Name -cne 'no' -or $item.restart.MaximumRetryCount -ne 0) { throw 'RESTORE_ORIGINAL_NOT_STOPPED' }
    }
    $api=@($project | Where-Object {$_.id -ceq $Config.api_container_id -and (Service $_) -ceq 'api' -and $_.name -ceq '/hybrid-windows-api-1'})
    $db=@($project | Where-Object {$_.id -ceq $Config.database_container_id -and (Service $_) -ceq 'db'})
    $script:RestoreScopeProbe=[pscustomobject]@{step='PRIMARY_SELECTION';api_matches=$api.Count;database_matches=$db.Count}
    if ($api.Count -ne 1 -or $db.Count -ne 1) { throw 'RESTORE_SOURCE_SCOPE_CHANGED' }
    $database=Volume-Mount $db[0] '/var/lib/postgresql'; $runtime=Volume-Mount $api[0] '/app/demo-export-state'
    $script:RestoreScopeProbe=[pscustomobject]@{step='PRIMARY_BINDINGS';database_volume_match=($database.Name -ceq $State.database_volume);runtime_volume_match=($runtime.Name -ceq $State.runtime_volume);api_image_reference_match=($api[0].image -ceq $State.canonical_images[0]);database_image_reference_match=($db[0].image -ceq $State.canonical_images[1]);api_image_resolves_to_canonical=$null;database_image_resolves_to_canonical=$null}
    $script:RestoreScopeProbe.api_image_resolves_to_canonical=(Resolve-RestoreImageMatch $api[0].image $State.canonical_images[0])
    $script:RestoreScopeProbe.database_image_resolves_to_canonical=(Resolve-RestoreImageMatch $db[0].image $State.canonical_images[1])
    if ($database.Name -cne $State.database_volume -or $runtime.Name -cne $State.runtime_volume -or -not $script:RestoreScopeProbe.api_image_resolves_to_canonical -or -not $script:RestoreScopeProbe.database_image_resolves_to_canonical) { throw 'RESTORE_SOURCE_SCOPE_CHANGED' }
    $snapshotIndex=-1
    foreach ($saved in $State.source_snapshots) {
        $snapshotIndex++
        $now=@($project | Where-Object {$_.id -ceq $saved.id -and (Service $_) -cne 'key-session'})
        $safeRole='OTHER'
        if (@('api','db','alerts','web') -ccontains $saved.service) { $safeRole=$saved.service }
        $script:RestoreScopeProbe=[pscustomobject]@{step='SAVED_SNAPSHOT';snapshot_index=$snapshotIndex;role=$safeRole;container_matches=$now.Count;image_match=$null;service_match=$null;restart_json_match=$null;restart_values_match=$null;mounts_json_match=$null;mounts_values_match=$null;restart_metadata_match=$null;mounts_metadata_match=$null}
        if ($now.Count -eq 1) {
            $script:RestoreScopeProbe.image_match=($now[0].image -ceq $saved.image)
            $script:RestoreScopeProbe.service_match=((Service $now[0]) -ceq $saved.service)
            $script:RestoreScopeProbe.restart_json_match=(($now[0].restart | ConvertTo-Json -Compress) -ceq ($saved.restart | ConvertTo-Json -Compress))
            $script:RestoreScopeProbe.restart_values_match=($now[0].restart.Name -ceq $saved.restart.Name -and $now[0].restart.MaximumRetryCount -eq $saved.restart.MaximumRetryCount)
            $currentMounts=@($now[0].mounts | Where-Object {$_.Destination -cne '/run/demo-keys'})
            $script:RestoreScopeProbe.mounts_json_match=(($currentMounts | ConvertTo-Json -Depth 8 -Compress) -ceq (@($saved.mounts) | ConvertTo-Json -Depth 8 -Compress))
            $script:RestoreScopeProbe.mounts_values_match=((Restore-MountDiagnosticValues $currentMounts) -ceq (Restore-MountDiagnosticValues @($saved.mounts)))
            $script:RestoreScopeProbe.restart_metadata_match=((Restore-CanonicalMetadataJson $now[0].restart) -ceq (Restore-CanonicalMetadataJson $saved.restart))
            $script:RestoreScopeProbe.mounts_metadata_match=((Restore-CanonicalMetadataJson @($currentMounts | Sort-Object -Property Destination)) -ceq (Restore-CanonicalMetadataJson @($saved.mounts | Sort-Object -Property Destination)))
        }
        if ($now.Count -ne 1 -or -not $script:RestoreScopeProbe.image_match -or -not $script:RestoreScopeProbe.service_match -or -not $script:RestoreScopeProbe.restart_metadata_match -or -not $script:RestoreScopeProbe.mounts_metadata_match) { throw 'RESTORE_SOURCE_SCOPE_CHANGED' }
    }
    $script:RestoreScopeProbe=[pscustomobject]@{step='EXTERNAL_CONSUMERS'}
    foreach ($item in $items) {
        if ((Project $item) -cne 'hybrid-windows' -and $item.id -cne $Receipt.helper_container_ids[0] -and ((Uses-Source $item $database) -or (Uses-Source $item $runtime))) { throw 'RESTORE_EXTERNAL_SOURCE_CONSUMER' }
    }
    $script:RestoreScopeProbe=[pscustomobject]@{step='FINAL_SNAPSHOT'}
    Assert-RestoreSourceSnapshot $items @() $false
    $script:RestoreScopeProbe=[pscustomobject]@{step='COMPLETE';source_project_count=$project.Count;labelled_project_count=$labelled.Count;verified_helper_excluded=$true;helper_had_project_label=((Project $oldWorker[0]) -ceq 'hybrid-windows')}
    return ,$items
}
