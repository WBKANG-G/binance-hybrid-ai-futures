@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_TRADES.ps1" -ManifestSHA256 6c281669490a82ca5effda73a0f3a5996174087125416fef87a956f4f85b54cd -CheckOnly
exit /b %errorlevel%
