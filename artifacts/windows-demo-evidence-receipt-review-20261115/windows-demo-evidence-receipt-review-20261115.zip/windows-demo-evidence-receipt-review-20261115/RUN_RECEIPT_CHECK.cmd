@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0REVIEW.ps1" -ManifestSHA256 6fb8862a0e1b3dd924c006fbb1bdeba27c7737c481f6b53589a18f1412b67035
exit /b %errorlevel%
