@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_COMPARE.ps1" -ManifestSHA256 d636dae4d82bee54e890f741c684c9d07c421a9d6a8d5cb8c61fc6d1bc5270fa -CompareOnce
exit /b %errorlevel%
