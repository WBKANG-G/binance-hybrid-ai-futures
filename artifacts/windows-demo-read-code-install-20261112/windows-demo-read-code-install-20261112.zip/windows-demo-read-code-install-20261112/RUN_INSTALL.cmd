@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL.ps1" -ManifestSHA256 b47b779a9a2997dc3ad9b2e658ec6b5a919b3406e4f153d7349de55906579eb5
exit /b %errorlevel%
