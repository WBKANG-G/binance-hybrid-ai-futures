@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_HANDOFF.ps1" -ManifestSHA256 fcd53effb5b14b87c333ff8430d96a82a85f6e1fb4d71e41a5e8c5c4d31847d2 -CheckOnly
exit /b %errorlevel%
