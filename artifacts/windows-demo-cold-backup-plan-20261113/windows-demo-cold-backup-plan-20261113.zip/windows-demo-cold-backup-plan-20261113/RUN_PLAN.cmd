@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0PLAN.ps1" -ManifestSHA256 94ea089e15b1d3b0a1b88c6c6c60699bb353c4d59bf3f53e2a9a55883ee63fc4
exit /b %errorlevel%
