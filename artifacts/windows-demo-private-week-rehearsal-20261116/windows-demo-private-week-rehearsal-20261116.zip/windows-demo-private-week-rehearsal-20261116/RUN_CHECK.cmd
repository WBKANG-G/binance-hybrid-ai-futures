@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_COPY.ps1" -ManifestSHA256 45261bc4cc8805b9602c7fa5e83190ed5960ebf9f0274f835d99ab5afa8ac1e5 -CheckOnly
exit /b %errorlevel%
