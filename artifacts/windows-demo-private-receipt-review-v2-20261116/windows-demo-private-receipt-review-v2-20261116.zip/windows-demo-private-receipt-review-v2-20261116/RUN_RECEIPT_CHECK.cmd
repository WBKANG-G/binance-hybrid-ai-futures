@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0REVIEW.ps1" -ManifestSHA256 3b8d08b59c1abb7e819d9dd63c39032e65ae6fc9f32b427f9499e89fe68c2e74
exit /b %errorlevel%
