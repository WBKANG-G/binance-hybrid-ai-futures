@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_REFERENCE.ps1" -ManifestSHA256 3ab9afc023a2d1fa25776ce73cc3a46846112f47ce4007a8d667cf3997ba381a -CheckOnly
exit /b %errorlevel%
