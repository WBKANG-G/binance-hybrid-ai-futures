@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_INCOME.ps1" -ManifestSHA256 3e40afcfe8b05397a1b444a8885a89cc0d715f7adacc8be7667cc0a5d119700c -CheckOnly
exit /b %errorlevel%
