@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_INSPECT.ps1" -ManifestSHA256 a1687d31f3fbf7a099d833541166cd996df8f79c6aa3e599707b2fe8c59afb5b -CheckOnly
exit /b %errorlevel%
