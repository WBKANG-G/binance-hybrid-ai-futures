@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_COPY.ps1" -ManifestSHA256 b610f3aa58cb3fd31d5753a7f55d8d828b317a7444f84ae0bf4c73ab30fd3933 -CheckOnly
exit /b %errorlevel%
