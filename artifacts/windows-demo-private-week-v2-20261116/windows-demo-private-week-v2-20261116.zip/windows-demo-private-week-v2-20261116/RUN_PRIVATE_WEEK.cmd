@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_COPY.ps1" -ManifestSHA256 a010b3037c60df7d21e2ef71991049a39689b7d31b976f5f6726d52aa624dfa9 -ExecuteReview
exit /b %errorlevel%
