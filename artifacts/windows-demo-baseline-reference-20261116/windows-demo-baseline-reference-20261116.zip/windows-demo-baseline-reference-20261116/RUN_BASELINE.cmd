@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_BASELINE.ps1" -ManifestSHA256 b52837f3f0f4c68cbac57945a1380bb00212c7d986c3bc26690df2d66a132bba
exit /b %errorlevel%
