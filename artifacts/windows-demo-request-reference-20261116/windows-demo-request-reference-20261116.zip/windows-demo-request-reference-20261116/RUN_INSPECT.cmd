@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_INSPECT.ps1" -ManifestSHA256 c9f9c4c2130564a740de9683ff6781de78d6c205092b7f214a6d16f4c55a9f0a
exit /b %errorlevel%
