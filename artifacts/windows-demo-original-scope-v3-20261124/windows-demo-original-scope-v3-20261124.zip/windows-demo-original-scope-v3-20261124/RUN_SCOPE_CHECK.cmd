@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_SCOPE.ps1" -ManifestSHA256 373bfd8718f9e69fcffa5334ec88a6eab9572aa790ca714c021cbdf6372a86f2
exit /b %errorlevel%
