@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0HISTORICAL_LOCAL_RECEIPTS.ps1" -ManifestSHA256 ca01f04ac6f1effb34c5831292a4afe616c163af99f8edfd4744726fbb041fee
exit /b %errorlevel%
