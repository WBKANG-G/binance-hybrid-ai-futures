@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_COPY.ps1" -ManifestSHA256 e58565156130361b2c6d5cc1ea14843de3c513de956d666e3540baf3b42e23f5 -CheckOnly
exit /b %errorlevel%
