@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_REVIEW.ps1" -ManifestSHA256 b0a455b5d261cf36628a345e9ae1610e1a25ae002ba401a9d0fe111df75bdc1c
exit /b %errorlevel%
