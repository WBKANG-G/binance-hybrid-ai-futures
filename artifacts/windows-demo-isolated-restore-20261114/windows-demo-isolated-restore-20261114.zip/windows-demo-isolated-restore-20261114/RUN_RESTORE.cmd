@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_RESTORE.ps1" -ManifestSHA256 64876fe7125aa32cd395c3c3c36b42cf1f084e541d7f900b4c8ba96d0ea4539b -ExecuteRestore
exit /b %errorlevel%
