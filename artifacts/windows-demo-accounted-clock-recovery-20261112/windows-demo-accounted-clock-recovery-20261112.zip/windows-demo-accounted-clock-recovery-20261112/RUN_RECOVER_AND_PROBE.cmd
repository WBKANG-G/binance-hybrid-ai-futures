@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0RECOVER_AND_PROBE.ps1" -ManifestSHA256 faffd00f7b5280049ef91c9ee074045a7f81e09cef8dcdbbd348faf14f9b0c7a
exit /b %errorlevel%
