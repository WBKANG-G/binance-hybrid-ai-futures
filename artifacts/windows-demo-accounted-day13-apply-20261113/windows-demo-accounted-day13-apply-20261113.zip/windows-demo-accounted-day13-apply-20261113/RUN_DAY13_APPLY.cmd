@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0DAY13_APPLY.ps1" -ManifestSHA256 d45301a9f0c98978ac13ed19eee0f639e0fbd1a9043b1a620a5a66b21ed9f626
exit /b %errorlevel%
