function Backup-Docker([string[]]$Arguments,[int]$Maximum=256) {
    $lines=@(& docker @Arguments 2>$null)
    if ($LASTEXITCODE -ne 0 -or $lines.Count -gt $Maximum) { throw 'COLD_DOCKER_COMMAND_FAILED' }
    foreach ($line in $lines) { if (([string]$line).Length -gt 65536) { throw 'COLD_DOCKER_OUTPUT_INVALID' } }
    return $lines
}
function Assert-PrivateBackupDirectory([string]$Path) {
    if (([IO.File]::GetAttributes($Path) -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'COLD_BACKUP_PATH_REPARSE_POINT' }
    $acl=[IO.Directory]::GetAccessControl($Path)
    $user=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    if (-not $acl.AreAccessRulesProtected -or $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value -cne $user) { throw 'COLD_BACKUP_ACL_INVALID' }
    $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]))
    if ($rules.Count -ne 2) { throw 'COLD_BACKUP_ACL_INVALID' }
    foreach ($rule in $rules) {
        if (@($user,'S-1-5-18') -cnotcontains $rule.IdentityReference.Value -or $rule.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow -or $rule.FileSystemRights -ne [Security.AccessControl.FileSystemRights]::FullControl -or $rule.IsInherited) { throw 'COLD_BACKUP_ACL_INVALID' }
    }
}
function Assert-PrivateBackupFiles([string]$Directory) {
    $user=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    foreach ($file in @(Get-ChildItem -LiteralPath $Directory -Force)) {
        if ($file.PSIsContainer -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'COLD_BACKUP_ACL_INVALID' }
        $acl=[IO.File]::GetAccessControl($file.FullName)
        if ($acl.GetOwner([Security.Principal.SecurityIdentifier]).Value -cne $user) { throw 'COLD_BACKUP_ACL_INVALID' }
        $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]))
        if ($rules.Count -ne 2) { throw 'COLD_BACKUP_ACL_INVALID' }
        foreach ($rule in $rules) { if (@($user,'S-1-5-18') -cnotcontains $rule.IdentityReference.Value -or $rule.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow -or $rule.FileSystemRights -ne [Security.AccessControl.FileSystemRights]::FullControl) { throw 'COLD_BACKUP_ACL_INVALID' } }
    }
}
