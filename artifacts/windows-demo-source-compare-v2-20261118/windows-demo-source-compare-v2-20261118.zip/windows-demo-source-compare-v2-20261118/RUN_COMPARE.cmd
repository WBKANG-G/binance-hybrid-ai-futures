@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_COMPARE.ps1" -ManifestSHA256 9d7951c3beae8f2b79c66d572134da0dca8b667c57c50bc87985e8468799bfb4 -CompareOnce
exit /b %errorlevel%
