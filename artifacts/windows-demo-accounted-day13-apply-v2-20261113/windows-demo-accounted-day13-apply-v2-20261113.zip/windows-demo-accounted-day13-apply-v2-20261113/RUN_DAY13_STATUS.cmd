@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0DAY13_APPLY.ps1" -StatusOnly -ManifestSHA256 9a16e64222c23841a3c24357a3e5ad9f75b7a98cd8113d7ecbcdcb70011488b2
exit /b %errorlevel%
