@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0REVIEW.ps1" -ManifestSHA256 6a5ac20ce1d2698731ba460f6d9bd829738570f0da85b9677ade001ef03b1184 -AuditApply
exit /b %errorlevel%
