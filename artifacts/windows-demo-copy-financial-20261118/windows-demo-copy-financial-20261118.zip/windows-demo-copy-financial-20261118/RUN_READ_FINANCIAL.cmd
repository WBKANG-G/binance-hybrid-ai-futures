@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_FINANCIAL.ps1" -ManifestSHA256 c76e7712c09bb33fb07afca9ce5f33430ea90fa2823931be639b963b5b542eff -ExecuteRead
exit /b %errorlevel%
