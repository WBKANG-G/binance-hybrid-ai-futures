@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_NO_SEND_CHECK.ps1" -ManifestSHA256 949c8f29a0a8602c1a8f6237c5a299f727fd92d20b7bfb04dc67db4fc08b070c
exit /b %errorlevel%
