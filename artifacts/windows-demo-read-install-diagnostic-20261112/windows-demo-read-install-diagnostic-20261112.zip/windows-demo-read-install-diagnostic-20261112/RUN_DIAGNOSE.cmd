@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0DIAGNOSE.ps1" -ManifestSHA256 7aef6bedd3e5dcc3020fe9dd60716987eb1480a28cd84bcdb1f686858a56f1d0
exit /b %errorlevel%
