@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_SUPPORT_DRAFT.ps1" -ManifestSHA256 765b5cc702db4018791fe355b88a0156044b2d2314068089c4f251433856b9d8 -CheckOnly
exit /b %errorlevel%
