@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0HISTORICAL_REQUESTS.ps1" -ManifestSHA256 5f18f093f9b8492d5999d9d700d3af9dd53d3d9a1fc8e8c6e0a679638aac5765
exit /b %errorlevel%
