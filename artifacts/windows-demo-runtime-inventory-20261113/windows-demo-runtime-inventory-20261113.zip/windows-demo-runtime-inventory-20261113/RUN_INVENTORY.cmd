@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0INVENTORY.ps1" -ManifestSHA256 51262321a18c573f816d846f24a14c2223879c92084ef7bd702d01baecddb64b
exit /b %errorlevel%
