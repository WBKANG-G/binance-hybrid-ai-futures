@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0PROBE.ps1" -ManifestSHA256 05472c78aad637af30466cb8ddebe15a084d99601741ad45eb9767f1085257ab
exit /b %errorlevel%
