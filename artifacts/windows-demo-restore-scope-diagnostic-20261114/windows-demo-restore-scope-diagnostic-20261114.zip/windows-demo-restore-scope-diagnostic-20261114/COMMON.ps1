# Functions only. The signed-by-transfer-hash launcher performs the opt-in call.
function Backup-Docker([string[]]$Arguments,[int]$Maximum=256) {
    $lines=@(& docker @Arguments 2>$null)
    if ($LASTEXITCODE -ne 0 -or $lines.Count -gt $Maximum) { throw 'COLD_DOCKER_COMMAND_FAILED' }
    foreach ($line in $lines) { if (([string]$line).Length -gt 65536) { throw 'COLD_DOCKER_OUTPUT_INVALID' } }
    return $lines
}
function Write-BackupJson([string]$Path,[object]$Value) {
    $bytes=[Text.Encoding]::UTF8.GetBytes(($Value | ConvertTo-Json -Depth 16 -Compress)+"`n")
    $stream=New-Object IO.FileStream($Path,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
    try { $stream.Write($bytes,0,$bytes.Length); $stream.Flush($true) } finally { $stream.Dispose() }
}
function New-PrivateBackupDirectory([string]$Token) {
    if ([Environment]::OSVersion.Platform -ne [PlatformID]::Win32NT) { throw 'COLD_WINDOWS_ACL_REQUIRED' }
    $base=[Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)
    if (-not [IO.Path]::IsPathRooted($base) -or $base -cne $env:LOCALAPPDATA) { throw 'COLD_LOCALAPPDATA_INVALID' }
    $drive=New-Object IO.DriveInfo([IO.Path]::GetPathRoot($base))
    if ($drive.DriveFormat -cne 'NTFS' -or $drive.AvailableFreeSpace -lt 2GB) { throw 'COLD_PRIVATE_STORAGE_UNAVAILABLE' }
    $current=New-Object IO.DirectoryInfo($base)
    while ($null -ne $current) {
        if (($current.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'COLD_BACKUP_PATH_REPARSE_POINT' }
        $current=$current.Parent
    }
    $sid=[Security.Principal.WindowsIdentity]::GetCurrent().User
    $system=New-Object Security.Principal.SecurityIdentifier('S-1-5-18')
    $acl=New-Object Security.AccessControl.DirectorySecurity
    $acl.SetOwner($sid)
    $acl.SetAccessRuleProtection($true,$false)
    foreach ($identity in @($sid,$system)) {
        $rule=New-Object Security.AccessControl.FileSystemAccessRule($identity,[Security.AccessControl.FileSystemRights]::FullControl,([Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [Security.AccessControl.InheritanceFlags]::ObjectInherit),[Security.AccessControl.PropagationFlags]::None,[Security.AccessControl.AccessControlType]::Allow)
        $null=$acl.AddAccessRule($rule)
    }
    $parent=Join-Path $base 'WBKANG-DEMO-Backups'
    if (-not [IO.Directory]::Exists($parent)) { $null=[IO.Directory]::CreateDirectory($parent,$acl) }
    if (([IO.File]::GetAttributes($parent) -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'COLD_BACKUP_PATH_REPARSE_POINT' }
    # Apply and verify DACL before creating the run directory or saving images.
    [IO.Directory]::SetAccessControl($parent,$acl)
    $destination=Join-Path $parent ('cold-20261114-'+$Token)
    if ([IO.Directory]::Exists($destination)) { throw 'COLD_BACKUP_DIRECTORY_EXISTS' }
    $null=[IO.Directory]::CreateDirectory($destination,$acl)
    Assert-PrivateBackupDirectory $destination
    return $destination
}
function Assert-PrivateBackupDirectory([string]$Path) {
    if (([IO.File]::GetAttributes($Path) -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'COLD_BACKUP_PATH_REPARSE_POINT' }
    $acl=[IO.Directory]::GetAccessControl($Path)
    $user=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    if (-not $acl.AreAccessRulesProtected -or $acl.GetOwner([Security.Principal.SecurityIdentifier]).Value -cne $user) { throw 'COLD_BACKUP_ACL_INVALID' }
    $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]))
    if ($rules.Count -ne 2) { throw 'COLD_BACKUP_ACL_INVALID' }
    foreach ($rule in $rules) {
        if (@($user,'S-1-5-18') -cnotcontains $rule.IdentityReference.Value -or $rule.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow -or $rule.FileSystemRights -ne [Security.AccessControl.FileSystemRights]::FullControl -or $rule.IsInherited) { throw 'COLD_BACKUP_ACL_INVALID' }
    }
}
function Assert-PrivateBackupFiles([string]$Directory) {
    $user=[Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    foreach ($file in @(Get-ChildItem -LiteralPath $Directory -Force)) {
        if ($file.PSIsContainer -or ($file.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw 'COLD_BACKUP_ACL_INVALID' }
        $acl=[IO.File]::GetAccessControl($file.FullName)
        if ($acl.GetOwner([Security.Principal.SecurityIdentifier]).Value -cne $user) { throw 'COLD_BACKUP_ACL_INVALID' }
        $rules=@($acl.GetAccessRules($true,$true,[Security.Principal.SecurityIdentifier]))
        if ($rules.Count -ne 2) { throw 'COLD_BACKUP_ACL_INVALID' }
        foreach ($rule in $rules) { if (@($user,'S-1-5-18') -cnotcontains $rule.IdentityReference.Value -or $rule.AccessControlType -ne [Security.AccessControl.AccessControlType]::Allow -or $rule.FileSystemRights -ne [Security.AccessControl.FileSystemRights]::FullControl) { throw 'COLD_BACKUP_ACL_INVALID' } }
    }
}
function Sync-BackupFile([string]$Path) {
    $stream=New-Object IO.FileStream($Path,[IO.FileMode]::Open,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    try { $stream.Flush($true) } finally { $stream.Dispose() }
}
function Backup-FreeBytes([string]$Directory) {
    $drive=New-Object IO.DriveInfo([IO.Path]::GetPathRoot($Directory))
    return $drive.AvailableFreeSpace
}
function Assert-SourceSnapshot([object[]]$Original,[string[]]$Helpers,[bool]$Frozen) {
    $current=@(Container-Ids)
    $expected=@(@($Original | ForEach-Object {$_.id})+$Helpers | Sort-Object)
    if (($current -join '|') -cne ($expected -join '|')) { throw 'COLD_CONTAINER_SET_CHANGED' }
    foreach ($old in $Original) {
        $fresh=Read-Container $old.id
        $expectedRunning=$old.running
        if ($Frozen -and (Project $old) -ceq 'hybrid-windows' -and @('api','db','web','alerts') -ccontains (Service $old)) { $expectedRunning=$false }
        if ($fresh.running -ne $expectedRunning -or $fresh.restarting -or $fresh.paused -or $fresh.dead) { throw 'COLD_SOURCE_RUNNING_STATE_CHANGED' }
        if ($Frozen -and $old.running -and -not $expectedRunning) {
            $oldKeys=@($old.networks.PSObject.Properties | ForEach-Object {$_.Name} | Sort-Object)
            $newKeys=@($fresh.networks.PSObject.Properties | ForEach-Object {$_.Name} | Sort-Object)
            if (($oldKeys -join '|') -cne ($newKeys -join '|')) { throw 'COLD_SOURCE_CONFIGURATION_CHANGED' }
            foreach ($key in $oldKeys) { if ($fresh.networks.$key.NetworkID -cne $old.networks.$key.NetworkID) { throw 'COLD_SOURCE_CONFIGURATION_CHANGED' } }
            # Docker clears endpoint IP/MAC/ID on stop; retain membership checks above.
            $fresh.networks=$old.networks
        }
        $fresh.running=$old.running
        if (($fresh | ConvertTo-Json -Depth 12 -Compress) -cne ($old | ConvertTo-Json -Depth 12 -Compress)) { throw 'COLD_SOURCE_CONFIGURATION_CHANGED' }
    }
}
