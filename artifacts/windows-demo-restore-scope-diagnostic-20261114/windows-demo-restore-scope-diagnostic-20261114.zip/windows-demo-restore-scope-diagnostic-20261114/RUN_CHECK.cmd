@echo off
setlocal DisableDelayedExpansion
powershell -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%~dp0RUN_RESTORE.ps1" -ManifestSHA256 b1c96ac131d51fc88253c0c00cdf38a35c23151a5999414beccfa94efa7948bc -CheckOnly
exit /b %errorlevel%
