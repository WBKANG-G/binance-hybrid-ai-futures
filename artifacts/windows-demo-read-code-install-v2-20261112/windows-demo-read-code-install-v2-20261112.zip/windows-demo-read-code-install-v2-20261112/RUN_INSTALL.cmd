@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0INSTALL.ps1" -ManifestSHA256 6ffdcfef691b0f4a514574f358a35594bb31f6a7c1eaf22ffed8e99bed3ea21d
exit /b %errorlevel%
