"""Explicit single capped DEMO entry, bounded TP observation, original safety cleanup."""

import argparse
import asyncio
import json
import os
from pathlib import Path
from uuid import UUID, uuid4, uuid5

import yaml
from sqlalchemy import create_engine

from integrations.binance_usdm.demo import DemoSettings
from packages.domain.config import UniqueKeyLoader, database_url
from packages.persistence.demo import DemoStore
from scripts.demo_key_session import credentials
from scripts.observe_demo_private import ACCOUNT
from services.execution.demo_api_restart_check import empty
from services.execution.demo_tp_trigger_check import TPTriggerClient, TPTriggerCoordinator, run
from services.execution.demo_validation import safe_failure


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--enable-demo", action="store_true", required=True)
    parser.add_argument("--enable-tp-trigger-observation", action="store_true", required=True)
    parser.add_argument("--operation-id", type=UUID, required=True)
    args = parser.parse_args()
    engine = store = lease = None
    report = {
        "tp_trigger_check": "BLOCKED",
        "failure": "CHECK_FAILED",
        "orders_enabled": False,
        "live_trading_enabled": False,
    }
    success = False
    try:
        if (
            os.getenv("LIVE_TRADING_ENABLED", "false").lower() != "false"
            or os.getenv("TRADING_MODE", "PAPER") == "LIVE"
        ):
            raise ValueError("LIVE context forbidden")
        key = credentials(prompt=False)
        cfg = DemoSettings.model_validate(
            yaml.load(
                Path("configs/demo-isolated.example.yaml").read_text(), Loader=UniqueKeyLoader
            )
        )
        client = TPTriggerClient(cfg.model_copy(update={"demo_trading_enabled": False}), key)
        client.sync_clock()
        engine = create_engine(
            database_url().get_secret_value(), connect_args={"connect_timeout": 2}
        )
        store = DemoStore(engine)
        state = store.read(ACCOUNT)
        if (
            str(args.operation_id) in state.orders
            or str(uuid5(args.operation_id, "tp-trigger-observation")) in state.operations
        ):
            raise ValueError("Existing operation must not be submitted again")
        lease = store.acquire(ACCOUNT, uuid4())
        coordinator = TPTriggerCoordinator(store, lease, client)
        empty(coordinator)
        coordinator.refresh_metadata()
        coordinator.reconcile()
        client.settings = cfg.model_copy(update={"demo_trading_enabled": True})
        report = asyncio.run(run(coordinator, args.operation_id))
        success = report["tp_trigger_check"] == "TP_FILLED_THEN_REMAINING_SL_CANCELED_FLAT_VERIFIED"
    except Exception as error:
        report["failure"] = safe_failure(error)
    finally:
        try:
            if store is not None and lease is not None:
                store.release(lease)
        except Exception:
            success = False
            report["tp_trigger_check"] = "BLOCKED"
            report["failure"] = "LEASE_RELEASE_FAILED"
        finally:
            if engine is not None:
                engine.dispose()
    print(json.dumps(report), flush=True)
    if not success:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
