import json
from concurrent.futures import ThreadPoolExecutor
from services.execution.demo_runtime_confirmation import ConfirmationClaim
from services.execution.demo_managed_runtime import assemble_managed_runtime
from packages.persistence.demo_order_quota import LocalQuotaStopped
claim=ConfirmationClaim()
with ThreadPoolExecutor(max_workers=8) as workers:
    results=list(workers.map(lambda _:claim.claim(),range(16)))
assert sum(results)==1 and claim.diagnostics()['repeated_calls_refused']==15
claim.finish()
assert not claim.claim()
assert not claim.diagnostics()['confirmation_call_active']
try:
    assemble_managed_runtime(None,None,None,None,None)
    raise AssertionError('execution enabled')
except LocalQuotaStopped as error:assert str(error)=='RUNTIME_REAL_EXECUTION_DISABLED'
print(json.dumps(dict(smoke='PASSED',network='NONE',scope='THREADED_CLAIM_IMPORTS_DEFAULT_REFUSAL_ONLY',threaded_claim_winners=sum(results),completion_reopens_permission=False,default_execution_refused=True,actual_exchange_requests=0)))
